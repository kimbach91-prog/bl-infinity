# DEUS-ONE PUBLIC COMPOSITION R6.2

An executable maintenance candidate for the six archived PUBLIC R4.1 module families already integrated by R6.1. The production change is in `kernel.py`; inherited algorithms, adapters, composition logic and the independent verifier are unchanged.

## Changes

1. Check pinned dependencies before importing adapters and inherited modules. Normalize unavailable or incomplete manifest errors into the existing CLI JSON rejection contract.
2. Validate the local receipt's task, context, source, result, typed codec, call count and verifier record before committing a completed result or returning a replay.
3. Use the same process lock for SQLite startup and task execution. This closes a reproduced concurrent-startup failure (`database is locked`) while retaining one connection per runner, WAL, `synchronous=FULL` and existing transactions.

The runner still admits only bounded PUBLIC/PURE requests. It does not integrate the private DEUS core, B1–B8, a neural model or a new chess engine.

## Requirements and verification

Linux and CPython 3.11 or later; standard library only. The runner makes no network calls and reads no credentials.

```sh
python verify_release.py
python -W error -m unittest discover -s tests -v
python kernel.py --store /tmp/deus-r62-demo.db --request examples/mapping.json
python kernel.py --store /tmp/deus-r62-demo.db --request examples/mapping.json
python run_graph.py --store /tmp/deus-r62-graph.db --workflow examples/source_to_plan.json
```

Use new store paths for R6.2. Repeating the same admitted task should return an idempotent replay without invoking its producer again. Recovery and snapshots are tested within one source version. **This release does not migrate R6.1 stores or snapshots in place.** Source changes cause different fingerprints; an old task ID can be rejected as an idempotency conflict. Keep the R6.1 runtime with its original store and archive for recovery. Never clear a job or change its ID merely to bypass an unknown outcome.

The final source test run passed 54/54 tests: the 44 inherited integration cases plus 10 new contract cases. A separate bounded startup check passed 40/40 pairs of simultaneous processes, with one execution and one replay per pair. The failed qualification and before/after diagnostic remain in `evidence/r62`. These are local tests, not multi-host HA or external certification.

## Evidence and history

- `LINEAGE.json` identifies the exact R6.1 archive already present on Google Drive and the current source ID.
- `history/r61` preserves the original R6.1 top-level report, model card, pending checkpoint and manifests. Their time-dependent statements remain historical.
- `evidence/r62` contains new tests, the startup failure and repair, static review, a code/configuration patch, and a limited external readiness observation.
- Other `evidence` files are unchanged R6.1 or earlier records. The 120-task benchmark, 305-test upstream log and 0–0–100 chess baseline are historical, not R6.2 runs.
- The original R5.1 archive and its 101-entry source manifest remain byte-identical. `SOURCE_BINDINGS.json` pins nine inherited modules and four integration modules.

No performance claim is made for R6.2. R6.1 measurements cannot be reused as measurements of the new receipt checks or startup lock.

## External PUBLIC route

`NATIVE_HANDOFF_PENDING.json` describes a source-backed readiness assessment of the existing Railway PUBLIC result service. Two unauthenticated GET requests returned HTTP 200 and matched expected provider, target, policy, catalog and module identities. No result task was submitted. A current admitted credential/job adapter is required before a POST can be considered. The service's idempotency is limited to one process boot; health does not provide an execution ACK or durable lease.

## Trust and custody

This is trusted local development code and a contract validator. Hashes check consistency against supplied pins; they are not owner authorization, supply-chain signatures or native identity authentication. Per-call input/output digests are checked for format, not independently reconstructed for every historic trace. A separate verifier checks result semantics; process separation is not a third-party certificate.

The R6.1 source ZIP was found on Drive and read back exactly during this task. The R6.2 package and `CANON_PENDING.json` are prepared changes only: an attempted checkpoint write returned `user rejected MCP tool call`, and readback confirmed no row was added. No R6.2 upload, GitHub commit, deployment or native ACK has occurred. External publication is held for concrete approval of the prepared change. No new Library/Project/ChatGPT attachment copy is created.
