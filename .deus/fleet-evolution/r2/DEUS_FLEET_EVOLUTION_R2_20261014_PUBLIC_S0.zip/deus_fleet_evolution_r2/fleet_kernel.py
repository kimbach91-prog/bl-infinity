#!/usr/bin/env python3
"""DEUS Fleet Evolution R2: bounded, offline, evidence-gated scheduler review kernel.

NO scheduler API, Drive writer, provider credential, remote dispatch, grant or native deployment.
The 23 actual task IDs are supplied as a PRIVATE owner manifest; never hard-code them
into a public code repository. SQLite is a local single-writer review fence only:
no claim of distributed exactly-once external effects.
"""
from __future__ import annotations

import argparse
import dataclasses
import datetime as dt
import hashlib
import json
import re
import sqlite3
from pathlib import Path
from typing import Any, Mapping, Sequence
from zoneinfo import ZoneInfo

TZ = "Asia/Ho_Chi_Minh"
UTC = dt.timezone.utc
DAILY_ID_PREFIX = "DEUS-DAILY-FLEET-EVOLUTION"
SCHEMA = "deus-fleet-evolution-review-r2/1"
REQUIRED_EVIDENCE = (
    "pinned_version", "source_hash", "target_admitted", "task_lease",
    "target_ack", "useful_output_receipt", "independent_verifier",
    "negative_regression", "same_job_cold_recovery", "rollback_verified", "drive_exact_readback",
)
DEUS_MINUTES = {f"DEUS{i:02d}": (31 + 4 * (i - 1)) % 60 for i in range(1, 16)}
WORKSPACE_MINUTES = {"Nguon":0,"UI":5,"Backend":13,"AIResearch":21,
                     "OSS":35,"DieuPhoi":31,"QA":47,"TienDo":51}
WORKSPACE_ROLES = frozenset(WORKSPACE_MINUTES)


class ContractError(ValueError):
    pass


def canon(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False,
                      separators=(",", ":")).encode("utf-8", "strict")


def digest(value: Any) -> str:
    return hashlib.sha256(canon(value)).hexdigest()


def fprint_legacy(value: Any) -> str:
    """An illustrative weak 32-bit FNV-1a baseline; DO NOT use to admit effects."""
    x = 2166136261
    for byte in canon(value):
        x = ((x ^ byte) * 16777619) & 0xFFFFFFFF
    return f"{x:08x}"


def safe_iso(value: str) -> dt.datetime:
    if not isinstance(value, str):
        raise ContractError("BAD_TIME_TYPE")
    try:
        instant = dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (ValueError, TypeError) as exc:
        raise ContractError("BAD_TIMESTAMP") from exc
    if instant.tzinfo is None or instant.utcoffset() is None:
        raise ContractError("NAIVE_TIMESTAMP")
    return instant.astimezone(UTC)


def safe_day(value: str) -> str:
    try:
        day = dt.date.fromisoformat(value)
    except Exception as exc:
        raise ContractError("BAD_DAY") from exc
    if day.isoformat() != value:
        raise ContractError("NONCANONICAL_DAY")
    return value


def parsed_schedule(task: Mapping[str, Any]) -> dict[str, Any]:
    raw = task.get("schedule")
    if not isinstance(raw, str) or not raw.startswith("BEGIN:VEVENT\n") or not raw.rstrip().endswith("END:VEVENT"):
        raise ContractError("BAD_VEVENT")
    dtstarts = re.findall(r"^DTSTART(?:;TZID=([^:\n]+))?:(\d{8}T\d{6})$", raw, re.M)
    freq = re.findall(r"^RRULE:(.+)$", raw, re.M)
    if len(dtstarts) != 1 or len(freq) != 1:
        raise ContractError("AMBIGUOUS_CALENDAR_RULE")
    if raw.count("\nDTSTART") != 1 or raw.count("\nRRULE:") != 1:
        raise ContractError("CALENDAR_DUPLICATE_LINE")
    params = {}
    for entry in freq[0].split(";"):
        if "=" not in entry:
            raise ContractError("BAD_RRULE")
        k,v = entry.split("=", 1)
        if k in params:
            raise ContractError("DUPLICATE_RRULE_KEY")
        params[k] = v
    if (set(params)-{"FREQ","BYMINUTE","BYSECOND","INTERVAL"}) or params.get("INTERVAL","1") != "1":
        raise ContractError("UNSUPPORTED_RECURRENCE_MUTATION")
    if params.get("BYSECOND", "0") != "0":
        raise ContractError("SECOND_DRIFT")
    zone, stamp = dtstarts[0]
    zone = zone or task.get("default_timezone")
    if zone != TZ:
        raise ContractError("WRONG_TIMEZONE")
    try:
        moment = dt.datetime.strptime(stamp, "%Y%m%dT%H%M%S")
        moment.replace(tzinfo=ZoneInfo(zone))
    except (ValueError, KeyError) as exc:
        raise ContractError("BAD_LOCAL_DATETIME") from exc
    return {"frequency":params.get("FREQ"), "start_minute":moment.minute,
            "timezone":zone, "start_local":stamp, "rrule":params}


def classify_task(task: Mapping[str, Any], role: str, expected_id: str) -> dict[str, Any]:
    if not isinstance(task, Mapping) or task.get("id") != expected_id:
        raise ContractError("TASK_ID_MISMATCH")
    if not isinstance(task.get("prompt"),str) or not task["prompt"].strip():
        raise ContractError("PROMPT_PREIMAGE_MISSING")
    if type(task.get("is_enabled")) is not bool:
        raise ContractError("MISSING_ENABLED_BOOLEAN")
    if task.get("notifications_enabled") not in (False, None) or task.get("email_enabled") not in (False, None):
        raise ContractError("UNEXPECTED_NOTIFICATION_STATE")
    spec = parsed_schedule(task)
    if spec["frequency"] != "HOURLY":
        raise ContractError("CADENCE_DRIFT")
    if role in DEUS_MINUTES and spec["start_minute"] != DEUS_MINUTES[role]:
        raise ContractError("DEUS_MINUTE_DRIFT")
    if role.startswith("WS/"):
        if role[3:] not in WORKSPACE_ROLES:
            raise ContractError("UNKNOWN_WS_ROLE")
        if task.get("timing_mode") != "exact_schedule":
            raise ContractError("WORKSPACE_TIMING_DRIFT")
        if spec["start_minute"] != WORKSPACE_MINUTES[role[3:]]:
            raise ContractError("WORKSPACE_MINUTE_DRIFT")
    expected_min = DEUS_MINUTES[role] if role in DEUS_MINUTES else WORKSPACE_MINUTES[role[3:]]
    if "BYMINUTE" in spec["rrule"] and spec["rrule"]["BYMINUTE"] != str(expected_min):
        raise ContractError("BYMINUTE_DRIFT")
    # last_run_time belongs to the scheduler, not an executor ACK; no process credit.
    last = task.get("last_run_time")
    if last is not None:
        safe_iso(last)
    return {"role":role, "id":expected_id, "enabled":task["is_enabled"],
            "configured":True, "scheduler_last_run_observed":last is not None,
            "actually_executed":False, "native_verified":False,
            "disable_cause":"UNKNOWN" if not task["is_enabled"] else "N/A",
            "schedule":spec, "last_run_utc":last,
            "source_signature":digest({k:task.get(k) for k in (
                "id","schedule","default_timezone","timing_mode","is_enabled","prompt")})}


def validate_snapshot(snapshot: Mapping[str, Any]) -> dict[str, Any]:
    """Must receive exactly the canonical 23-role allowlist, not provider-wide tasks."""
    if not isinstance(snapshot, Mapping) or snapshot.get("schema") != SCHEMA:
        raise ContractError("WRONG_SCHEMA")
    expected = snapshot.get("expected_ids")
    tasks = snapshot.get("tasks")
    if not isinstance(expected, dict) or not isinstance(tasks, list) or len(expected) != 23 or len(tasks) != 23:
        raise ContractError("NOT_EXACTLY_23")
    if set(expected) != set(DEUS_MINUTES) | {f"WS/{r}" for r in WORKSPACE_ROLES}:
        raise ContractError("WRONG_ROLE_ROSTER")
    if any(not isinstance(x,str) or not re.fullmatch(r"[0-9a-f]{32}",x) for x in expected.values()):
        raise ContractError("BAD_PROVIDER_TASK_ID")
    if len(set(expected.values())) != 23:
        raise ContractError("ROSTER_ID_COLLISION")
    tasks_by_id = {t.get("id"):t for t in tasks if isinstance(t,Mapping)}
    if len(tasks_by_id) != 23 or set(tasks_by_id) != set(expected.values()):
        raise ContractError("UNKNOWN_OR_DUPLICATE_TASK_ID")
    lanes = [classify_task(tasks_by_id[id],role,id) for role,id in sorted(expected.items())]
    return {"lanes": lanes, "count":23,"enabled_count":sum(x["enabled"] for x in lanes),
            "disabled_count":sum(not x["enabled"] for x in lanes),
            "canonical_fingerprint":digest([{
                "role":x["role"],"id":x["id"],"enabled":x["enabled"],
                "schedule":x["schedule"],"source_signature":x["source_signature"]} for x in lanes])}


def qualify_native(evidence: Mapping[str, Any] | None) -> tuple[str, list[str]]:
    if not evidence:
        return "NATIVE_HOLD", list(REQUIRED_EVIDENCE)
    absent=[x for x in REQUIRED_EVIDENCE if evidence.get(x) is not True]
    if evidence.get("effect_state") in ("UNKNOWN", "REJECTED", "POLICY_DENIED"):
        return "NO_REPLAY", absent
    if absent:
        return "NATIVE_HOLD", absent
    if evidence.get("verification_job") == evidence.get("production_job"):
        return "NATIVE_HOLD", ["INDEPENDENCE_NOT_PROVEN"]
    return "EVIDENCE_PACKET_COMPLETE_UNVERIFIED_TARGET", []


class DayFence:
    """Local transactional fence with per-day immutable review; no remote effects."""
    def __init__(self, path: str):
        self.db=sqlite3.connect(path,timeout=5, isolation_level=None)
        self.db.execute("PRAGMA busy_timeout=5000")
        self.db.execute("CREATE TABLE IF NOT EXISTS review(day TEXT PRIMARY KEY, fingerprint TEXT NOT NULL, manifest_id TEXT NOT NULL, status TEXT NOT NULL)")
        self.db.execute("CREATE TABLE IF NOT EXISTS intents(day TEXT NOT NULL, scope TEXT NOT NULL, effect_hash TEXT NOT NULL, state TEXT NOT NULL, PRIMARY KEY(day,scope))")

    def admit_daily(self,day: str, fingerprint:str, exists_on_drive:bool)->str:
        safe_day(day)
        if not re.fullmatch(r"[0-9a-f]{64}",fingerprint):
            raise ContractError("BAD_MANIFEST_FINGERPRINT")
        self.db.execute("BEGIN IMMEDIATE")
        try:
            prev=self.db.execute("SELECT fingerprint FROM review WHERE day=?",(day,)).fetchone()
            if prev:
                result="REUSE_SAME_DAY" if prev[0]==fingerprint else "SOURCE_DELTA_SAME_DAY_REVIEW_ONLY"
            elif exists_on_drive:
                self.db.execute("INSERT INTO review VALUES (?,?,?,?)",(day,fingerprint,DAILY_ID_PREFIX+"-"+day,"EXTERNAL_MANIFEST_ALREADY_EXISTS"))
                result="REUSE_CANONICAL_DRIVE_DAY"
            else:
                self.db.execute("INSERT INTO review VALUES (?,?,?,?)",(day,fingerprint,DAILY_ID_PREFIX+"-"+day,"LOCAL_REVIEW_ONLY"))
                result="LOCAL_DAY_REVIEW_CLAIM_ONLY"
            self.db.execute("COMMIT")
            return result
        except BaseException:
            self.db.execute("ROLLBACK")
            raise

    def reserve_intent(self,day:str,scope:str,effect_hash:str)->str:
        safe_day(day)
        if not scope or not re.fullmatch(r"[0-9a-f]{64}",effect_hash):
            raise ContractError("INVALID_EFFECT_INTENT")
        self.db.execute("BEGIN IMMEDIATE")
        try:
            current=self.db.execute("SELECT effect_hash,state FROM intents WHERE day=? AND scope=?",(day,scope)).fetchone()
            if current:
                result="NO_REPLAY_SAME_INTENT" if current[0]==effect_hash else "HOLD_SCOPE_CONFLICT"
            else:
                self.db.execute("INSERT INTO intents VALUES (?,?,?,?)",(day,scope,effect_hash,"UNKNOWN_NOT_DISPATCHED"))
                result="LOCAL_RESERVATION_ONLY_NO_PROVIDER_ADMISSION"
            self.db.execute("COMMIT")
            return result
        except BaseException:
            self.db.execute("ROLLBACK")
            raise

    def close(self):
        self.db.close()


def review(snapshot: Mapping[str, Any], day: str, db_file: str,
           drive_manifest_exists: bool=True) -> dict[str,Any]:
    verified=validate_snapshot(snapshot)
    fence=DayFence(db_file)
    try:
        gate=fence.admit_daily(day,verified["canonical_fingerprint"],drive_manifest_exists)
    finally:
        fence.close()
    return {"schema":SCHEMA,"day":day,"status":"LOCAL_AUDIT_NO_NATIVE_EFFECT",
            "daily_gate":gate,"manifest_id":f"{DAILY_ID_PREFIX}-{day}",
            "fingerprint_sha256":verified["canonical_fingerprint"],
            "lanes":verified["lanes"],"configured":23,
            "enabled":verified["enabled_count"],"disabled":verified["disabled_count"],
            "schedule_changed":False,"provider_ack":False,"native_verified":False,
            "external_durable_atomicity":"NOT_PROVEN", "exact_drive_readback":"NOT_EXECUTED_BY_THIS_CODE"}


def main():
    p=argparse.ArgumentParser()
    p.add_argument("snapshot",type=Path)
    p.add_argument("--day",required=True)
    p.add_argument("--db",default="fleet_review.sqlite3")
    p.add_argument("--no-prior-drive-manifest",action="store_true")
    p.add_argument("--out",type=Path)
    args=p.parse_args()
    data=json.loads(args.snapshot.read_text(encoding="utf-8"))
    result=review(data,args.day,args.db,not args.no_prior_drive_manifest)
    encoded=json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True)
    if args.out:args.out.write_text(encoded+"\n",encoding="utf-8")
    else:print(encoded)


if __name__=="__main__":
    main()
