#!/usr/bin/env python3
"""Separate-process, distinct structural oracle; reads benchmark artifact, not implementation."""
import hashlib
import json
import sys
from pathlib import Path

p=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('benchmark.json')
obj=json.loads(p.read_text())
assert obj['schema']=='deus-fleet-frozen-bench-r2/1'
assert len(obj['results'])==3
assert sorted([x['seed'] for x in obj['results']])==[1401,1402,1403]
def different_oracle_hash(data):
    text=json.dumps(data, ensure_ascii=False, allow_nan=False, sort_keys=True,
                    separators=(',',':')).encode('utf-8')
    weak=0x811c9dc5
    for byte in memoryview(text):
        weak=((weak ^ byte) * 0x01000193) & 0xffffffff
    return f'{weak:08x}', hashlib.sha256(text).hexdigest()

for result in obj['results']:
    weak_left, full_left=different_oracle_hash(result['collision_fixture_left'])
    weak_right, full_right=different_oracle_hash(result['collision_fixture_right'])
    assert weak_left==weak_right==result['collision_digest_weak']
    assert full_left!=full_right
    assert result['collision_sha256_equal'] is False
    assert result['false_dedupe_baseline']==1 and result['false_dedupe_candidate']==0
    assert result['same_day_reuse']==48
    assert result['same_day_new_run_denied'] is True
    assert result['cold_reopen_denied'] is True
    assert result['effect_changed_id_denied'] is True
    assert result['native']=='NOT_EXECUTED'
    assert 0<result['collision_found_after']<=280000
    for key in ('weak_hash_us_per_input','strong_hash_us_per_input'):
        assert 0<result[key]['p50']<=result[key]['p95']
print(json.dumps({"qa":"PASS_SEPARATE_PROCESS_LOCAL","cases":len(obj['results']),"source_sha256":hashlib.sha256(p.read_bytes()).hexdigest()}))
