# DEUS Daily Fleet Evolution — transactional review gate R2 (public S0)

**Status:** Runnable and tested only in a local isolated environment. Not installed in ChatGPT Automations, Brain1–8, Railway, B7 or Workspace. No execution authority is created by this code.

Goal: make the already-configured daily review of **exactly 23 owner-supplied task IDs** robust against false attribution, duplicate review, schedule drift and weak-digest collisions, without creating a new scheduler. This is an optional review/validation sidecar, **not** an additional cron/worker. Source-of-record stays with owner Google Drive; scheduler settings stay at the provider; targets and native receipts require their own admission.

## Logic

1. Input is an explicit private owner manifest of 23 exact IDs (15 DEUS + 8 Workspace), observed provider metadata and full prompt preimages. It **rejects** missing, foreign or duplicate IDs, disables never self-activate, and verifies known minute staggering and hourly schedule only.
2. For each role, evidence tracks `CONFIGURED`, `ENABLED`, `scheduler_last_run_observed`, `ACTUALLY_EXECUTED`, and `NATIVE_VERIFIED` separately. `last_run_time` alone cannot promote execution.
3. Frozen typed manifest SHA-256 is compared by exact bytes, not a substring or weak 32-bit hash. Explicit same-day Drive manifest means **REUSE** instead of a second fleet evolution wave. A changed same-day fingerprint means source review only, no second effect.
4. Local SQLite `BEGIN IMMEDIATE`, unique `(day,scope)` effect-intent rows and cold-reopen tests enforce a single **local** reservation and hold changed/uncertain effects. This does not provide distributed atomicity or exactly-once external side effects. Production would need a trusted shared writer/lease, target-side idempotency/CAS and readback.
5. A native candidate is not eligible solely because the result appears in logs/CI/Drive; pinned version, target admission, signed lease, output-bound target receipt, independent negative regression, cold recovery, rollback and exact Drive readback are separate gates. Even when the packet is apparently complete, the offline classifier says `...UNVERIFIED_TARGET`.
6. There are no external calls, scheduler updates, Secrets/Memory/Core writes, or provider mutations. No effect denied as `REJECTED` or `POLICY_DENIED` is replayed, even with alternate identity.

## Run (public demo)

```bash
cd deus_fleet_evolution_r2
python3 -m unittest discover -v -p 'test*.py'
python3 bench_fleet.py
python3 qa_verify.py benchmark.json
```

## Current limitations

* Demonstration uses **fake task IDs**, not owner's actual prompt bodies. Applying it to owner tasks requires a legitimate scope-approved canonical read plus fresh provider metadata, never new privilege.
* Default `drive_manifest_exists=True` marks reuse without proving SHA equality with the existing Drive daily row. No second-wave write or side effect is admitted. Prior Drive preimage hash/readback remains a separate required gate.
* This code does not replace an atomic host-side fence or existing native `DEUS_IMPLEMENTATION_CLOSURE_LAW_V1`. It provides zero production-performance or physical-capacity credit.
* No auto-install, CI trigger, scheduled execution, new cron, provider service, power/quota, or spend.

## Rationale / official docs

- [Google Cloud Scheduler: at-least-once delivery requires idempotent handlers](https://docs.cloud.google.com/scheduler/docs/overview)
- [Temporal scheduling / overlap policies](https://github.com/temporalio/documentation/blob/main/docs/encyclopedia/workflow/schedule.mdx)
- [AWS Step Functions best practices for idempotent tasks and audits](https://docs.aws.amazon.com/step-functions/latest/dg/sfn-best-practices.html)

## Rollback

Remove only the optional R2 sidecar, its *local* demo SQLite/benchmark files, and any added review overlay. Preserve owner scheduler IDs, prompts, cadence, enabled state, Drive daily manifest, all native HOLD/FAIL/POLICY_DENIED scars, and production code and resources. No production restoration is required because none is modified.
