"""Fully synthetic tests; real provider scheduler states not used as mock native receipts."""
import copy
import datetime as dt
import hashlib
import json
import random
import sqlite3
import tempfile
import unittest
from pathlib import Path

from fleet_kernel import (SCHEMA, DEUS_MINUTES, WORKSPACE_ROLES, ContractError,
                          DayFence, canon, classify_task, digest, fprint_legacy,
                          qualify_native, review, validate_snapshot)

ROLE_MIN={"Nguon":0,"UI":5,"Backend":13,"AIResearch":21,"OSS":35,"DieuPhoi":31,"QA":47,"TienDo":51}

def fake_snapshot():
    roles=sorted(set(DEUS_MINUTES)|{f"WS/{r}" for r in WORKSPACE_ROLES})
    tasks=[];expected={}
    for i,role in enumerate(roles):
        task_id=hashlib.md5(f"public-demo-{role}".encode()).hexdigest()
        expected[role]=task_id
        minute=DEUS_MINUTES[role] if role in DEUS_MINUTES else ROLE_MIN[role[3:]]
        task={"id":task_id,"title":"PUBLIC_S0_GENERIC_TASK", "prompt":"SAFE_DEMO_NO_EFFECT",
          "schedule":f"BEGIN:VEVENT\nDTSTART;TZID=Asia/Ho_Chi_Minh:20261010T08{minute:02d}00\nRRULE:FREQ=HOURLY\nEND:VEVENT",
          "default_timezone":"Asia/Ho_Chi_Minh", "timing_mode":"exact_schedule",
          "notifications_enabled":False,"email_enabled":False,
          "is_enabled":i<14,"last_run_time":"2026-10-14T06:00:00Z" if i<14 else None}
        tasks.append(task)
    return {"schema":SCHEMA,"expected_ids":expected,"tasks":tasks}

class FleetTests(unittest.TestCase):
    def test_one_case(self):
        r=validate_snapshot(fake_snapshot());self.assertEqual((r["count"],r["enabled_count"],r["disabled_count"]),(23,14,9))
    def test_shuffle_stable(self):
        a=fake_snapshot(); b=copy.deepcopy(a);random.Random(75).shuffle(b["tasks"])
        self.assertEqual(validate_snapshot(a)["canonical_fingerprint"],validate_snapshot(b)["canonical_fingerprint"])
    def test_wrong_id_fails(self):
        a=fake_snapshot();a["tasks"][0]["id"]="0"*32
        with self.assertRaises(ContractError): validate_snapshot(a)
    def test_duplicate_id_fails(self):
        a=fake_snapshot();a["tasks"][0]=a["tasks"][1]
        with self.assertRaises(ContractError): validate_snapshot(a)
    def test_added_unrelated_fails(self):
        a=fake_snapshot();a["tasks"].append(dict(a["tasks"][0],id="1"*32))
        with self.assertRaises(ContractError):validate_snapshot(a)
    def test_missing_member_fails(self):
        a=fake_snapshot();a["tasks"].pop()
        with self.assertRaises(ContractError):validate_snapshot(a)
    def test_invalid_bool_fails(self):
        a=fake_snapshot();a["tasks"][0]["is_enabled"]="false"
        with self.assertRaises(ContractError):validate_snapshot(a)
    def test_disabled_does_not_auto_enable(self):
        a=fake_snapshot();r=validate_snapshot(a);self.assertEqual(sum(x["enabled"] for x in r["lanes"]),14)
        self.assertEqual({x["disable_cause"] for x in r["lanes"] if not x["enabled"]},{"UNKNOWN"})
    def test_last_run_not_native(self):
        a=fake_snapshot();r=validate_snapshot(a)
        self.assertFalse(any(x["native_verified"] or x["actually_executed"] for x in r["lanes"]))
    def test_schedule_wrong_minute(self):
        a=fake_snapshot();a["tasks"][0]["schedule"]=a["tasks"][0]["schedule"].replace("20261010T08","20261010T09")
        # Changing hour is allowed by this profile: no declaration of absolute hour for hourly lanes.
        self.assertEqual(validate_snapshot(a)["count"],23)
        r=next(x for x in a["tasks"] if x["id"]==a["expected_ids"]["DEUS01"])
        r["schedule"]=r["schedule"].replace("T093100","T093200")
        with self.assertRaises(ContractError):validate_snapshot(a)
    def test_schedule_daily_denied(self):
        a=fake_snapshot();a["tasks"][0]["schedule"]=a["tasks"][0]["schedule"].replace("FREQ=HOURLY","FREQ=DAILY")
        with self.assertRaises(ContractError):validate_snapshot(a)
    def test_workplace_schedule_minute_drift(self):
        a=fake_snapshot();t=next(x for x in a["tasks"] if x["id"]==a["expected_ids"]["WS/UI"])
        t["schedule"]=t["schedule"].replace("T080500", "T080600")
        with self.assertRaises(ContractError): validate_snapshot(a)
    def test_byminute_drift(self):
        a=fake_snapshot();t=next(x for x in a["tasks"] if x["id"]==a["expected_ids"]["WS/UI"])
        t["schedule"]=t["schedule"].replace("FREQ=HOURLY", "FREQ=HOURLY;BYMINUTE=6")
        with self.assertRaises(ContractError):validate_snapshot(a)
    def test_extra_interval_denied(self):
        a=fake_snapshot();t=a["tasks"][0]
        t["schedule"]=t["schedule"].replace("FREQ=HOURLY", "FREQ=HOURLY;INTERVAL=2")
        with self.assertRaises(ContractError):validate_snapshot(a)
    def test_prompt_missing_denied(self):
        a=fake_snapshot();a["tasks"][0].pop("prompt")
        with self.assertRaises(ContractError):validate_snapshot(a)
    def test_seconds_drift(self):
        a=fake_snapshot();a["tasks"][0]["schedule"]=a["tasks"][0]["schedule"].replace("FREQ=HOURLY", "FREQ=HOURLY;BYSECOND=3")
        with self.assertRaises(ContractError):validate_snapshot(a)
    def test_wrong_timezone(self):
        a=fake_snapshot();a["tasks"][0]["default_timezone"]="Asia/Bangkok";a["tasks"][0]["schedule"]=a["tasks"][0]["schedule"].replace("Asia/Ho_Chi_Minh","Asia/Bangkok")
        with self.assertRaises(ContractError):validate_snapshot(a)
    def test_naive_timestamp(self):
        a=fake_snapshot();a["tasks"][0]["last_run_time"]="2026-10-14T06:00:00"
        with self.assertRaises(ContractError):validate_snapshot(a)
    def test_notification_change(self):
        a=fake_snapshot();a["tasks"][0]["notifications_enabled"]=True
        with self.assertRaises(ContractError):validate_snapshot(a)
    def test_prompt_tamper_affects_hash(self):
        a=fake_snapshot();b=copy.deepcopy(a);b["tasks"][0]["prompt"]+="CHANGED"
        self.assertNotEqual(validate_snapshot(a)["canonical_fingerprint"],validate_snapshot(b)["canonical_fingerprint"])
    def test_fence_sequences(self):
        with tempfile.TemporaryDirectory() as td:
            p=str(Path(td)/"f.db")
            f=DayFence(p);d="2026-10-14";a=digest({"x":1});b=digest({"x":2})
            self.assertEqual(f.admit_daily(d,a,True),"REUSE_CANONICAL_DRIVE_DAY")
            self.assertEqual(f.admit_daily(d,a,True),"REUSE_SAME_DAY")
            self.assertEqual(f.admit_daily(d,b,True),"SOURCE_DELTA_SAME_DAY_REVIEW_ONLY")
            self.assertEqual(f.reserve_intent(d,"SCOPE1",a),"LOCAL_RESERVATION_ONLY_NO_PROVIDER_ADMISSION")
            self.assertEqual(f.reserve_intent(d,"SCOPE1",a),"NO_REPLAY_SAME_INTENT")
            self.assertEqual(f.reserve_intent(d,"SCOPE1",b),"HOLD_SCOPE_CONFLICT")
            f.close();g=DayFence(p)
            self.assertEqual(g.reserve_intent(d,"SCOPE1",a),"NO_REPLAY_SAME_INTENT");g.close()
    def test_fence_bad_day(self):
        with tempfile.TemporaryDirectory() as td:
            f=DayFence(str(Path(td)/"f.db"))
            with self.assertRaises(ContractError):f.admit_daily("2026-02-30",digest({"x":1}),False)
            f.close()
    def test_native_requires_all_gates(self):
        self.assertEqual(qualify_native({"target_ack":True})[0],"NATIVE_HOLD")
        self.assertEqual(qualify_native({"effect_state":"UNKNOWN"})[0],"NO_REPLAY")
        self.assertEqual(qualify_native({"effect_state":"POLICY_DENIED"})[0],"NO_REPLAY")
        self.assertEqual(qualify_native({"effect_state":"REJECTED"})[0],"NO_REPLAY")
    def test_no_launder_native(self):
        from fleet_kernel import REQUIRED_EVIDENCE
        evidence={k:True for k in REQUIRED_EVIDENCE};evidence["verification_job"]="same";evidence["production_job"]="same"
        self.assertEqual(qualify_native(evidence)[0],"NATIVE_HOLD")
    def test_daily_manifest_existing(self):
        with tempfile.TemporaryDirectory() as td:
            a=review(fake_snapshot(),"2026-10-14",str(Path(td)/"f.db"),True)
            self.assertEqual(a["daily_gate"],"REUSE_CANONICAL_DRIVE_DAY")
            self.assertFalse(a["native_verified"])
    def test_all_negative_mutations(self):
        src=fake_snapshot();rnd=random.Random(777);count=0
        for _ in range(1000):
            a=copy.deepcopy(src)
            task=rnd.choice(a["tasks"])
            choose=rnd.randrange(6)
            if choose==0: task["is_enabled"]="true"
            elif choose==1: task["id"]="0"*32
            elif choose==2: task["default_timezone"]="UTC";task["schedule"]=task["schedule"].replace("Asia/Ho_Chi_Minh","UTC")
            elif choose==3: task["schedule"]=task["schedule"].replace("FREQ=HOURLY","FREQ=DAILY")
            elif choose==4: task["last_run_time"]="NOT_TIME"
            else: task["notifications_enabled"]=True
            with self.assertRaises(ContractError):validate_snapshot(a)
            count+=1
        self.assertEqual(count,1000)

if __name__=="__main__": unittest.main(verbosity=2)
