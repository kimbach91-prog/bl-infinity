#!/usr/bin/env python3
"""Frozen public tests, local-only performance; 3 process seeds. No provider dispatch."""
import hashlib
import json
import os
import random
import statistics
import tempfile
import time
from pathlib import Path
from fleet_kernel import DayFence, digest, fprint_legacy, canon, validate_snapshot
from test_fleet_kernel import fake_snapshot

def pct(a,n):
    return sorted(a)[round((len(a)-1)*n/100)]

def run(seed):
    rnd=random.Random(seed)
    a=fake_snapshot();valid=validate_snapshot(a)
    base={"schema":"public-envelope","day":"2026-10-14", "roster":valid["canonical_fingerprint"]}
    seen={}
    collision=None
    for ix in range(280000):
        obj={**base,"epoch":rnd.getrandbits(72)}
        weak=fprint_legacy(obj)
        if weak in seen and seen[weak] != obj:
            collision=(seen[weak],obj,weak)
            break
        seen[weak]=obj
    if not collision:
        raise AssertionError("FNV32_COLLISION_NOT_FOUND")
    p,q,old=collision
    assert fprint_legacy(p)==fprint_legacy(q)==old
    assert digest(p)!=digest(q)
    # Freeze inputs; paired timings include canonical serialization; equal contract.
    cases=[{**base,"epoch":rnd.getrandbits(72)} for _ in range(256)]
    weak_times=[];strong_times=[]
    for repeat in range(36):
        order = (0,1) if repeat%2 else (1,0)
        for which in order:
            t=time.perf_counter_ns()
            for case in cases:
                (fprint_legacy(case) if which==0 else digest(case))
            elapsed=(time.perf_counter_ns()-t)/len(cases)/1000  # microseconds/hash
            (weak_times if which==0 else strong_times).append(elapsed)
    with tempfile.TemporaryDirectory() as td:
        fence=str(Path(td)/"f.db")
        gate=DayFence(fence)
        first=gate.admit_daily("2026-10-14",valid["canonical_fingerprint"],True)
        after=[gate.admit_daily("2026-10-14",valid["canonical_fingerprint"],True) for _ in range(48)]
        # Same local day, distinct fingerprint must not authorize a second daily review.
        conflict=gate.admit_daily("2026-10-14",digest(p),True)
        reserved=gate.reserve_intent("2026-10-14","CONTROLLER",digest(p))
        no_replay=gate.reserve_intent("2026-10-14","CONTROLLER",digest(p))
        changed=gate.reserve_intent("2026-10-14","CONTROLLER",digest(q))
        gate.close()
        fresh=DayFence(fence);cold=fresh.reserve_intent("2026-10-14","CONTROLLER",digest(p));fresh.close()
    assert first=="REUSE_CANONICAL_DRIVE_DAY"
    assert all(x=="REUSE_SAME_DAY" for x in after)
    assert conflict=="SOURCE_DELTA_SAME_DAY_REVIEW_ONLY"
    assert reserved=="LOCAL_RESERVATION_ONLY_NO_PROVIDER_ADMISSION"
    assert changed=="HOLD_SCOPE_CONFLICT" and no_replay==cold=="NO_REPLAY_SAME_INTENT"
    return {"seed":seed,"collision_found_after":ix+1,"collision_fn":"FNV1a32 illustrative, not cryptographic identity","collision_digest_weak":old,
      "collision_sha256_equal":False, "collision_fixture_left":p,
      "collision_fixture_right":q, "false_dedupe_baseline":1,"false_dedupe_candidate":0,
      "same_day_reuse":48,"same_day_new_run_denied":True,"effect_same_id_replay_denied":True,
      "effect_changed_id_denied":True,"cold_reopen_denied":True,
      "weak_hash_us_per_input":{"p50":pct(weak_times,50),"p95":pct(weak_times,95)},
      "strong_hash_us_per_input":{"p50":pct(strong_times,50),"p95":pct(strong_times,95)},
      "hash_workload_cases":256,"timed_repetitions":36,
      "native":"NOT_EXECUTED","provider_time":"NOT_MEASURED"}

if __name__=='__main__':
    seeds=(1401,1402,1403)
    results=[run(x) for x in seeds]
    out={"schema":"deus-fleet-frozen-bench-r2/1","scope":"LOCAL_PUBLIC_S0_NOT_NATIVE",
       "results":results,"case_control":"3 independent processes OR same process when orchestrated externally",
       "limitations":["FNV32 collision proof illustrative; actual Drive FNV implementation not byte-verified",
          "local SQLite BEGIN IMMEDIATE is not a distributed scheduler transaction", "no target ACK, actual daily schedule trigger or external cost measurement",
          "SHA256 digest equality is not a substitute for full content readback or authority"],
       "sources":["https://docs.cloud.google.com/scheduler/docs/overview",
          "https://docs.temporal.io/workflows", "https://docs.aws.amazon.com/step-functions/latest/dg/sfn-best-practices.html"]}
    Path(__file__).with_name('benchmark.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print(json.dumps({"collision_count":len(results),"results":results},indent=2))
