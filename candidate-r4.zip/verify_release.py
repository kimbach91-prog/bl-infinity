"""Integrity-only release verification; not a cryptographic trust certificate."""
import hashlib, json, sys, zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    manifest=json.loads((ROOT/'RELEASE_MANIFEST.json').read_text())
    failures=[]
    for name,expected in manifest['files'].items():
        p=(ROOT/name).resolve()
        if not p.is_relative_to(ROOT) or not p.is_file() or digest(p)!=expected:
            failures.append(name)
    upstream=json.loads((ROOT/'upstream/r51/SOURCE_SHA256.json').read_text())
    # Preserve the predecessor's actual schema rather than pretending it is this manifest.
    entries=upstream.get('files',upstream)
    if type(entries) is not dict:raise ValueError('unsupported predecessor manifest schema')
    for name,expected in entries.items():
        p=(ROOT/'upstream/r51'/name).resolve()
        if not p.is_relative_to(ROOT/'upstream/r51') or not p.is_file() or digest(p)!=expected:
            failures.append('upstream:'+name)
    original=ROOT/'source/DEUS_CHESS_R51_SOURCE_RECONSTRUCTION_20261017.zip'
    if digest(original)!='520c8deb919a3f886b56ecd36d2807ade3f437098881595919c7e9fdd5b06861':failures.append('original-archive')
    with zipfile.ZipFile(original) as z:
        bad=z.testzip()
        if bad:failures.append('original-zip-crc:'+bad)
    from kernel import check_pins
    source_id=check_pins()
    result={'ok':not failures,'release_files_checked':len(manifest['files']),
      'predecessor_entries_checked':len(entries),'source_id':source_id,'failures':failures,
      'native_admission':False,'private_core_included':False,'third_party_certificate':False}
    print(json.dumps(result,sort_keys=True))
    return 1 if failures else 0
if __name__=='__main__':sys.exit(main())
