"""Deterministic source-scoped test corpus; not a native-world or AGI benchmark."""
from __future__ import annotations
import copy, hashlib, json
from pathlib import Path

FAMILIES=('evidence','metadata','backchain','forecast_reflex','placement','mapping')

def payload(family,n=0):
    if family=='evidence':
        records=[]
        for i in range(12):
            status=['PASS','FAIL','UNKNOWN'][i%3]
            records.append({'id':f'sample_{n}_{i}','source':'LiveBus:WORKSPACE_CODEX_20261012!A289:H289',
               'version':'R6_PUBLIC_FIXTURE','data_class':'PUBLIC','status':status,
               'scar':'' if status=='PASS' else 'synthetic controlled negative',
               'content':f'public fixture {n}: repeated provenance '+('abcd'*80)+str(i)})
        return {'records':records+copy.deepcopy(records)}
    if family=='metadata':
        cards=[]
        for i in range(24):
            cards.append(dict(id=f'source_{n}_{i:02}',label=('Delta compiler' if i%2==0 else 'Map evaluator'),
              family='F04' if i%2==0 else 'F14',lineage_root=f'root_{i//2:02}',
              source_kind='DRIVE_METADATA' if i%2==0 else 'LIVEBUS_TAB',
              principal='PHD' if i==22 else 'BACH',source_date='2026-10-17',
              aliases=['Memory Search'] if i%2==0 else ['Reversible Map'],state='METADATA_ONLY'))
        return dict(cards=cards,query='Memory Search',families=['F04'])
    if family=='backchain':
        links=[[f's{i}',f's{i+1}'] for i in range(10)]
        if n%4!=0:links += [['s0','a'],['a','b'],['b','s10']]
        return dict(start='s0',goal='s10',transitions=links,max_depth=6 if n%4==0 else 12)
    if family=='forecast_reflex':
        step=n%5;vals=[n+i*step for i in range(12)]
        if n%4==0:vals[-1]+=20
        return dict(ticks=list(range(12)),values=vals,as_of=11,horizon=2,tolerance=2,threshold=3,refractory=1)
    if family=='placement':
        nodes=[dict(name=f'node{i}',capacity=[2+i,2048*(i+1),0,4096,100,100],
                latency_ms=5+i,cost_microunits=i+1,healthy=i!=0,freshness='CURRENT_SYNTHETIC',data_class='PUBLIC') for i in range(8)]
        return dict(nodes=nodes,required=[4,4096,1 if n%5==0 else 0,100,10,10],max_latency_ms=20,max_cost_microunits=10)
    if family=='mapping':
        size=8+n%24
        return dict(source_domain='state_A',target_domain='state_B',forward={f'a{i}':f'b{i}' for i in range(size)},
           source_invariants={f'a{i}':f'class_{i%3}' for i in range(size)},target_invariants={f'b{i}':f'class_{i%3}' for i in range(size)},
           source_transition={f'a{i}':f'a{(i+1)%size}' for i in range(size)},target_transition={f'b{i}':f'b{(i+1)%size}' for i in range(size)})
    raise ValueError(family)

def task(family,n=0,tag='test'):
    return {'schema':'deus-one-public-task/1','task_id':f'{tag}.{family}.{n}',
      'subject':'BACH','data_class':'PUBLIC','effect':'PURE','family':family,'payload':payload(family,n),
      'context_sha256':hashlib.sha256(f'PUBLIC-CONTEXT-{n}'.encode()).hexdigest(),
      'idempotency_key':f'{tag}.{family}.{n}'}

def corpus():return [task(f,n,'bench') for n in range(20) for f in FAMILIES]

def workflow(tag='selected_source_plan'):
    cards=[]
    for i,label in enumerate(['Memory Search','Mapping Context']):
        cards.append(dict(id=f'source_{i}',label=label,family='F04',lineage_root=f'root_{i}',source_kind='DRIVE_METADATA',principal='BACH',source_date='UNKNOWN',aliases=[],state='METADATA_ONLY'))
    return dict(schema='deus-one-public-dag/1',workflow_id=tag,context_sha256=hashlib.sha256(b'PUBLIC SYNTHETIC PLANNING').hexdigest(),steps=[
        dict(id='find',family='metadata',payload=dict(cards=cards,query='Memory Search',families=['F04']),depends_on=[],bindings=[]),
        dict(id='trace',family='backchain',payload=dict(start='source_0',goal='verified_result',transitions=[['source_0','analyze'],['analyze','verified_result'],['source_1','map'],['map','analyze']],max_depth=8),depends_on=['find'],bindings=[dict(from_step='find',output_pointer='/search/items/0/id',payload_pointer='/start')]),
        dict(id='record',family='evidence',payload=dict(records=[dict(id='selected-source',source='LiveBus:WORKSPACE_CODEX_20261012!A289:H289',version='R6_SYNTHETIC',data_class='PUBLIC',status='UNKNOWN',scar='metadata is not source/runtime proof',content='placeholder')]),depends_on=['find'],bindings=[dict(from_step='find',output_pointer='/lineage/lineage_roots/0',payload_pointer='/records/0/content')])
    ])
