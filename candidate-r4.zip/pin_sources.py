"""Developer release step only; never called by runtime or benchmark."""
from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent
mods=['__init__.py','contract.py','languages.py','compress_r3.py','forecast_r3.py','mapping.py','supersearch_r4.py','reflex_r3.py','resources_r4.py']
files={}
for m in mods:
 p=r/'upstream/r51/upstream/r41/deus_one'/m
 files[p.relative_to(r).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
for m in ['adapters.py','kernel.py','compose.py','independent_verifier.py']:
 p=r/m;files[m]=hashlib.sha256(p.read_bytes()).hexdigest()
obj={'schema':'deus-one-local-public-source-bindings/1','source_archive_sha256':'520c8deb919a3f886b56ecd36d2807ade3f437098881595919c7e9fdd5b06861','source_archive_drive_id':'1AldX3N5WaTc9e_NotnFg4vc6PQ51yHW2','private_native_binding':False,'neural_weights':False,'files':files}
(r/'SOURCE_BINDINGS.json').write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
