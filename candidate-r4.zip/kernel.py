"""DEUS-ONE composition runner R6: a local consumer of pinned PUBLIC R4.1 code.

NOT private DEUS Core, a neural model, a fleet controller, or website deployment.
Only bounded PURE PUBLIC requests are admitted here. No engine substitution.
"""
from __future__ import annotations
import contextlib, fcntl, hashlib, json, os, re, select, sqlite3, subprocess, sys, time, uuid, zlib
from pathlib import Path
from typing import Any

ROOT=Path(__file__).resolve().parent
VERSION='DEUS-ONE-PUBLIC-COMPOSITION-R6.2'
REQUIRED={'schema','task_id','subject','data_class','effect','family','payload','context_sha256','idempotency_key'}
TOKEN=re.compile(r'^[A-Za-z0-9_.:-]{1,128}$')
MAX_BYTES=900_000

def canonical(x: Any)->bytes:
    return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def sha(x: Any)->str:return hashlib.sha256(canonical(x)).hexdigest()
class AdmissionError(ValueError):pass
class IntegrityError(ValueError):pass
class SimulatedCrash(RuntimeError):pass

def validate_request(x: Any)->dict:
    if type(x) is not dict or set(x)!=REQUIRED:raise AdmissionError('SCHEMA: exact request keys required')
    if x['schema']!='deus-one-public-task/1':raise AdmissionError('SCHEMA_VERSION')
    if x['subject']!='BACH' or x['data_class']!='PUBLIC' or x['effect']!='PURE':raise AdmissionError('PUBLIC_PURE_SCOPE_ONLY')
    if any(type(x[k]) is not str or not TOKEN.fullmatch(x[k]) for k in ('task_id','idempotency_key')):raise AdmissionError('IMMUTABLE_ID')
    if type(x['context_sha256']) is not str or not re.fullmatch('[0-9a-f]{64}',x['context_sha256']):raise AdmissionError('CONTEXT_PIN')
    if x['family'] not in adapters.FAMILIES:raise AdmissionError('UNBOUND_ADAPTER')
    # Native authority/credentials cannot be passed as extra request fields.
    data=canonical(x)
    if len(data)>MAX_BYTES:raise AdmissionError('PAYLOAD_BUDGET')
    adapters.validate_payload(x['family'],x['payload'])
    return json.loads(data)

def check_pins()->str:
    try:
        pins=json.loads((ROOT/'SOURCE_BINDINGS.json').read_text())
        if type(pins) is not dict or type(pins.get('files')) is not dict or not pins['files']:
            raise IntegrityError('SOURCE_BINDINGS_SCHEMA')
        if pins['source_archive_sha256']!='520c8deb919a3f886b56ecd36d2807ade3f437098881595919c7e9fdd5b06861':raise IntegrityError('UPSTREAM_ARCHIVE_ID')
        for path,expected in pins['files'].items():
            if type(path) is not str or type(expected) is not str or not re.fullmatch('[0-9a-f]{64}',expected):
                raise IntegrityError('SOURCE_BINDINGS_SCHEMA')
            p=(ROOT/path).resolve()
            if not p.is_relative_to(ROOT) or not p.is_file():raise IntegrityError('SOURCE_MISSING')
            if hashlib.sha256(p.read_bytes()).hexdigest()!=expected:raise IntegrityError('SOURCE_PIN_MISMATCH:'+path)
        return sha(pins)
    except IntegrityError:
        raise
    except (OSError,ValueError,KeyError,TypeError) as exc:
        raise IntegrityError('SOURCE_BINDINGS_INVALID:'+type(exc).__name__) from exc

# Verify dependencies before their module bodies are imported. Keep the CLI's
# existing structured rejection and exit code for source-integrity failures.
try:
    _BOOT_SOURCE_ID=check_pins()
    import adapters
except IntegrityError as exc:
    if __name__=='__main__':
        print(json.dumps({'state':'REJECTED','reason':str(exc),'native_core':False}))
        sys.exit(2)
    raise

class VerifierClient:
    def __init__(self):
        env={'PATH':os.environ.get('PATH','/usr/bin:/bin'),'PYTHONHASHSEED':'0','PYTHONDONTWRITEBYTECODE':'1'}
        self.expected_hash=hashlib.sha256((ROOT/'independent_verifier.py').read_bytes()).hexdigest()
        self.proc=subprocess.Popen([sys.executable,'-I',str(ROOT/'independent_verifier.py')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,bufsize=0)
        self.buffer=b''
    def verify(self,family,payload,result):
        qid=uuid.uuid4().hex
        payload_bytes=canonical(dict(id=qid,family=family,payload=payload,result=result))+b'\n'
        if len(payload_bytes)>2_000_000:raise IntegrityError('VERIFIER_BOUND')
        self.proc.stdin.write(payload_bytes);self.proc.stdin.flush()
        deadline=time.monotonic()+5
        while b'\n' not in self.buffer:
            left=deadline-time.monotonic()
            if left<=0:raise IntegrityError('VERIFIER_TIMEOUT')
            readable,_,_=select.select([self.proc.stdout],[],[],left)
            if not readable:raise IntegrityError('VERIFIER_TIMEOUT')
            block=os.read(self.proc.stdout.fileno(),65536)
            if not block:raise IntegrityError('VERIFIER_EXITED')
            self.buffer+=block
        line,self.buffer=self.buffer.split(b'\n',1)
        response=json.loads(line)
        if response.get('id')!=qid or response.get('pid')!=self.proc.pid or response.get('verifier_source_sha256')!=self.expected_hash:
            raise IntegrityError('VERIFIER_IDENTITY')
        if not response.get('ok'):raise IntegrityError('SEMANTIC_REJECTION:'+response.get('error','unknown'))
        if response.get('result_sha256')!=sha(result):raise IntegrityError('VERIFIER_RESULT_MISMATCH')
        return response
    def close(self):
        if self.proc.poll() is None:
            self.proc.stdin.close()
            try:self.proc.wait(timeout=2)
            except subprocess.TimeoutExpired:self.proc.kill();self.proc.wait()
        self.proc.stdout.close();self.proc.stderr.close()
    def __enter__(self):return self
    def __exit__(self,*exc):self.close()

class Kernel:
    def __init__(self, store: str|Path, cache_ttl:float=300):
        if not isinstance(cache_ttl,(int,float)) or not 0<cache_ttl<=3600:raise ValueError('TTL bound')
        self.path=Path(store).resolve();self.path.parent.mkdir(parents=True,exist_ok=True)
        self.ttl=cache_ttl;self.source_id=check_pins()
        if self.source_id!=_BOOT_SOURCE_ID:raise IntegrityError('SOURCE_GENERATION_CHANGED_SINCE_IMPORT')
        # Keep one connection per runner. FULL synchronous durability and transactions are unchanged.
        # A new database needs the same process lock as task execution: journal
        # mode and schema setup must not race a second runner's initialization.
        with self.lock():
            self._conn=sqlite3.connect(str(self.path),timeout=10)
            try:
                self._conn.execute('PRAGMA journal_mode=WAL')
                self._conn.execute('PRAGMA synchronous=FULL')
                with self.db() as db:
                    db.executescript('''
                    CREATE TABLE IF NOT EXISTS jobs(task_id TEXT PRIMARY KEY, request_hash TEXT NOT NULL,
                      cache_key TEXT NOT NULL, state TEXT NOT NULL, result_sha TEXT, receipt TEXT, error TEXT);
                    CREATE TABLE IF NOT EXISTS artifacts(sha TEXT PRIMARY KEY, body BLOB NOT NULL, raw_bytes INTEGER NOT NULL);
                    CREATE TABLE IF NOT EXISTS reuse(cache_key TEXT PRIMARY KEY, result_sha TEXT NOT NULL, expires_at REAL NOT NULL);
                    CREATE TABLE IF NOT EXISTS audit(seq INTEGER PRIMARY KEY AUTOINCREMENT,task_id TEXT NOT NULL,event TEXT NOT NULL,detail TEXT NOT NULL);
                    ''')
            except BaseException:
                self._conn.close()
                raise
        try:
            self.verifier=VerifierClient()
        except BaseException:
            self._conn.close()
            raise
    def close(self):
        self.verifier.close()
        self._conn.close()
    def __enter__(self):return self
    def __exit__(self,*exc):self.close()
    @contextlib.contextmanager
    def db(self):
        with self._conn:
            yield self._conn
    @contextlib.contextmanager
    def lock(self):
        with open(str(self.path)+'.lock','ab') as f:
            fcntl.flock(f,fcntl.LOCK_EX)
            try:yield
            finally:fcntl.flock(f,fcntl.LOCK_UN)
    def _audit(self,db,task,event,detail):db.execute('INSERT INTO audit(task_id,event,detail) VALUES(?,?,?)',(task,event,json.dumps(detail,sort_keys=True)))
    def _artifact(self,db,digest):
        found=db.execute('SELECT body,raw_bytes FROM artifacts WHERE sha=?',(digest,)).fetchone()
        if not found or not 0<=found[1]<=2_000_000:raise IntegrityError('ARTIFACT_MISSING_OR_OVERSIZED')
        decoder=zlib.decompressobj();raw=decoder.decompress(found[0],found[1]+1)
        if len(raw)!=found[1] or not decoder.eof or decoder.unused_data or decoder.unconsumed_tail:raise IntegrityError('COMPRESSED_ARTIFACT_BOUND')
        if hashlib.sha256(raw).hexdigest()!=digest:raise IntegrityError('ARTIFACT_DIGEST')
        value=json.loads(raw)
        if canonical(value)!=raw:raise IntegrityError('NONCANONICAL_ARTIFACT')
        return value
    def _check_receipt(self,x,r,receipt,fingerprint):
        """Check the stored local evidence contract; this does not authenticate a native target."""
        fixed={'version':VERSION,'task_id':x['task_id'],'request_hash':fingerprint,
          'context_sha256':x['context_sha256'],'source_id':self.source_id,
          'result_sha256':sha(r),'scope':'LOCAL_PUBLIC_CONTRACT',
          'private_native_calls':0,'model_calls':0,'remote_brain_calls':0,
          'native_target_ack':False,'neural_quality_verified':False}
        if type(receipt) is not dict or set(receipt)!=set(fixed)|{'origin','producer_function_calls','bindings','typed_receipt','verifier','pid'}:
            raise IntegrityError('RECEIPT_SCHEMA')
        for key,value in fixed.items():
            if type(receipt[key]) is not type(value) or receipt[key]!=value:
                raise IntegrityError('RECEIPT_BINDING:'+key)
        if receipt['origin'] not in ('EXECUTED','EXACT_REUSE'):
            raise IntegrityError('RECEIPT_ORIGIN')
        names=(adapters.FUNCTIONS[x['family']] if receipt['origin']=='EXECUTED' else [])+['languages.encode_ir','languages.decode_ir']
        count=receipt['producer_function_calls']
        if type(count) is not int or count!=len(names)-2:
            raise IntegrityError('RECEIPT_CALL_COUNT')
        traces=receipt['bindings']
        if type(traces) is not list or len(traces)!=len(names):raise IntegrityError('RECEIPT_TRACE_COUNT')
        pins=json.loads((ROOT/'SOURCE_BINDINGS.json').read_text())['files']
        fields={'binding','source_file','source_sha256','input_sha256','output_sha256','wall_ns','scope','private_native'}
        for trace,name in zip(traces,names):
            path='upstream/r51/upstream/r41/deus_one/'+name.split('.')[0]+'.py'
            if type(trace) is not dict or set(trace)!=fields:raise IntegrityError('RECEIPT_TRACE_SCHEMA')
            if trace['binding']!=name or trace['source_file']!=path or trace['source_sha256']!=pins.get(path):raise IntegrityError('RECEIPT_TRACE_SOURCE')
            if trace['scope']!='ARCHIVED_PUBLIC_REFERENCE' or trace['private_native'] is not False:raise IntegrityError('RECEIPT_TRACE_SCOPE')
            if type(trace['wall_ns']) is not int or trace['wall_ns']<0:raise IntegrityError('RECEIPT_TRACE_TIME')
            if any(type(trace[k]) is not str or not re.fullmatch('[0-9a-f]{64}',trace[k]) for k in ('input_sha256','output_sha256')):raise IntegrityError('RECEIPT_TRACE_DIGEST')
        typed={'schema':'deus-one-r2-synthetic-datacodec/1','task_id':x['task_id'],
          'role':'tool','data_class':'PUBLIC','effect':'PURE','semantic_type':'TEXT',
          'source_sha256':self.source_id,'value':sha(r)}
        if type(receipt['typed_receipt']) is not dict or canonical(receipt['typed_receipt'])!=canonical(typed):raise IntegrityError('RECEIPT_TYPED_BINDING')
        vr=receipt['verifier']
        vf={'id','ok','pid','result_sha256','verifier','verifier_source_sha256','external_third_party','details'}
        if type(vr) is not dict or set(vr)!=vf:raise IntegrityError('RECEIPT_VERIFIER_SCHEMA')
        if type(receipt['pid']) is not int or receipt['pid']<=0 or type(vr['pid']) is not int or vr['pid']<=0 or receipt['pid']==vr['pid']:raise IntegrityError('RECEIPT_PROCESS_SEPARATION')
        if type(vr['id']) is not str or not re.fullmatch('[0-9a-f]{32}',vr['id']):raise IntegrityError('RECEIPT_VERIFIER_ID')
        if vr['ok'] is not True or vr['result_sha256']!=sha(r) or vr['verifier']!='deus-one-local-semantic-verifier/1' or vr['verifier_source_sha256']!=pins['independent_verifier.py'] or vr['external_third_party'] is not False:
            raise IntegrityError('RECEIPT_VERIFIER_BINDING')
        details={'verified_local_semantics':True,'native_core_verified':False,'forecast_truth_verified':False}
        if type(vr['details']) is not dict or canonical(vr['details'])!=canonical(details):raise IntegrityError('RECEIPT_VERIFIER_SCOPE')
    def run(self,request:dict,*,_fault:str|None=None)->dict:
        start=time.perf_counter_ns();t=start;x=validate_request(request)
        stages={'admission_ns':time.perf_counter_ns()-t}
        t=time.perf_counter_ns();source_id=check_pins();stages['source_pin_ns']=time.perf_counter_ns()-t
        if source_id!=self.source_id:raise IntegrityError('SOURCE_GENERATION_CHANGED_IN_PROCESS')
        env=adapters.CanonicalEnvelope(x['subject'],x['task_id'],x['family'],x['data_class'],x['payload'],x['idempotency_key'],source_revision=source_id)
        # Context is deliberately part of both idempotency and reuse keys, even when payload matches.
        fingerprint=sha({'envelope':env.fingerprint(),'context':x['context_sha256']})
        cache_key=sha({k:v for k,v in x.items() if k not in ('task_id','idempotency_key')}|{'source_id':source_id})
        with self.lock(),self.db() as db:
            old=db.execute('SELECT request_hash,state,result_sha,receipt,error FROM jobs WHERE task_id=?',(x['task_id'],)).fetchone()
            if old and old[0]!=fingerprint:raise AdmissionError('IDEMPOTENCY_CONFLICT')
            if old and old[1] in ('VERIFIED','PREPARED'):
                t=time.perf_counter_ns();r=self._artifact(db,old[2]);vr=self.verifier.verify(x['family'],x['payload'],r)
                stages['reverify_ns']=time.perf_counter_ns()-t
                prior=json.loads(old[3]);self._check_receipt(x,r,prior,fingerprint)
                stages['total_ns']=time.perf_counter_ns()-start
                if old[1]=='PREPARED':
                    db.execute("UPDATE jobs SET state='VERIFIED' WHERE task_id=?",(x['task_id'],))
                    self._audit(db,x['task_id'],'RECOVER_PREPARED_NO_EXECUTOR',{'result_sha':old[2]})
                return self._response(x,r,prior,stages,'IDEMPOTENT_REPLAY' if old[1]=='VERIFIED' else 'RECOVERED_PREPARED',vr)
            if old:
                # Nothing may replay unknown effects. Even these PURE jobs require an explicit checkpoint or new job.
                return {'state':'UNKNOWN_LOCAL_OUTCOME' if old[1]=='RUNNING' else old[1],
                  'task_id':x['task_id'],'error':old[4],'native_core':False,'executor_reinvoked':False}
            db.execute('INSERT INTO jobs(task_id,request_hash,cache_key,state) VALUES(?,?,?,?)',(x['task_id'],fingerprint,cache_key,'RUNNING'));db.commit()
            if _fault=='before_execute':raise SimulatedCrash('test interruption before producer; explicit UNKNOWN retained')
            try:
                t=time.perf_counter_ns();reuse=db.execute('SELECT result_sha,expires_at FROM reuse WHERE cache_key=?',(cache_key,)).fetchone();stages['reuse_lookup_ns']=time.perf_counter_ns()-t
                calls=adapters.Calls();producer_calls=[];origin='EXECUTED'
                if reuse and reuse[1]>time.time():
                    try:r=self._artifact(db,reuse[0]);origin='EXACT_REUSE'
                    except IntegrityError:
                        db.execute('DELETE FROM reuse WHERE cache_key=?',(cache_key,));reuse=None
                        self._audit(db,x['task_id'],'INVALID_CACHE_EVICTED',{})
                else:reuse=None
                t=time.perf_counter_ns()
                if origin!='EXACT_REUSE':
                    self._audit(db,x['task_id'],'PRODUCER_STARTED',{'family':x['family'],'source_id':source_id})
                    r,producer_calls=adapters.run_bound(x['family'],x['payload'],calls)
                    producer_calls=list(producer_calls)
                stages['producer_ns']=time.perf_counter_ns()-t
                t=time.perf_counter_ns();vr=self.verifier.verify(x['family'],x['payload'],r);stages['semantic_verifier_ns']=time.perf_counter_ns()-t
                t=time.perf_counter_ns();typed=adapters.encode_output(x['task_id'],source_id,r,calls);stages['typed_codec_ns']=time.perf_counter_ns()-t
                receipt={'version':VERSION,'task_id':x['task_id'],'request_hash':fingerprint,'context_sha256':x['context_sha256'],
                    'source_id':source_id,'result_sha256':sha(r),'scope':'LOCAL_PUBLIC_CONTRACT',
                    'origin':origin,'producer_function_calls':len(producer_calls),
                    'bindings':calls.trace,'typed_receipt':typed,'verifier':vr,
                    'pid':os.getpid(),'private_native_calls':0,'model_calls':0,'remote_brain_calls':0,
                    'native_target_ack':False,'neural_quality_verified':False}
                self._check_receipt(x,r,receipt,fingerprint)
                t=time.perf_counter_ns();raw=canonical(r);blob=zlib.compress(raw,6)
                stages['storage_encode_ns']=time.perf_counter_ns()-t
                db.execute('INSERT OR IGNORE INTO artifacts(sha,body,raw_bytes) VALUES(?,?,?)',(sha(r),blob,len(raw)))
                db.execute('INSERT OR REPLACE INTO reuse VALUES(?,?,?)',(cache_key,sha(r),time.time()+self.ttl))
                db.execute("UPDATE jobs SET state='PREPARED',result_sha=?,receipt=? WHERE task_id=?",(sha(r),canonical(receipt).decode(),x['task_id']))
                self._audit(db,x['task_id'],'VERIFIED_PREPARED',{'result_sha':sha(r)});db.commit()
                if _fault=='after_prepared':raise SimulatedCrash('test interruption after durable result before final acknowledgment')
                t=time.perf_counter_ns();db.execute("UPDATE jobs SET state='VERIFIED' WHERE task_id=?",(x['task_id'],));db.commit();stages['commit_ns']=time.perf_counter_ns()-t
                stages['total_ns']=time.perf_counter_ns()-start
                return self._response(x,r,receipt,stages,origin,vr)
            except SimulatedCrash:raise
            except Exception as exc:
                db.execute("UPDATE jobs SET state='FAILED',error=? WHERE task_id=?",(type(exc).__name__+': '+str(exc)[:200],x['task_id']))
                self._audit(db,x['task_id'],'FAILED',{'reason':str(exc)[:200]});db.commit()
                raise
    def _response(self,x,r,receipt,stages,origin,vr):
        return {'state':'VERIFIED_LOCAL_CONTRACT','task_id':x['task_id'],'family':x['family'],
           'origin':origin,'output':r,'receipt':receipt,'replay_verifier':vr,
           'stages':stages,'native_core':False,'forecast_truth_verified':False,
           'remote_target_admission':False,'external_third_party_verified':False}
    def snapshot(self,target:Path)->str:
        target=Path(target).resolve()
        if target==self.path or target.exists():raise ValueError('snapshot requires a new destination')
        with self.lock(),self.db() as src:
            dest=sqlite3.connect(str(target))
            try:src.backup(dest)
            finally:dest.close()
        digest=hashlib.sha256(target.read_bytes()).hexdigest()
        target.with_suffix(target.suffix+'.sha256').write_text(digest+'\n')
        return digest
    def audit_counts(self):
        with self.db() as db:return dict(db.execute('SELECT event,count(*) FROM audit GROUP BY event').fetchall())

def restore_snapshot(snapshot:Path,target:Path,expected:str)->None:
    snapshot=Path(snapshot).resolve();target=Path(target).resolve()
    if target.exists() or not re.fullmatch('[0-9a-f]{64}',expected):raise IntegrityError('RESTORE_TARGET_OR_HASH')
    data=snapshot.read_bytes()
    if hashlib.sha256(data).hexdigest()!=expected:raise IntegrityError('SNAPSHOT_DIGEST')
    target.parent.mkdir(parents=True,exist_ok=True)
    with open(target,'xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
    db=sqlite3.connect(str(target))
    try:
        if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise IntegrityError('SQLITE_INTEGRITY')
    finally:db.close()

def main():
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--store',required=True);ap.add_argument('--request',required=True)
    args=ap.parse_args()
    try:
        with Kernel(args.store) as runtime:print(json.dumps(runtime.run(json.loads(Path(args.request).read_text())),ensure_ascii=False,sort_keys=True))
    except Exception as exc:print(json.dumps({'state':'REJECTED','reason':str(exc),'native_core':False}));sys.exit(2)
if __name__=='__main__':main()
