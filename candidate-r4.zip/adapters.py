"""Call archived PUBLIC R4.1 functions unchanged. No native/private substitutions.

This layer is integration glue only. It does not implement the upstream algorithms.
"""
from __future__ import annotations
import dataclasses, hashlib, json, sys, time
from pathlib import Path
from typing import Any, Callable

ROOT = Path(__file__).resolve().parent
VENDOR = ROOT / 'upstream/r51/upstream/r41'
sys.dont_write_bytecode = True
sys.path.insert(0, str(VENDOR))
from deus_one.contract import CanonicalEnvelope, canon
from deus_one.languages import encode_ir, decode_ir
from deus_one.mapping import MappingWitness, certify_finite_map
from deus_one.compress_r3 import exact_evidence_reuse
from deus_one.forecast_r3 import Window, Backchain, forecast_public, backchain_public
from deus_one.reflex_r3 import Signal, simulate_reflex
from deus_one.supersearch_r4 import SourceCard, search_metadata, triangulate
from deus_one.resources_r4 import Vector, Node, Demand, place_public

FAMILIES = ('evidence', 'metadata', 'backchain', 'forecast_reflex', 'placement', 'mapping')
FUNCTIONS = {
 'evidence': ['compress_r3.exact_evidence_reuse'],
 'metadata': ['supersearch_r4.search_metadata', 'supersearch_r4.triangulate'],
 'backchain': ['forecast_r3.backchain_public'],
 'forecast_reflex': ['forecast_r3.forecast_public', 'reflex_r3.simulate_reflex'],
 'placement': ['resources_r4.place_public'],
 'mapping': ['mapping.certify_finite_map'],
}

def clean(x: Any) -> Any:
    return json.loads(json.dumps(x, ensure_ascii=False, sort_keys=True, allow_nan=False))

def _wire(x: Any) -> Any:
    if dataclasses.is_dataclass(x): return _wire(dataclasses.asdict(x))
    if isinstance(x, dict): return {k: _wire(v) for k, v in x.items()}
    if isinstance(x, (tuple, list)): return [_wire(v) for v in x]
    return x

class Calls:
    def __init__(self) -> None:
        self.trace: list[dict] = []
    def call(self, name: str, fn: Callable, *args, **kwargs):
        payload = {'args': _wire(args), 'kwargs': _wire(kwargs)}
        started = time.perf_counter_ns()
        result = fn(*args, **kwargs)
        wall = time.perf_counter_ns() - started
        module_path = Path(sys.modules[fn.__module__].__file__)
        self.trace.append({'binding': name, 'source_file': module_path.relative_to(ROOT).as_posix(),
           'source_sha256': hashlib.sha256(module_path.read_bytes()).hexdigest(),
           'input_sha256': hashlib.sha256(canon(payload)).hexdigest(),
           'output_sha256': hashlib.sha256(canon(_wire(result))).hexdigest(),
           'wall_ns': wall, 'scope': 'ARCHIVED_PUBLIC_REFERENCE', 'private_native': False})
        return result

def validate_payload(family: str, p: dict) -> None:
    required = {
      'evidence': {'records'}, 'metadata': {'cards', 'query', 'families'},
      'backchain': {'start','goal','transitions','max_depth'},
      'forecast_reflex': {'ticks','values','as_of','horizon','tolerance','threshold','refractory'},
      'placement': {'nodes','required','max_latency_ms','max_cost_microunits'},
      'mapping': {'source_domain','target_domain','forward','source_invariants','target_invariants','source_transition','target_transition'},
    }
    if family not in required or type(p) is not dict or set(p) != required[family]:
        raise ValueError('SCHEMA: unknown family or exact payload keys mismatch')
    if family == 'metadata':
        allowed = {'id','label','family','lineage_root','source_kind','principal','source_date','aliases','state'}
        if type(p['cards']) is not list or len(p['cards']) > 180: raise ValueError('metadata bound')
        if any(type(c) is not dict or set(c) != allowed for c in p['cards']): raise ValueError('card schema')
    if family == 'placement':
        allowed = {'name','capacity','latency_ms','cost_microunits','healthy','freshness','data_class'}
        if type(p['nodes']) is not list or len(p['nodes']) > 32: raise ValueError('node bound')
        if any(type(n) is not dict or set(n) != allowed for n in p['nodes']): raise ValueError('node schema')

def run_bound(family: str, p: dict, calls: Calls | None = None) -> tuple[dict, list[dict]]:
    validate_payload(family,p)
    c = calls or Calls()
    if family == 'evidence':
        result = c.call('compress_r3.exact_evidence_reuse', exact_evidence_reuse, p['records'])
    elif family == 'metadata':
        cards = tuple(SourceCard(**{**d, 'aliases': tuple(d['aliases'])}) for d in p['cards'])
        search = c.call('supersearch_r4.search_metadata', search_metadata, cards, p['query'], tuple(p['families']))
        refs = tuple(item['id'] for item in search['items'])
        if len(refs)>24: raise ValueError('HOLD: matched-source evidence exceeds inherited 24-reference bound')
        # The output of search, not a fixed fixture, drives the second operator.
        evidence = c.call('supersearch_r4.triangulate', triangulate, cards, refs)
        result = {'search': search, 'lineage': evidence}
    elif family == 'backchain':
        spec=Backchain(p['start'],p['goal'],tuple(tuple(e) for e in p['transitions']),p['max_depth'])
        result=c.call('forecast_r3.backchain_public',backchain_public,spec)
    elif family == 'forecast_reflex':
        w=Window(tuple(p['ticks']),tuple(p['values']),p['as_of'],p['horizon'],p['tolerance'])
        forecast=c.call('forecast_r3.forecast_public',forecast_public,w)
        # Explicit finite advisory signal transform; not a native BioReflex or probabilistic oracle.
        signals=tuple(Signal(i, min(8,abs(b-a)),0) for i,(a,b) in enumerate(zip(p['values'],p['values'][1:])))
        reflex=c.call('reflex_r3.simulate_reflex',simulate_reflex,signals,p['threshold'],p['refractory'],3)
        result={'forecast':forecast,'reflex':reflex,'action_authorized':False}
    elif family == 'placement':
        nodes=tuple(Node(**{**d,'capacity':Vector(tuple(d['capacity']))}) for d in p['nodes'])
        demand=Demand(Vector(tuple(p['required'])),p['max_latency_ms'],p['max_cost_microunits'])
        result=c.call('resources_r4.place_public',place_public,nodes,demand)
    else:
        w=MappingWitness(**p)
        result=c.call('mapping.certify_finite_map',certify_finite_map,w)
    return clean(result),c.trace

def encode_output(task_id: str, source_hash: str, result: dict, calls: Calls) -> dict:
    # Same archived typed codec; use a digest, not a lossy flattening of arbitrary history.
    packet={'schema':'deus-one-r2-synthetic-datacodec/1','task_id':task_id,
       'role':'tool','data_class':'PUBLIC','effect':'PURE','semantic_type':'TEXT',
       'source_sha256':source_hash,'value':hashlib.sha256(canon(result)).hexdigest()}
    wire=calls.call('languages.encode_ir',encode_ir,packet)
    decoded=calls.call('languages.decode_ir',decode_ir,wire)
    if decoded != packet: raise ValueError('INTEGRITY: typed output codec')
    return decoded
