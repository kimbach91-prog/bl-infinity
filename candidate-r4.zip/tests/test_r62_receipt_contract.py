"""Bounded validation of incomplete local records; no network or modified executable source."""
import ast
import copy
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import kernel
from workloads import task


class ReceiptContractTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.runner=kernel.Kernel(Path(self.tmp.name)/'state.db')
        self.request=task('mapping',3)
        self.response=self.runner.run(self.request)

    def tearDown(self):
        self.runner.close()
        self.tmp.cleanup()

    def check_record(self,record):
        self.runner._check_receipt(self.request,self.response['output'],record,
                                   self.response['receipt']['request_hash'])

    def test_incomplete_request_binding_is_rejected(self):
        record=copy.deepcopy(self.response['receipt'])
        del record['request_hash']
        with self.assertRaisesRegex(kernel.IntegrityError,'RECEIPT_SCHEMA'):
            self.check_record(record)

    def test_inconsistent_context_is_rejected(self):
        record=copy.deepcopy(self.response['receipt'])
        record['context_sha256']='0'*64
        with self.assertRaisesRegex(kernel.IntegrityError,'RECEIPT_BINDING:context_sha256'):
            self.check_record(record)

    def test_call_count_requires_an_integer(self):
        record=copy.deepcopy(self.response['receipt'])
        record['producer_function_calls']=str(record['producer_function_calls'])
        with self.assertRaisesRegex(kernel.IntegrityError,'RECEIPT_CALL_COUNT'):
            self.check_record(record)

    def test_trace_requires_exact_source_reference(self):
        record=copy.deepcopy(self.response['receipt'])
        record['bindings'][0]['source_file']=''
        with self.assertRaisesRegex(kernel.IntegrityError,'RECEIPT_TRACE_SOURCE'):
            self.check_record(record)

    def test_typed_record_must_match_verified_result(self):
        record=copy.deepcopy(self.response['receipt'])
        record['typed_receipt']['value']='0'*64
        with self.assertRaisesRegex(kernel.IntegrityError,'RECEIPT_TYPED_BINDING'):
            self.check_record(record)

    def test_verifier_record_requires_complete_typed_scope(self):
        record=copy.deepcopy(self.response['receipt'])
        del record['verifier']['details']['forecast_truth_verified']
        with self.assertRaisesRegex(kernel.IntegrityError,'RECEIPT_VERIFIER_SCOPE'):
            self.check_record(record)

    def test_dependency_check_precedes_adapter_import_in_boot_block(self):
        tree=ast.parse(Path(kernel.__file__).read_text())
        boot=next(node for node in tree.body if isinstance(node,ast.Try) and
                  any(isinstance(child,ast.Import) and any(a.name=='adapters' for a in child.names)
                      for child in node.body))
        check_index=next(i for i,node in enumerate(boot.body) if isinstance(node,ast.Assign)
                         and isinstance(node.value,ast.Call)
                         and isinstance(node.value.func,ast.Name)
                         and node.value.func.id=='check_pins')
        import_index=next(i for i,node in enumerate(boot.body) if isinstance(node,ast.Import)
                          and any(a.name=='adapters' for a in node.names))
        self.assertLess(check_index,import_index)
        self.assertFalse(any(isinstance(node,ast.Import) and any(a.name=='adapters' for a in node.names)
                             for node in tree.body))


class ManifestReadContractTests(unittest.TestCase):
    """Ordinary unavailable/incomplete input handling, without changing source files."""

    def test_unavailable_manifest_has_integrity_error(self):
        with patch.object(Path,'read_text',side_effect=FileNotFoundError('manifest unavailable')):
            with self.assertRaisesRegex(kernel.IntegrityError,'SOURCE_BINDINGS_INVALID:FileNotFoundError'):
                kernel.check_pins()

    def test_incomplete_json_has_integrity_error(self):
        with patch.object(Path,'read_text',return_value='{'):
            with self.assertRaisesRegex(kernel.IntegrityError,'SOURCE_BINDINGS_INVALID:JSONDecodeError'):
                kernel.check_pins()

    def test_manifest_requires_a_nonempty_file_mapping(self):
        with patch.object(Path,'read_text',return_value='{"files": {}}'):
            with self.assertRaisesRegex(kernel.IntegrityError,'SOURCE_BINDINGS_SCHEMA'):
                kernel.check_pins()


if __name__=='__main__':
    unittest.main()
