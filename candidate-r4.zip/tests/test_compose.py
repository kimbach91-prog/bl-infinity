import copy,json,sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from compose import plan,run_workflow
from kernel import Kernel,AdmissionError
from workloads import workflow

class TestCompose(unittest.TestCase):
 def test_actual_output_drives_next_operator(self):
  with tempfile.TemporaryDirectory() as d, Kernel(Path(d)/'a.db') as k:
   w=workflow();r=run_workflow(k,w)
   self.assertEqual(r['step_results']['trace']['output']['steps'],2)
   self.assertEqual(r['resolved_requests']['trace']['payload']['start'],'source_0')
   w=workflow('other');w['steps'][0]['payload']['query']='Mapping Context'
   r=run_workflow(k,w)
   self.assertEqual(r['step_results']['trace']['output']['steps'],3)
   self.assertEqual(r['resolved_requests']['trace']['payload']['start'],'source_1')
   self.assertFalse(r['native_core'])
 def test_dag_resume_no_duplicate_producers(self):
  with tempfile.TemporaryDirectory() as d, Kernel(Path(d)/'a.db') as k:
   w=workflow();run_workflow(k,w);r=run_workflow(k,w)
   self.assertEqual(k.audit_counts()['PRODUCER_STARTED'],3)
   self.assertEqual({a['origin'] for a in r['dependency_receipts']},{'IDEMPOTENT_REPLAY'})
 def test_cycle(self):
  w=workflow();w['steps'][0]['depends_on']=['trace']
  with self.assertRaises(AdmissionError):plan(w)
 def test_unlisted_dependency(self):
  w=workflow();w['steps'][1]['depends_on']=[]
  with self.assertRaises(AdmissionError):plan(w)
 def test_duplicate_step(self):
  w=workflow();w['steps'].append(copy.deepcopy(w['steps'][0]))
  with self.assertRaises(AdmissionError):plan(w)
 def test_ambiguous_write(self):
  w=workflow();w['steps'][1]['bindings']*=2
  with self.assertRaises(AdmissionError):plan(w)
 def test_changed_plan_same_job_conflict(self):
  with tempfile.TemporaryDirectory() as d, Kernel(Path(d)/'a.db') as k:
   w=workflow();run_workflow(k,w);w['steps'][0]['payload']['query']='Mapping Context'
   with self.assertRaises(AdmissionError):run_workflow(k,w)
