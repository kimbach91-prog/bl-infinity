from __future__ import annotations
import copy, hashlib, json, os, sqlite3, subprocess, sys, tempfile, time, unittest, zlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import kernel, adapters, workloads
from independent_verifier import verify

class TestKernel(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.base=Path(self.tmp.name)
        self.k=kernel.Kernel(self.base/'state.db')
    def tearDown(self):self.k.close();self.tmp.cleanup()
    def test_full_composition_all_families(self):
        for family in workloads.FAMILIES:
            with self.subTest(family=family):
                q=workloads.task(family,1);r=self.k.run(q)
                self.assertEqual(r['state'],'VERIFIED_LOCAL_CONTRACT')
                self.assertNotEqual(r['receipt']['pid'],r['receipt']['verifier']['pid'])
                self.assertEqual(r['receipt']['producer_function_calls'],len(adapters.FUNCTIONS[family]))
                self.assertEqual(len(r['receipt']['bindings']),len(adapters.FUNCTIONS[family])+2)
                self.assertFalse(r['native_core'])
    def test_hold_in_forecast_preserved(self):
        r=self.k.run(workloads.task('forecast_reflex',0))
        self.assertEqual(r['output']['forecast']['state'],'HOLD_REGIME_CHANGE_OR_DRIFT')
        self.assertIsNone(r['output']['forecast']['forecast_value'])
        self.assertFalse(r['forecast_truth_verified'])
    def test_unreachable_graph_not_solved(self):
        r=self.k.run(workloads.task('backchain',0))
        self.assertEqual(r['output']['state'],'HOLD_GOAL_UNREACHABLE_IN_DECLARED_GRAPH')
    def test_no_physical_capacity_credit(self):
        r=self.k.run(workloads.task('placement',0))
        self.assertEqual(r['output']['state'],'HOLD_NO_SINGLE_NODE_CAPACITY')
    def test_source_counts_scope_preserved(self):
        r=self.k.run(workloads.task('metadata',1))
        self.assertEqual(r['output']['search']['excluded_nonowner_or_unknown'],1)
        self.assertEqual(r['output']['search']['matched'],11)
    def test_evidence_preserves_fail_unknown(self):
        r=self.k.run(workloads.task('evidence',1))['output']
        self.assertEqual((r['unique_count'],r['original_count'],r['fail_retained'],r['unknown_retained']),(12,24,8,8))
    def test_same_job_no_producer_replay(self):
        q=workloads.task('evidence');a=self.k.run(q);b=self.k.run(q)
        self.assertEqual(b['origin'],'IDEMPOTENT_REPLAY');self.assertEqual(a['output'],b['output'])
        self.assertEqual(self.k.audit_counts().get('PRODUCER_STARTED'),1)
    def test_cross_job_exact_reuse(self):
        q=workloads.task('mapping',2);self.k.run(q)
        q['task_id']='different';q['idempotency_key']='different'
        r=self.k.run(q);self.assertEqual(r['origin'],'EXACT_REUSE')
        self.assertEqual(r['receipt']['producer_function_calls'],0)
        self.assertEqual(self.k.audit_counts()['PRODUCER_STARTED'],1)
    def test_context_change_invalidates_reuse(self):
        q=workloads.task('mapping',2);self.k.run(q)
        q['task_id']='different';q['idempotency_key']='different';q['context_sha256']='f'*64
        self.assertEqual(self.k.run(q)['origin'],'EXECUTED')
    def test_identity_conflict(self):
        q=workloads.task('mapping',2);self.k.run(q);q['context_sha256']='e'*64
        with self.assertRaises(kernel.AdmissionError):self.k.run(q)
    def test_payload_conflict(self):
        q=workloads.task('evidence');self.k.run(q);q['payload']['records'][0]['content']='changed'
        with self.assertRaises(kernel.AdmissionError):self.k.run(q)
    def test_private_rejected_before_jobs(self):
        q=workloads.task('evidence');q['data_class']='OWNER_PRIVATE'
        with self.assertRaises(kernel.AdmissionError):self.k.run(q)
        self.assertEqual(self.k.audit_counts(),{})
    def test_phd_rejected(self):
        q=workloads.task('mapping');q['subject']='PHD'
        with self.assertRaises(kernel.AdmissionError):self.k.run(q)
    def test_effect_rejected(self):
        q=workloads.task('mapping');q['effect']='SHELL'
        with self.assertRaises(kernel.AdmissionError):self.k.run(q)
    def test_unknown_field_rejected(self):
        q=workloads.task('mapping');q['native_ack']=True
        with self.assertRaises(kernel.AdmissionError):self.k.run(q)
    def test_unbound_neural_rejected(self):
        q=workloads.task('mapping');q['family']='DEUS_NATIVE_PRIVATE'
        with self.assertRaises(kernel.AdmissionError):self.k.run(q)
    def test_mapping_collapse_fails(self):
        q=workloads.task('mapping');q['payload']['forward']['a1']='b0'
        with self.assertRaises(ValueError):self.k.run(q)
    def test_future_data_fails(self):
        q=workloads.task('forecast_reflex');q['payload']['as_of']=10
        with self.assertRaises(ValueError):self.k.run(q)
    def test_conflicting_evidence_id_fails(self):
        q=workloads.task('evidence');q['payload']['records'][12]['content']='changed'
        with self.assertRaises(ValueError):self.k.run(q)
    def test_expired_cache_reexecutes_pure_new_job(self):
        q=workloads.task('mapping',1);self.k.run(q)
        with self.k.db() as db:db.execute('UPDATE reuse SET expires_at=0')
        q['task_id']='new';q['idempotency_key']='new'
        self.assertEqual(self.k.run(q)['origin'],'EXECUTED')
    def test_prepared_cold_recovery_no_producer(self):
        q=workloads.task('mapping',1)
        with self.assertRaises(kernel.SimulatedCrash):self.k.run(q,_fault='after_prepared')
        self.k.close();self.k=kernel.Kernel(self.base/'state.db')
        r=self.k.run(q);self.assertEqual(r['origin'],'RECOVERED_PREPARED')
        self.assertEqual(self.k.audit_counts()['PRODUCER_STARTED'],1)
    def test_unknown_outcome_no_silent_replay(self):
        q=workloads.task('evidence')
        with self.assertRaises(kernel.SimulatedCrash):self.k.run(q,_fault='before_execute')
        r=self.k.run(q);self.assertEqual(r['state'],'UNKNOWN_LOCAL_OUTCOME')
        self.assertFalse(r['executor_reinvoked'])
    def test_snapshot_restore_no_producer(self):
        q=workloads.task('metadata');a=self.k.run(q)
        snapshot=self.base/'before.db';h=self.k.snapshot(snapshot)
        kernel.restore_snapshot(snapshot,self.base/'restored.db',h)
        with kernel.Kernel(self.base/'restored.db') as other:
            b=other.run(q);self.assertEqual(a['output'],b['output'])
            self.assertEqual(b['origin'],'IDEMPOTENT_REPLAY')
            self.assertEqual(other.audit_counts()['PRODUCER_STARTED'],1)
    def test_bad_restore_digest(self):
        self.k.run(workloads.task('mapping'));p=self.base/'snap.db';self.k.snapshot(p)
        with self.assertRaises(kernel.IntegrityError):kernel.restore_snapshot(p,self.base/'restore.db','0'*64)
    def test_artifact_corruption_is_not_accepted(self):
        q=workloads.task('evidence');self.k.run(q)
        with self.k.db() as db:db.execute('UPDATE artifacts SET body=?',(b'bad',))
        with self.assertRaises((kernel.IntegrityError,zlib.error)):self.k.run(q)
    def test_invalid_schema_version(self):
        q=workloads.task('mapping');q['schema']='wrong'
        with self.assertRaises(kernel.AdmissionError):self.k.run(q)
    def test_payload_budget(self):
        q=workloads.task('mapping');q['payload']['junk']='x'*1000000
        with self.assertRaises(kernel.AdmissionError):self.k.run(q)
    def test_verifier_rejects_forged_binding_credit(self):
        q=workloads.task('mapping',1);r,_=adapters.run_bound(q['family'],q['payload']);r['native_bl_mapping_executed']=True
        with self.assertRaises(kernel.IntegrityError):self.k.verifier.verify(q['family'],q['payload'],r)
    def test_verifier_detects_rehashed_wrong_mapping(self):
        q=workloads.task('mapping',1);r,_=adapters.run_bound(q['family'],q['payload']);r['states_checked']=999
        with self.assertRaises(kernel.IntegrityError):self.k.verifier.verify(q['family'],q['payload'],r)
    def test_verifier_detects_lost_fail(self):
        q=workloads.task('evidence',1);r,_=adapters.run_bound(q['family'],q['payload']);r['fail_retained']=0
        with self.assertRaises(kernel.IntegrityError):self.k.verifier.verify(q['family'],q['payload'],r)
    def test_verifier_detects_wrong_goal_path(self):
        q=workloads.task('backchain',1);r,_=adapters.run_bound(q['family'],q['payload']);r['path']=['s0','s10'];r['steps']=1
        with self.assertRaises(kernel.IntegrityError):self.k.verifier.verify(q['family'],q['payload'],r)
    def test_verifier_detects_false_prediction(self):
        q=workloads.task('forecast_reflex',1);r,_=adapters.run_bound(q['family'],q['payload']);r['forecast']['forecast_value']+=1
        with self.assertRaises(kernel.IntegrityError):self.k.verifier.verify(q['family'],q['payload'],r)
    def test_verifier_detects_unsafe_resource_sum(self):
        q=workloads.task('placement',0);r,_=adapters.run_bound(q['family'],q['payload']);r['suggestion']={'node':'fictional'}
        with self.assertRaises(kernel.IntegrityError):self.k.verifier.verify(q['family'],q['payload'],r)
    def test_verifier_detects_duplicate_lineage_credit(self):
        q=workloads.task('metadata',1);r,_=adapters.run_bound(q['family'],q['payload']);r['lineage']['independent_lineages_claimable']=100
        with self.assertRaises(kernel.IntegrityError):self.k.verifier.verify(q['family'],q['payload'],r)

if __name__=='__main__':unittest.main(verbosity=2)
