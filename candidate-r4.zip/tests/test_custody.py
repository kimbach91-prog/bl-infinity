import hashlib,json,os,shutil,subprocess,sys,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from workloads import task

class CustodyTests(unittest.TestCase):
 def test_two_processes_one_job_only_one_producer(self):
  with tempfile.TemporaryDirectory() as d:
   d=Path(d);q=d/'task.json';q.write_text(json.dumps(task('mapping',1)))
   cmd=[sys.executable,str(ROOT/'kernel.py'),'--store',str(d/'jobs.db'),'--request',str(q)]
   procs=[subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE) for _ in range(2)]
   completed=[];results=[]
   for p in procs:
    o,e=p.communicate(timeout=12);completed.append((p.returncode,o,e))
   for rc,o,e in completed:
    self.assertEqual(rc,0,'stdout='+o.decode()+' stderr='+e.decode());results.append(json.loads(o))
   self.assertEqual(sorted(r['origin'] for r in results),['EXECUTED','IDEMPOTENT_REPLAY'])
   self.assertEqual(results[0]['output'],results[1]['output'])
 def test_changed_pinned_code_stops_before_execution(self):
  with tempfile.TemporaryDirectory() as d:
   d=Path(d)
   for n in ['kernel.py','adapters.py','compose.py','independent_verifier.py','SOURCE_BINDINGS.json']:
    shutil.copy2(ROOT/n,d/n)
   shutil.copytree(ROOT/'upstream/r51/upstream/r41/deus_one',d/'upstream/r51/upstream/r41/deus_one')
   p=d/'upstream/r51/upstream/r41/deus_one/mapping.py';p.write_text(p.read_text()+'\n# controlled source tamper\n')
   q=d/'task.json';q.write_text(json.dumps(task('mapping',1)))
   run=subprocess.run([sys.executable,str(d/'kernel.py'),'--store',str(d/'jobs.db'),'--request',str(q)],capture_output=True,text=True,timeout=12)
   self.assertEqual(run.returncode,2);self.assertIn('SOURCE_PIN_MISMATCH',run.stdout)
   self.assertFalse((d/'jobs.db').exists())
 def test_original_archive_stays_byte_identical(self):
  p=ROOT/'source/DEUS_CHESS_R51_SOURCE_RECONSTRUCTION_20261017.zip'
  self.assertEqual(hashlib.sha256(p.read_bytes()).hexdigest(),'520c8deb919a3f886b56ecd36d2807ade3f437098881595919c7e9fdd5b06861')
