# DEUS-ONE PUBLIC COMPOSITION R6.1

Executable integration of unchanged, archived PUBLIC R4.1 functions. Not private Native Core, a trained LLM, an owner-fleet deployment, or a new chess engine.

## Requirements
Linux, CPython 3.11+; standard library only. No downloads, network calls or credentials. The producer, verifier and SQLite store use separate measured stages. The verifier is a separate process, not a third-party certifier.

## Verify and run
```sh
python verify_release.py
python -W error -m unittest discover -s tests -v
python kernel.py --store /tmp/deus-r61-demo.db --request examples/mapping.json
# Exact repeat should return IDEMPOTENT_REPLAY, not run the producer again.
python kernel.py --store /tmp/deus-r61-demo.db --request examples/mapping.json
python run_graph.py --store /tmp/deus-r61-graph.db --workflow examples/source_to_plan.json
# The output directory MUST be new. This runs 120 synthetic tasks x 3 repeats, no chess.
python benchmark.py --out /tmp/deus-r61-new-benchmark
```

Optional processing of the already archived 100 chess results is `benchmark.py --out NEW_DIRECTORY --match-zip PATH_TO_PINNED_MATCH_ARCHIVE`. It does not start games or change the baseline. The match archive is not copied into this release; its exact hash is checked when supplied.

`REPORT_VI.md` records measured slowdown relative to direct calls and the observed optimization. `SOURCE_BINDINGS.json` pins the 9 inherited Python modules and 4 integration modules, not all private DEUS capabilities. Original R5.1 archive and 101-entry manifest are included without modification. `evidence/bench1` preserves pre-optimization source and results; `evidence/bench3_optimized` contains completed measurements and SQLite snapshots. The interrupted bench2 is not counted.

Security boundary: trusted local development code and processes only. Hashes are integrity checks, not owner authorization or supply-chain signatures. No arbitrary executable/module registration is supported. Stateful or private capabilities need a separate target admission contract and verifier. Never change `native_core=false` merely because tests pass.

Custody: CANON_PENDING.json is a proposed checkpoint. It is not a successful Google Drive write or native ACK.
