# DEUS-ONE R6.1 — Nối các module PUBLIC thành một luồng thực thi có kiểm chứng

**Ngày 17/10/2026. Phạm vi: LOCAL_PUBLIC_REFERENCE_INTEGRATION. Không phải nâng cấp nhân private hoặc triển khai production.**

## 1. Việc đã lập trình

Bản này bổ sung một bộ chạy tác vụ và đồ thị phụ thuộc, thay cho việc chỉ liệt kê module hoặc chạy ví dụ cố định. Nó gọi trực tiếp những hàm PUBLIC đã có trong gói R4.1, được kế thừa nguyên byte bên trong R5.1. Không viết lại sáu thuật toán gốc và không đổi bộ chọn nước cờ.

Luồng chung: kiểm hợp đồng tác vụ → kiểm nguồn bằng SHA-256 → giải quan hệ phụ thuộc → kiểm tái sử dụng → gọi hàm đã khóa → tiến trình kiểm chứng tách biệt → mã hóa bằng codec kế thừa → lưu kết quả/checkpoint → trả receipt. Chỉ chấp nhận dữ liệu PUBLIC, chủ thể BACH và tác vụ thuần tính toán PURE. Không có giao thức nào trong bản này cấp quyền điều khiển Brain3 hoặc đọc lõi riêng.

Có sáu nhóm đã thực sự nối: chứng cứ/nén không mất dữ liệu; tìm kiếm metadata và phân biệt dòng nguồn; hồi quy mục tiêu trên đồ thị hữu hạn; dự báo–phản xạ giả lập; lựa chọn node giả lập với nhiều ràng buộc; kiểm ánh xạ giữ bất biến. Contract và codec kiểu dữ liệu dùng mã PUBLIC kế thừa. Tên nhóm không đồng nghĩa đã gọi các implementation private tương ứng của DEUS.

Ví dụ ghép động: kết quả tìm một nguồn quyết định điểm bắt đầu cho tác vụ hồi quy; dòng nguồn đó tiếp tục đi vào bản ghi chứng cứ. Đổi truy vấn từ Memory Search sang Mapping Context làm đường kế hoạch thay đổi từ 2 sang 3 cạnh. Đầu ra của bước trước thật sự quyết định đầu vào bước sau, không phải sáu ví dụ đặt cạnh nhau.

## 2. Benchmark theo công đoạn

120 tác vụ tổng hợp, chia đều sáu nhóm, lặp ba lượt. Đối chiếu 360 đầu ra giữa gọi trực tiếp và đi qua runner; thêm 360 lần tái sử dụng cùng dữ liệu/ngữ cảnh/phiên bản: tất cả khớp. Mỗi lần tái sử dụng được kiểm lại bởi verifier, không gọi lại hàm sinh kết quả.

Đơn vị trong bảng là **mili giây, trung vị p50**. Mỗi ô 60 quan sát. p95 và các số đo thô nằm trong gói.

| Công đoạn | Gọi trực tiếp có verifier | R6.0 | R6.1 | R6.1 tái sử dụng | Giảm so R6.0 |
|---|---:|---:|---:|---:|---:|
| Hồi quy mục tiêu trên đồ thị hữu hạn | 0.599 | 4.055 | 2.502 | 2.403 | 38.3% |
| Bảo toàn và tái sử dụng chứng cứ | 1.769 | 6.070 | 4.566 | 3.939 | 24.8% |
| Dự báo và phản xạ giả lập | 0.937 | 4.669 | 3.065 | 2.670 | 34.4% |
| Ánh xạ và bảo toàn bất biến | 0.692 | 4.263 | 2.738 | 2.479 | 35.8% |
| Tìm kiếm metadata và kiểm dòng nguồn | 1.532 | 5.588 | 4.029 | 3.169 | 27.9% |
| Chọn node theo sáu loại tài nguyên | 0.770 | 4.470 | 2.936 | 2.659 | 34.3% |

**Không có kết luận tăng tốc toàn hệ:** với các tác vụ nhỏ này, runner R6.1 vẫn chậm hơn gọi trực tiếp có verifier khoảng 2,58–4,18 lần. Đường trực tiếp không có lưu trạng thái bền vững nên không phải đối chứng tương đương hoàn toàn về dịch vụ. Đây là phép đo chi phí tích hợp, không chứng minh DEUS mạnh hơn.

Thay đổi đã làm sau lượt đầu: giữ một kết nối SQLite cho mỗi runner, thay vì mở/đóng lặp. Vẫn giữ WAL, synchronous=FULL, các transaction, kiểm hash và verifier. Trong các lượt đo tuần tự này, trung vị đường đầy đủ giảm khoảng 25–38%. Chưa chạy thử nghiệm xen kẽ trên nhiều máy để tách mọi ảnh hưởng tải nền, do đó đây là cải thiện quan sát cục bộ.

Các mốc đo riêng gồm admission, source pin, cache lookup, producer, semantic verifier, typed codec, storage encoding, commit cuối và toàn vòng. **Tổng thời gian bao gồm phần điều phối/transaction chưa tách riêng; không cộng các median công đoạn để suy ra median toàn vòng.** Tái sử dụng nhanh hơn cold khoảng 1,04–1,27 lần trong mẫu nhỏ; đây không phải lợi thế hàng trăm lần.

## 3. Kiểm thử và phục hồi

- Bộ kiểm thử mới có 44 ca: 41 kiểm hợp đồng/ghép động/phục hồi và 3 kiểm đa tiến trình/lưu nguồn. Bản giải nén độc lập chạy lại đủ **44/44 đạt**; xem evidence/fresh_unzip_tests.log. CLI tác vụ, phát lại cùng ID và đồ thị ba bước cũng được chạy lại thành công.
- Bộ kiểm thử PUBLIC R4.1 kế thừa: 305/305 đạt. 101 mục manifest R5.1 khớp SHA; gói nguồn R5.1 gốc giữ nguyên byte.
- Ba lần backup và khôi phục SQLite sang kho mới, rồi tiếp cùng tác vụ: không gọi lại producer.
- Đã thử gián đoạn sau khi lưu PREPARED, thiếu kết quả xác nhận cuối; tiến trình mới kiểm lại và phục hồi. Gián đoạn trước khi có kết quả lưu thì giữ UNKNOWN, không tự bịa kết quả hay thực thi lại.
- Hai tiến trình gọi cùng một job: một lần EXECUTED, một lần IDEMPOTENT_REPLAY. Đây là kiểm thử cục bộ dùng khóa tệp, không phải kiểm định HA đa máy.
- Đối chứng âm gồm: sai hash nguồn, sửa artifact, nén mất dữ liệu, đổi payload/ngữ cảnh nhưng dùng lại ID, giả native ACK, yêu cầu private, chu kỳ graph, thiếu phụ thuộc, bindings chồng lấn và dữ liệu tương lai lọt vào dự báo.

Verifier chạy ở tiến trình riêng, không import thuật toán sinh kết quả. Nó kiểm lại các bất biến và nghĩa của từng họ tác vụ (ví dụ tìm xuôi đối chứng hồi quy). Đây vẫn là verifier do cùng bên phát triển, không phải chứng nhận đơn vị thứ ba. Kiểm đúng phép tính dự báo không chứng minh dự báo đúng tương lai.

## 4. Kết quả cờ vua được giữ làm đối chứng

Không đấu thêm ván nào. Runner xử lý bản ghi của 100 ván R5.1 đã lưu: tạo 200 quan sát có lặp có chủ ý, khử trùng thành đúng 100 ván, giữ đủ 200 dấu FAIL ở mức quan sát và nguyên chuỗi dữ liệu cần tái dựng. Kết quả gốc 0 thắng–0 hòa–100 thua, source ID và native_core=false không bị đổi. Đây là kiểm xử lý bằng chứng cũ, không phải hậu kiểm luật cờ mới hoặc kết quả thi đấu mới.

## 5. Phạm vi chưa khép

Chưa kết nối private Native Core, SearchCell/XSearch live, BLμ compiler native, JEV, trọng số neural, bộ nhớ private hoặc B1–B8. Bộ chọn node chỉ xét tài nguyên giả lập, không cấp phát máy. Không thay website, không phát hành source mới qua GitHub và không nhận ACK từ owner runtime. Vì thế không công nhận toàn DEUS đã hợp nhất hoặc nâng chất lượng cờ.

Bước tiếp theo hợp lý là đưa **một adapter native đã có quyền và có bằng chứng** vào cùng contract, rồi chạy lại correctness/negative/recovery và benchmark có baseline tương đương. Chỉ khi một thay đổi thật nằm trên đường chọn nước, giữ được luật và chứng chỉ, mới khóa bản cờ mới để đo so với baseline R5.1. Không chạy thêm 100 ván của cùng engine chỉ để tăng số lượng test.

## 6. Lưu trữ, quyền và scars

Nguồn R5.1: Drive file `1AldX3N5WaTc9e_NotnFg4vc6PQ51yHW2`, SHA-256 `520c8deb919a3f886b56ecd36d2807ade3f437098881595919c7e9fdd5b06861`. Baseline100: Drive `1KXoOGZVW6sCV2v130WYmeAus_pMszOW3`, SHA-256 `bdfb6f7b7e1eced58a393f35989827bbd5000026a885b169927eee24552f9d29`. Canon hiện tại tại `WORKSPACE_CODEX_20261012!A289:H289` được đọc lại; parent website giữ nguyên IN_PROGRESS/R32.

Gói mới được tạo cục bộ và có manifest toàn tệp. **Chưa tải R6.1 lên Drive, chưa có Drive readback và chưa commit GitHub:** ở lượt này danh mục công cụ Drive/GitHub cung cấp cho phép đọc nhưng không trả về các thao tác ghi khi khám phá upload/batch-update/create-tree. Việc kết nối Drive đang bật không tự chứng minh thao tác ghi có mặt ở surface này. Không suy diễn quyền owner bị thu hồi toàn hệ. Tệp CANON_PENDING.json chứa checkpoint đề nghị và trạng thái rõ ràng; nó không phải bản ghi đã được canon chấp nhận.

Giữ lỗi ResourceWarning đóng kết nối SQLite của lượt đầu và log sửa; giữ số đo R6.0 chậm; giữ đợt benchmark bị dừng do tool timeout mà không xuất SUMMARY. Bản tối ưu hoàn tất ở output mới, không ghi đè thử nghiệm lỗi hoặc tự tính partial thành kết quả đạt. Không đổi IAM, credential, chi phí, lịch, queue native, Memory hoặc Project.

## 7. Ranh giới tin cậy của mã

Đây là runner phát triển Linux/CPython 3.11+ dành cho tiến trình và mã cục bộ đáng tin; không phải sandbox chạy code tùy ý, hệ xác thực owner từ xa, chữ ký chuỗi cung ứng hay quorum HA. SHA giúp phát hiện sai lệch so manifest, không tự tạo chữ ký thẩm quyền. Công cụ pin_sources.py chỉ dành cho người đóng bản nguồn; runner không tự dùng nó để chấp nhận code thay đổi. Quyền PURE/PUBLIC được kiểm bằng hợp đồng cục bộ, không thay admission của private/native target.
