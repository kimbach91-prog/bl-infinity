"""Bounded typed DAG linking actual local function outputs; no new authority.

Dependency bindings may replace payload fields only, never family/subject/scope.
A workflow remains a LOCAL PUBLIC contract, not an admitted native DEUS job.
"""
from __future__ import annotations
import copy, re, time
from kernel import Kernel, AdmissionError, sha, validate_request

TOKEN=re.compile(r'^[A-Za-z][A-Za-z0-9_-]{0,47}$')

def pick(value,pointer):
    if type(pointer) is not str or not pointer.startswith('/') or '~' in pointer:raise AdmissionError('BOUNDED_JSON_POINTER')
    try:
        for key in pointer.split('/')[1:]:
            if isinstance(value,list):
                if not re.fullmatch(r'0|[1-9][0-9]*', key):raise AdmissionError('ARRAY_INDEX')
                value=value[int(key)]
            elif isinstance(value,dict):
                if key not in value:raise AdmissionError('BOUNDED_JSON_POINTER')
                value=value[key]
            else:raise AdmissionError('POINTER_NON_CONTAINER')
        return copy.deepcopy(value)
    except (KeyError, IndexError, ValueError, TypeError) as exc:
        if isinstance(exc, AdmissionError):
            raise
        raise AdmissionError('BOUNDED_JSON_POINTER') from exc

def replace(payload,pointer,value):
    if type(pointer) is not str or not pointer.startswith('/') or '~' in pointer:raise AdmissionError('PAYLOAD_POINTER')
    keys=pointer.split('/')[1:];current=payload
    try:
        for key in keys[:-1]:
            if isinstance(current,list):
                if not re.fullmatch(r'0|[1-9][0-9]*', key):raise AdmissionError('NO_NEW_PAYLOAD_KEYS')
                idx=int(key)
                if not (0<=idx<len(current)):raise AdmissionError('NO_NEW_PAYLOAD_KEYS')
                current=current[idx]
            elif isinstance(current,dict):
                if key not in current:raise AdmissionError('NO_NEW_PAYLOAD_KEYS')
                current=current[key]
            else:raise AdmissionError('NO_NEW_PAYLOAD_KEYS')
        key=keys[-1]
        if isinstance(current,list):
            if not re.fullmatch(r'0|[1-9][0-9]*', key):raise AdmissionError('NO_NEW_PAYLOAD_KEYS')
            idx=int(key)
            if not (0<=idx<len(current)):raise AdmissionError('NO_NEW_PAYLOAD_KEYS')
            current[idx]=value
        elif isinstance(current,dict):
            if key not in current:raise AdmissionError('NO_NEW_PAYLOAD_KEYS')
            current[key]=value
        else:raise AdmissionError('NO_NEW_PAYLOAD_KEYS')
    except (KeyError, IndexError, ValueError, TypeError) as exc:
        if isinstance(exc, AdmissionError):
            raise
        raise AdmissionError('NO_NEW_PAYLOAD_KEYS') from exc

def _validate_and_canonicalize_pointer(payload, pointer):
    if type(pointer) is not str or not pointer.startswith('/') or '~' in pointer:raise AdmissionError('PAYLOAD_POINTER')
    keys=pointer.split('/')[1:];current=payload
    canonical_keys=[]
    for key in keys:
        if isinstance(current,list):
            if not re.fullmatch(r'0|[1-9][0-9]*', key):raise AdmissionError('NO_NEW_PAYLOAD_KEYS')
            idx=int(key)
            if not (0<=idx<len(current)):raise AdmissionError('NO_NEW_PAYLOAD_KEYS')
            canonical_keys.append(str(idx))
            current=current[idx]
        elif isinstance(current,dict):
            if key not in current:raise AdmissionError('NO_NEW_PAYLOAD_KEYS')
            canonical_keys.append(key)
            current=current[key]
        else:raise AdmissionError('NO_NEW_PAYLOAD_KEYS')
    return '/'+'/'.join(canonical_keys)

def plan(workflow):
    if type(workflow) is not dict or set(workflow)!={'schema','workflow_id','context_sha256','steps'}:raise AdmissionError('WORKFLOW_SCHEMA')
    if workflow['schema']!='deus-one-public-dag/1' or not TOKEN.fullmatch(workflow['workflow_id']):raise AdmissionError('WORKFLOW_ID')
    if not re.fullmatch('[0-9a-f]{64}',workflow['context_sha256']):raise AdmissionError('WORKFLOW_CONTEXT')
    steps=workflow['steps']
    if type(steps) is not list or not 1<=len(steps)<=24:raise AdmissionError('WORKFLOW_BOUND')
    ids=[];catalog={}
    for s in steps:
        if type(s) is not dict or set(s)!={'id','family','payload','depends_on','bindings'} or not TOKEN.fullmatch(s['id']):raise AdmissionError('STEP_SCHEMA')
        if s['id'] in ids:raise AdmissionError('DUPLICATE_STEP')
        ids.append(s['id']);catalog[s['id']]=s
        if type(s['depends_on']) is not list or len(set(s['depends_on']))!=len(s['depends_on']):raise AdmissionError('DEPENDENCY_SCHEMA')
        if type(s['bindings']) is not list or len(s['bindings'])>24:raise AdmissionError('BINDING_BOUND')
        destinations=[]
        canonical_dests=[]
        for b in s['bindings']:
            if type(b) is not dict or set(b)!={'from_step','output_pointer','payload_pointer'} or b['from_step'] not in s['depends_on']:raise AdmissionError('UNDECLARED_DEPENDENCY')
            p_ptr = b['payload_pointer']
            can_ptr = _validate_and_canonicalize_pointer(s['payload'], p_ptr)
            if p_ptr in destinations or can_ptr in canonical_dests:raise AdmissionError('OVERLAPPING_WRITE')
            destinations.append(p_ptr)
            canonical_dests.append(can_ptr)
        for a in canonical_dests:
            for b in canonical_dests:
                if a!=b and b.startswith(a+'/'):raise AdmissionError('OVERLAPPING_POINTERS')
    for s in steps:
        if any(d not in catalog or d==s['id'] for d in s['depends_on']):raise AdmissionError('DANGLING_DEPENDENCY')
    order=[]
    while len(order)<len(ids):
        ready=sorted(i for i in ids if i not in order and set(catalog[i]['depends_on'])<=set(order))
        if not ready:raise AdmissionError('DEPENDENCY_CYCLE')
        order.extend(ready)
    return catalog,order

def run_workflow(runtime:Kernel,workflow:dict)->dict:
    t=time.perf_counter_ns();catalog,order=plan(workflow);plan_ns=time.perf_counter_ns()-t
    completed={};resolved={};receipts=[]
    workflow_hash=sha(workflow)
    for stepid in order:
        step=catalog[stepid];payload=copy.deepcopy(step['payload'])
        for b in step['bindings']:
            replace(payload,b['payload_pointer'],pick(completed[b['from_step']]['output'],b['output_pointer']))
        dep_hashes={d:completed[d]['receipt']['result_sha256'] for d in step['depends_on']}
        context=sha({'workflow':workflow_hash,'source_context':workflow['context_sha256'],'dependencies':dep_hashes})
        request={'schema':'deus-one-public-task/1','task_id':workflow['workflow_id']+'.'+stepid,
          'subject':'BACH','data_class':'PUBLIC','effect':'PURE','family':step['family'],
          'payload':payload,'context_sha256':context,'idempotency_key':workflow['workflow_id']+'.'+stepid}
        # Payload type/schema remains checked after binding, not assumed from the DAG.
        validate_request(request);resolved[stepid]=request
        result=runtime.run(request)
        if result['state']!='VERIFIED_LOCAL_CONTRACT':
            return {'state':'HOLD_WORKFLOW_STEP','failed_step':stepid,'completed':completed,'native_core':False}
        completed[stepid]=result
        receipts.append({'step':stepid,'depends_on':dep_hashes,'request_sha256':sha(request),
          'output_sha256':result['receipt']['result_sha256'],'origin':result['origin']})
    return {'state':'VERIFIED_LOCAL_DAG_CONTRACT','workflow_id':workflow['workflow_id'],
       'workflow_sha256':workflow_hash,'plan_ns':plan_ns,'order':order,'step_results':completed,
       'resolved_requests':resolved,'dependency_receipts':receipts,'native_core':False,'remote_target_ack':False}
