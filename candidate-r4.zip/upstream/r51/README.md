# DEUS-ONE Chess R5.1 — reconstructed PUBLIC UCI adapter

This is a **new reconstruction**, not the byte-identical R5 previously described,
not the owner-private DEUS Native Core, and not the complete B1–B8 fleet.
The original R5 C++/binary/archive could not be recovered in the inspected stores.
No claim that its earlier 342 tests or two historical games were reproduced from original R5.

## Actual functionality

* Original standalone C++17 standard 32-piece chess engine: legal moves, FEN/history replay,
  castling, pinned en-passant, all promotions, terminal mates/stalemates, bounded draw-aware search.
* UCI position/startpos/fen, go movetime/depth/nodes/clocks/searchmoves, stop, ready, perft.
  One search thread; Hash 1–256 MiB. No Chess960, no ponder mode, no neural network.
* Iterative deepening, alpha-beta, quiescence, heuristic material/position/king-safety evaluation.
  Transposition keys preserve halfmove/repetition context. Heuristic evaluations are **not proof**.
* Reuses the unchanged R4.1 PUBLIC KQK source through a new exporter and strict material/history gates.
  The original R41 archive is pinned: 67af5cdf970875704b02e073e5bbbd34e274ec87d8c4f132b81a70cbcaaf3c60.
* Reuses original R41 `CanonicalEnvelope`, fingerprint and lossless pack/unpack in a new local adapter.
  Owner-private/context/native grants are rejected. No remote effect or model call.
* Match referee is a **separate pinned Stockfish 19 process** used exclusively as a legal-move/FEN/check
  oracle, combined with an independently written Python FEN updater/SAN encoder.
  This is independent of DEUS move selection, not an external third-party arbiter or official online service.
* Per-move UCI stdout, CPU ticks, wall time, nodes, exact event hash chain, configuration, PGN and checkpoints.
  Verified finished games are not rerun. An interrupted game resumes from already played moves.

## Build and run

`bash build.sh` on Linux x86-64 (C++17, g++, Python 3.10+, standard libraries only).
The binary included is an isolated Linux build; rebuild for another platform. The KQK export is little endian.
Get Stockfish **separately from its official distribution**; its source and GPL license are not part of this new engine.
The verified opponent binary used here has SHA256
`2d89ca06b7f564cdea08fc1433d35b78d18178f5ceee9cab50133ab8d69c0cd2`.
Place it at `bin/stockfish19`, then run:

```
python -W error -m unittest discover -s tests -v
python arena.py --games 100 --millis 100 --workers 2 --out evidence/match100
```

`100 ms per move`, one thread and 32 MiB hash each are **local test settings**, not all hardware available to either side.
All 100 games begin at ordinary startpos; 50 color-swapped seed pairs; no opening book, no resignation/evaluation
adjudication. Threefold/fifty-move draw claims are applied when already claimable in the current position by a
predeclared mutual-claim policy. Potential future claims are not automatically played for the engines. Proven
mate/stalemate and conservative insufficient-material are adjudicated. A 400-ply limit abort is `*`, never a fake draw.

## What is NOT enabled

Private Native Core/BL-SFRET implementation, SearchCell native, JEV, learned DEUS weights, GPU/fleet dispatch,
owner Brain3 installation, website deployment and Lichess BOT channel are **not bound or verified**.
Using Stockfish 19's original binary does not make this an official online tournament.
Do not label results as full-DEUS-vs-Stockfish strength or as a 100x-compute victory.

## Source custody

`SOURCE_SHA256.json` covers this reconstruction and every inherited R41 file; `verify_package.py`
checks them before running. Match source is frozen before the 100-game test. Any later edit needs a new identity.
Previous R41 artifacts and the missing-R5 audit remain intact; this package does not overwrite them.

## Preserved scars

Initial pip installation of a potential referee library failed due to unavailable container DNS; no dependency
was silently installed. Final code uses only stdlib and the existing official Stockfish binary.
Initial strict C++ build found misleading-indentation and possible invalid-move indexing warnings. The code
was corrected, including explicit move index guards; warnings were not disabled.
Two pilot games finished legally with losses for R5.1. They are a separate development preflight, not part of 100.
