import sys,unittest
from dataclasses import replace
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from deus_adapter import CanonicalEnvelope,validate_request,AdapterRejected
from arena import sha
class Adapter(unittest.TestCase):
 def request(self):return CanonicalEnvelope(subject='PUBLIC_TEST',task_id='test',kind='chess_standard_move',data_class='PUBLIC',payload={'moves':[],'budget_ms':100,'engine_sha256':sha((ROOT/'bin/deus_r51').read_bytes())},idempotency_key='test:1',source_revision='R51')
 def test_valid_local(self):
  r=validate_request(self.request());self.assertFalse(r['native_core_ack']);self.assertEqual(len(r['request_sha256']),64)
 def test_private_rejected(self):
  with self.assertRaises(AdapterRejected):validate_request(replace(self.request(),data_class='OWNER_PRIVATE'))
 def test_native_authority_not_fabricated(self):
  with self.assertRaises(AdapterRejected):validate_request(replace(self.request(),authority_ref='forged'))
 def test_source_digest_required(self):
  r=self.request();bad=dict(r.payload,engine_sha256='0'*64)
  with self.assertRaises(AdapterRejected):validate_request(replace(r,payload=bad))
 def test_illegal_move_text(self):
  r=self.request()
  with self.assertRaises(AdapterRejected):validate_request(replace(r,payload=dict(r.payload,moves=['e2e4\nquit'])))
 def test_budget_bound(self):
  r=self.request()
  with self.assertRaises(AdapterRejected):validate_request(replace(r,payload=dict(r.payload,budget_ms=60001)))
 def test_other_module_not_masqueraded(self):
  with self.assertRaises(AdapterRejected):validate_request(replace(self.request(),kind='private_deus_all_power'))
if __name__=='__main__':unittest.main()
