import sys,time,json,random,hashlib,unittest,subprocess,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from arena import Engine,Position,START,compare_fen,canonical,sha,SF_SHA
D=[ROOT/'bin/deus_r51','--kqk',ROOT/'bin/kqk.dtm'];S=[ROOT/'bin/stockfish19']
class Runtime(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.d=Engine(D);cls.s=Engine(S)
 @classmethod
 def tearDownClass(cls):cls.d.close();cls.s.close()
 def test_identity(self):
  self.assertEqual(self.d.identity,'DEUS-ONE R5.1 PUBLIC Reconstruction');self.assertEqual(self.s.identity,'Stockfish 19')
  self.assertNotEqual(sha((ROOT/'bin/deus_r51').read_bytes()),SF_SHA)
 def test_startpos_perft4(self):
  self.d.position();self.s.position();a,n,_=self.d.perft(4);b,k,_=self.s.perft(4)
  self.assertEqual(a,b);self.assertEqual(n,197281);self.assertEqual(k,197281)
 def test_special_positions(self):
  fens=[
   'r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1',
   '8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1',
   'r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1',
   '4k3/8/8/r4pPK/8/8/8/8 w - f6 0 1',
   '4k3/P7/8/8/8/8/7p/4K3 w - - 0 1',
   '8/8/8/8/8/2k5/1q6/K7 w - - 0 1',
   '7k/5Q2/6K1/8/8/8/8/8 b - - 0 1',
   '7k/6Q1/6K1/8/8/8/8/8 b - - 150 1',
  ]
  evidence=[]
  for fen in fens:
   with self.subTest(fen=fen):
    self.d.position(fen=fen);self.s.position(fen=fen)
    a,n,_=self.d.perft(3);b,k,_=self.s.perft(3)
    self.assertEqual(a,b);self.assertEqual(n,k);evidence.append({'fen':fen,'nodes':n,'match':True})
  (ROOT/'evidence/special_perft.json').write_bytes(canonical(evidence))
 def test_random_reachable(self):
  evidence=[]
  for seed in range(4):
   rng=random.Random(99171+seed);moves=[];pos=Position(START)
   for ply in range(40):
    self.s.position(moves);legal,_,_=self.s.perft(1)
    if not legal:break
    m=rng.choice(sorted(legal));moves.append(m);pos.apply(m)
    self.d.position(moves);self.s.position(moves)
    if ply%2==0:
     a,n,_=self.d.perft(2);b,k,_=self.s.perft(2)
     self.assertEqual(a,b,(seed,ply));self.assertEqual(n,k)
     df,_=self.d.describe();sf,_=self.s.describe()
     self.assertTrue(compare_fen(df,sf));self.assertTrue(compare_fen(pos.fen(),sf))
     evidence.append({'seed':seed,'ply':ply+1,'moves':list(moves),'nodes':n,'fen':sf,'legal_sha':sha(canonical(sorted(a)))})
  (ROOT/'evidence/random_perft.json').write_bytes(canonical(evidence));self.assertGreaterEqual(len(evidence),75)
 def test_kqk_exact_route(self):
  self.d.position(fen='8/7Q/1k1K4/8/8/8/8/8 w - - 0 1')
  move,t=self.d.play(100);self.assertEqual(move,'h7b1');self.assertIn('R41_KQK_EXACT_REFERENCE',t['route'])
 def test_kqk_black_color_mapping(self):
  self.d.position(fen='8/7q/1K1k4/8/8/8/8/8 b - - 0 1')
  move,t=self.d.play(100);self.assertEqual(move,'h7b1');self.assertIn('R41_KQK_EXACT_REFERENCE',t['route'])
 def test_tb_invalid_history_gate(self):
  self.d.position(fen='8/7Q/1k1K4/8/8/8/8/8 w - - 99 1')
  move,t=self.d.play(20);self.assertNotIn('R41_KQK_EXACT_REFERENCE',t['route'] or '')
 def test_stop_and_ready(self):
  self.d.position();self.d.send('go infinite');time.sleep(.03);self.d.send('isready')
  lines=self.d.until(lambda x:x=='readyok');self.d.send('stop')
  lines+=self.d.until(lambda x:x.startswith('bestmove '));self.assertTrue(any(x.startswith('bestmove ') for x in lines));self.d.ready()
 def test_nodes_limit(self):
  self.d.position();self.d.send('go nodes 100');lines=self.d.until(lambda x:x.startswith('bestmove '))
  self.assertRegex(lines[-1],r'^bestmove [a-h][1-8][a-h][1-8]$')
 def test_searchmoves(self):
  self.d.position();self.d.send('go depth 2 searchmoves e2e4');lines=self.d.until(lambda x:x.startswith('bestmove '));self.assertEqual(lines[-1],'bestmove e2e4')
 def test_illegal_input_rejected(self):
  self.d.position(['e2e5']);self.d.send('go nodes 1');lines=self.d.until(lambda x:x.startswith('bestmove '))
  self.assertIn('info string rejected ILLEGAL_REPLAY',lines);self.assertEqual(lines[-1],'bestmove 0000');self.d.position()
 def test_bad_fen_rejected(self):
  self.d.position(fen='8/8/8/8/8/8/8/8 w - - 0 1');self.d.send('go nodes 1');lines=self.d.until(lambda x:x.startswith('bestmove '));self.assertEqual(lines[-1],'bestmove 0000');self.d.position()
 def test_no_moves_null(self):
  self.d.position(fen='7k/6Q1/6K1/8/8/8/8/8 b - - 0 1');m,_=self.d.play(20);self.assertEqual(m,'0000')
 def test_king_queen_material_not_claim_draw(self):self.assertFalse(Position('7k/8/8/8/8/8/5Q2/4K3 w - - 0 1').insufficient())
 def test_stalemate(self):
  self.d.position(fen='7k/5Q2/6K1/8/8/8/8/8 b - - 0 1');_,n,_=self.d.perft(1);f,c=self.d.describe();self.assertEqual(n,0);self.assertFalse(c)
 def test_core_absent_boundary(self):
  source=(ROOT/'src/deus_r51.cpp').read_text()
  self.assertIn('native_core false',source);self.assertNotIn('system(',source);self.assertNotIn('popen(',source)
if __name__=='__main__':unittest.main(verbosity=2)
