"""Task adapter to the PUBLIC reconstructed executable, not the private Native Core.
Reuses exact original R4.1 CanonicalEnvelope and lossless archive implementation.
No calling/minting owner credentials, remote dispatch or external LLMs.
"""
from pathlib import Path
import sys,hashlib,json
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'upstream/r41'))
from deus_one.contract import CanonicalEnvelope,lossless_pack,lossless_unpack

class AdapterRejected(ValueError):pass

def validate_request(req:CanonicalEnvelope):
    if not isinstance(req,CanonicalEnvelope):raise AdapterRejected('Typed request required')
    if req.data_class!='PUBLIC':raise AdapterRejected('Private data admission absent')
    if req.authority_ref or req.context_ref:raise AdapterRejected('No native authority or context adapter')
    if req.kind!='chess_standard_move':raise AdapterRejected('Not chess')
    if set(req.payload)!={'moves','budget_ms','engine_sha256'}:raise AdapterRejected('Payload schema')
    if type(req.payload['budget_ms']) is not int or not 1<=req.payload['budget_ms']<=60000:raise AdapterRejected('Budget')
    if type(req.payload['moves']) is not list or len(req.payload['moves'])>2000:raise AdapterRejected('History')
    import re
    if any(type(m) is not str or not re.fullmatch('[a-h][1-8][a-h][1-8][qnrb]?',m) for m in req.payload['moves']):raise AdapterRejected('Move grammar')
    actual=hashlib.sha256((ROOT/'bin/deus_r51').read_bytes()).hexdigest()
    if req.payload['engine_sha256']!=actual:raise AdapterRejected('Engine source custody changed')
    # Preserve exact job/source/role-history. This is encoding, NOT a claimed native core call.
    record={'subject':req.subject,'job':req.task_id,'fingerprint':req.fingerprint(),'payload':dict(req.payload),'scope':'PUBLIC_RECONSTRUCTION_ONLY'}
    packed=lossless_pack(record)
    if lossless_unpack(packed)!=record:raise AdapterRejected('Lossless checkpoint mismatch')
    return {'request_sha256':req.fingerprint(),'archive_sha256':hashlib.sha256(packed).hexdigest(),
            'archive_bytes':len(packed),'native_core_ack':False,'scope':'PUBLIC_RECONSTRUCTION_ONLY'}

def select_move(engine, moves, millis, game_id, ply):
    req=CanonicalEnvelope(subject='DEUS_CHESS_PUBLIC_RECONSTRUCTION',task_id=game_id,
       kind='chess_standard_move',data_class='PUBLIC',payload={'moves':list(moves),'budget_ms':millis,
       'engine_sha256':hashlib.sha256((ROOT/'bin/deus_r51').read_bytes()).hexdigest()},
       idempotency_key=f'{game_id}:{ply}',source_revision='R51-NEW-RECONSTRUCTION')
    receipt=validate_request(req);engine.position(moves);move,telemetry=engine.play(millis)
    receipt['output_uci']=move;receipt['output_sha256']=hashlib.sha256(move.encode()).hexdigest()
    telemetry['typed_adapter']=receipt
    return move,telemetry
