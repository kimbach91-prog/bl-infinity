from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'SOURCE_SHA256.json').read_text())
for rel,digest in manifest.items():
 p=root/rel
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:raise SystemExit('FAIL '+rel)
print(json.dumps({'source_files_verified':len(manifest),'scope':'PUBLIC_RECONSTRUCTION','original_R5_recovered':False,'native_core_bound':False}))
