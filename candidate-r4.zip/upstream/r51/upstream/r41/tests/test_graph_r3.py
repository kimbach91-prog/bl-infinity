import copy
import json
import unittest
from pathlib import Path
from deus_one.extension_r3 import validate_r3,R3Rejected,source_report,sha
from deus_one.pipeline_r3 import run_public_synthetic_r3
P=Path(__file__).resolve().parents[1]
R1=json.loads((P/'CAPABILITY_GRAPH_R1.json').read_text())
R2=json.loads((P/'CAPABILITY_EXTENSION_R2.json').read_text())
R3=json.loads((P/'CAPABILITY_EXTENSION_R3.json').read_text())

class GraphR3(unittest.TestCase):
    def test_complete(self):
        x=validate_r3(R1,R2,R3)
        self.assertEqual(x['node_count'],31);self.assertEqual(x['edge_count'],51)
    def test_total(self):
        r=source_report(R1,R2,R3);self.assertEqual((r['total_descriptive_nodes'],r['total_descriptive_edges']),(96,134));self.assertFalse(r['new_target_receipt'])
    def mutate(self,change):
        x=copy.deepcopy(R3);change(x)
        with self.assertRaises(R3Rejected):validate_r3(R1,R2,x)
    def test_new_ack_forged(self):self.mutate(lambda x:x.update(runtime_target_ack=True))
    def test_permission_forged(self):self.mutate(lambda x:x.update(live_native_adapter_bound=True))
    def test_weight_forged(self):self.mutate(lambda x:x.update(own_weight_checkpoint_included=True))
    def test_brain_fidelity_forged(self):self.mutate(lambda x:x.update(scientific_brain_fidelity_proven=True))
    def test_physical_credit_forged(self):self.mutate(lambda x:x.update(physical_compute_credited=True))
    def test_egg_private_forged(self):self.mutate(lambda x:x['nodes'][0].update(owner_private_included=True))
    def test_forecast_certainty_forged(self):self.mutate(lambda x:x['nodes'][0].update(forecast_certainty_claim=True))
    def test_node_callable_forged(self):self.mutate(lambda x:x['nodes'][0].update(runtime_callable=True))
    def test_edge_callable_forged(self):self.mutate(lambda x:x['edges'][0].update(runtime_callable=True))
    def test_false_prophecy_claim(self):self.mutate(lambda x:x['limits'].update(prophecy='CERTAIN'))
    def test_job_changed(self):self.mutate(lambda x:x['continuity'].update(child='OTHER'))
    def test_r2_source_changed(self):self.mutate(lambda x:x.update(r2_source_sha256='x'*64))
    def test_future_toy_promoted(self):
        self.mutate(lambda x:next(n for n in x['nodes'] if n['id']=='FORECAST-PUBLIC-TOY').update(state='HISTORICAL_SCOPED'))
    def test_duplicate_reference(self):self.mutate(lambda x:x['nodes'].append(copy.deepcopy(x['nodes'][0])) or x.update(node_count=len(x['nodes'])))
    def test_cross_version_cycle(self):
        def add(x):
            x['edges'].append({'from':'WEBSITE-R32','to':'NET-BRAIN-FED','kind':'RESEARCH_LINK','runtime_callable':False})
            x['edge_count']+=1
        self.mutate(add)
    def test_reverse_claims(self):
        self.assertFalse(run_public_synthetic_r3(R1,R2,R3)['verified_native_inference'])
    def test_pipeline_isolated(self):
        x=run_public_synthetic_r3(R1,R2,R3)
        self.assertEqual(x['forecast_scenario'],20);self.assertEqual(x['regression_path'],['now','step','goal'])
        self.assertFalse(x['owner_private_egress']);self.assertEqual(x['native_connector_or_model_calls'],0)
    def test_pipeline_deterministic(self):self.assertEqual(run_public_synthetic_r3(R1,R2,R3),run_public_synthetic_r3(R1,R2,R3))
