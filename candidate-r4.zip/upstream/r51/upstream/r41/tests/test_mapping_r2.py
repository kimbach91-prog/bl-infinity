"""Finite PUBLIC Φ/Ψ example, deliberately NOT native BL Mapping Context."""
import unittest
from dataclasses import replace
from deus_one.mapping import MappingWitness, MappingRejected, certify_finite_map


def witness():
    return MappingWitness(
        source_domain='PUBLIC_SYNTH_S', target_domain='PUBLIC_SYNTH_T',
        forward={'s0':'t0','s1':'t1','s2':'t2'},
        source_invariants={'s0':'cold','s1':'warm','s2':'hot'},
        target_invariants={'t0':'cold','t1':'warm','t2':'hot'},
        source_transition={'s0':'s1','s1':'s2','s2':'s2'},
        target_transition={'t0':'t1','t1':'t2','t2':'t2'})

class FiniteMappingTests(unittest.TestCase):
    def test_positive(self):
        c=certify_finite_map(witness())
        self.assertEqual(c['states_checked'],3)
        self.assertEqual(c['state'],'FINITE_SYNTHETIC_MAPPING_PASS')
        self.assertFalse(c['runtime_ack'])
        self.assertFalse(c['native_bl_mapping_executed'])
    def test_deterministic(self):
        self.assertEqual(certify_finite_map(witness()),certify_finite_map(witness()))
    def test_collapsing_nonidentical_states(self):
        w=witness();w.forward['s1']='t0'
        with self.assertRaises(MappingRejected):certify_finite_map(w)
    def test_changed_protected_invariant(self):
        w=witness();w.target_invariants['t0']='hot'
        with self.assertRaises(MappingRejected):certify_finite_map(w)
    def test_noncommuting_diagram(self):
        w=witness();w.target_transition['t1']='t0'
        with self.assertRaises(MappingRejected):certify_finite_map(w)
    def test_missing_state(self):
        w=witness();del w.source_transition['s1']
        with self.assertRaises(MappingRejected):certify_finite_map(w)
    def test_bad_transition_target(self):
        w=witness();w.target_transition['t0']='unknown'
        with self.assertRaises(MappingRejected):certify_finite_map(w)
    def test_wrong_data_class(self):
        with self.assertRaises(MappingRejected):certify_finite_map(replace(witness(),data_class='OWNER_PRIVATE'))
    def test_source_fake(self):
        with self.assertRaises(MappingRejected):certify_finite_map(replace(witness(),source_pin='Drive:forged'))
    def test_invalid_state_label(self):
        w=witness();w.forward['s0']=''
        with self.assertRaises(MappingRejected):certify_finite_map(w)
    def test_name_source_same_denied(self):
        with self.assertRaises(MappingRejected):certify_finite_map(replace(witness(),target_domain='PUBLIC_SYNTH_S'))
    def test_not_a_witness(self):
        with self.assertRaises(MappingRejected):certify_finite_map({'forward':{}})

if __name__ == '__main__':unittest.main()
