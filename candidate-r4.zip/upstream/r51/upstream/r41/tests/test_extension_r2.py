"""R2 extension must NOT mutate R1 truth or grant runtime admission."""
import unittest
import json
import copy
from pathlib import Path
from deus_one.architecture import validate_graph,graph_digest
from deus_one.extension import validate_extension,extension_summary,ExtensionRejected
R=Path(__file__).resolve().parent.parent

def source():
    return (json.loads((R/'CAPABILITY_GRAPH_R1.json').read_text(encoding='utf-8')),
            json.loads((R/'CAPABILITY_EXTENSION_R2.json').read_text(encoding='utf-8')))

class ExtensionTests(unittest.TestCase):
    def test_baseline_unchanged(self):
        b,x=source();validate_graph(b);validate_extension(b,x)
        self.assertEqual((len(b['nodes']),len(b['edges'])),(36,41))
        self.assertEqual((len(x['nodes']),len(x['edges'])),(29,42))
    def test_bounded_audit(self):
        b,x=source();p=extension_summary(b,x)
        self.assertFalse(p['runtime_ack']);self.assertFalse(p['neural_checkpoint'])
        self.assertFalse(p['private_core_copied'])
    def test_deterministic_extension_digest(self):
        b,x=source();self.assertEqual(extension_summary(b,x),extension_summary(b,x))
    def test_base_mutation_denied(self):
        b,x=source();b['nodes'][0]['label']='tampered'
        with self.assertRaises(ExtensionRejected):validate_extension(b,x)
    def test_forged_source_digest_denied(self):
        b,x=source();x['base_graph_sha256']='0'*64
        with self.assertRaises(ExtensionRejected):validate_extension(b,x)
    def test_relabel_as_runtime_denied(self):
        b,x=source();x['runtime_ack']=True
        with self.assertRaises(ExtensionRejected):validate_extension(b,x)
    def test_admit_adapter_denied(self):
        b,x=source();x['native_adapter_admission']=True
        with self.assertRaises(ExtensionRejected):validate_extension(b,x)
    def test_change_continuity_denied(self):
        b,x=source();x['continuity']['parent']='JOB-FOREIGN'
        with self.assertRaises(ExtensionRejected):validate_extension(b,x)
    def test_private_code_inclusion_denied(self):
        b,x=source();x['nodes'][0]['private_bytes_included']=True
        with self.assertRaises(ExtensionRejected):validate_extension(b,x)
    def test_forged_neuro_biological_fidelity(self):
        b,x=source();next(n for n in x['nodes'] if n['id']=='NEURO-TOY-LIF')['biological_fidelity_proven']=True
        with self.assertRaises(ExtensionRejected):validate_extension(b,x)
    def test_forged_model_weights(self):
        b,x=source();x['training_checkpoint_included']=True
        with self.assertRaises(ExtensionRejected):validate_extension(b,x)
    def test_promote_synthetic_surrogate(self):
        b,x=source();next(n for n in x['nodes'] if n['id']=='CELL-HOMEOSTASIS-SYNTH')['state']='SOURCE_SCOPED'
        with self.assertRaises(ExtensionRejected):validate_extension(b,x)
    def test_unverified_blx_promoted(self):
        b,x=source();next(n for n in x['nodes'] if n['id']=='LANG-BLX')['state']='SOURCE_SCOPED'
        with self.assertRaises(ExtensionRejected):validate_extension(b,x)
    def test_unknown_r2_source_denied(self):
        b,x=source();x['nodes'][0]['source_ref']='https://evil.invalid'
        with self.assertRaises(ExtensionRejected):validate_extension(b,x)
    def test_duplicate_base_node_denied(self):
        b,x=source();x['nodes'][0]['id']=b['nodes'][0]['id']
        with self.assertRaises(ExtensionRejected):validate_extension(b,x)
    def test_duplicate_new_edge_denied(self):
        b,x=source();x['edges'].append(copy.deepcopy(x['edges'][0]));x['edge_count']+=1
        with self.assertRaises(ExtensionRejected):validate_extension(b,x)
    def test_edge_to_undeclared_denied(self):
        b,x=source();x['edges'][0]['to']='FICTITIOUS'
        with self.assertRaises(ExtensionRejected):validate_extension(b,x)
    def test_edge_fake_runtime_denied(self):
        b,x=source();x['edges'][0]['runtime_callable']=True
        with self.assertRaises(ExtensionRejected):validate_extension(b,x)
    def test_cycle_across_r1_and_r2_denied(self):
        b,x=source();x['edges'].append({'from':'WEBSITE-R32','to':'BL-EYE2-MAP','kind':'RESEARCH_LINK','runtime_callable':False});x['edge_count']+=1
        with self.assertRaises(ExtensionRejected):validate_extension(b,x)
    def test_unknown_fields_denied(self):
        b,x=source();x['nodes'][0]['free_root']=True
        with self.assertRaises(ExtensionRejected):validate_extension(b,x)
    def test_effect_count_forged(self):
        b,x=source();x['effect_count']=1
        with self.assertRaises(ExtensionRejected):validate_extension(b,x)
    def test_no_hidden_arc_claim(self):
        b,x=source();x['limits']['official_arc_score']='100'
        with self.assertRaises(ExtensionRejected):validate_extension(b,x)

if __name__=='__main__':unittest.main()
