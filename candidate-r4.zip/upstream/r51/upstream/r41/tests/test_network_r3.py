import unittest
from deus_one.network_r3 import Cell, RouteRequest, NetworkRejected,route_public
class NetR3(unittest.TestCase):
    def setUp(self):
        self.cells=(Cell('a',('relay',),True,2),Cell('b',('relay',),True,2),Cell('c',('compute',),True,2))
        self.edges=(('a','b'),('b','c'))
        self.req=RouteRequest('a','c','compute')
    def test_route_no_lease(self):
        x=route_public(self.cells,self.edges,self.req)
        self.assertEqual(x['route'],['a','b','c']);self.assertFalse(x['native_dispatch']);self.assertFalse(x['provider_permission'])
    def test_bounded_most_short(self):
        self.assertEqual(route_public(self.cells,self.edges+(('a','c'),),self.req)['route'],['a','c'])
    def test_offline_holds(self):
        cells=(self.cells[0],Cell('b',('relay',),False,2),self.cells[2]);self.assertIn('HOLD',route_public(cells,self.edges,self.req)['state'])
    def test_no_capacity_holds(self):
        cells=(self.cells[0],Cell('b',('relay',),True,0),self.cells[2]);self.assertIn('HOLD',route_public(cells,self.edges,self.req)['state'])
    def test_no_capability_holds(self):self.assertIn('HOLD',route_public(self.cells,self.edges,RouteRequest('a','c','gpu'))['state'])
    def test_private_block(self):
        with self.assertRaises(NetworkRejected):route_public(self.cells,self.edges,RouteRequest('a','c','compute',data_class='OWNER_PRIVATE'))
    def test_side_effect_block(self):
        with self.assertRaises(NetworkRejected):route_public(self.cells,self.edges,RouteRequest('a','c','compute',effect='DEPLOY'))
    def test_duplicate_node(self):
        with self.assertRaises(NetworkRejected):route_public(self.cells+(self.cells[0],),self.edges,self.req)
    def test_unknown_endpoint(self):
        with self.assertRaises(NetworkRejected):route_public(self.cells,self.edges+(('x','c'),),self.req)
    def test_duplicate_edge(self):
        with self.assertRaises(NetworkRejected):route_public(self.cells,self.edges+(('a','b'),),self.req)
    def test_cycle_finite(self):self.assertEqual(route_public(self.cells,self.edges+(('c','a'),),self.req)['route'],['a','b','c'])
    def test_fake_private_ceiling_block(self):
        with self.assertRaises(NetworkRejected):route_public((Cell('a',('relay',),True,2,data_ceiling='OWNER_PRIVATE'),)+self.cells[1:],self.edges,self.req)
    def test_bool_capacity_rejected(self):
        with self.assertRaises(NetworkRejected):route_public((Cell('a',('relay',),True,True),)+self.cells[1:],self.edges,self.req)
