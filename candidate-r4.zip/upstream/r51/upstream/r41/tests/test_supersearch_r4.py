import unittest
from dataclasses import replace
from deus_one.supersearch_r4 import SourceCard,SearchError,search_metadata,triangulate,coverage
A=SourceCard('sourceA01','BL HyperWeave 6D','F14','sourceDriveA',aliases=('multilayer compression',))
B=SourceCard('sourceB02','Mirror HyperWeave','F14','sourceDriveA',source_kind='LIVEBUS_TAB')
C=SourceCard('sourceC03','World Tree Search','F04','sourceGithubB',source_kind='GITHUB_PATH')
X=SourceCard('sourceX04','PHD unrelated','F00','sourcePHD04',principal='PHD')
U=SourceCard('sourceU05','Unknown source','F00','sourceUNKN',principal='UNKNOWN')
class SearchR4Tests(unittest.TestCase):
    def test_alias(self):
        o=search_metadata((A,B,C),'multilayer compression')
        self.assertEqual(1,o['matched']);self.assertFalse(o['contents_examined'])
    def test_independent_mirror_false(self):
        o=triangulate((A,B),('sourceA01','sourceB02'))
        self.assertEqual(1,o['independent_lineages_claimable'])
        self.assertFalse(o['mirror_is_independent'])
    def test_distinct_lineages_not_verified_fact(self):
        o=triangulate((A,C),('sourceA01','sourceC03'))
        self.assertEqual(2,o['independent_lineages_claimable'])
        self.assertFalse(o['validated_factual_claim'])
    def test_owner_isolation(self):
        o=search_metadata((A,X,U),'unrelated')
        self.assertEqual(0,o['matched']);self.assertEqual(2,o['excluded_nonowner_or_unknown'])
    def test_audit_open(self):
        o=coverage((A,B,C),('F04','F14','F25'))
        self.assertEqual(['F25'],o['missing_families'])
        self.assertFalse(o['whole_deus_coverage_verified'])
    def test_august_assertion_blocked(self):
        with self.assertRaises(SearchError):coverage((A,),('F14',),primary_august_verified=True)
    def test_fake_denominator_blocked(self):
        with self.assertRaises(SearchError):coverage((A,),('F14',),full_census_denominator=1)
    def test_duplicate_id(self):
        with self.assertRaises(SearchError):search_metadata((A,A),'HyperWeave')
    def test_wrong_principal_excluded_from_triangulation(self):
        v=triangulate((A,X),('sourceA01','sourceX04'))
        self.assertEqual(1,v['excluded_scope_count'])
    def test_bad_unknown_family(self):
        with self.assertRaises(SearchError):coverage((replace(A,family='F99'),),('F14',))
    def test_unknown_source_ref(self):
        with self.assertRaises(SearchError):triangulate((A,),('sourceZ99',))
    def test_empty_query(self):
        with self.assertRaises(SearchError):search_metadata((A,),'')
    def test_no_native_search(self):
        self.assertFalse(search_metadata((A,),'HyperWeave')['search_is_native_deus'])
    def test_duplicate_refs(self):
        with self.assertRaises(SearchError):triangulate((A,),('sourceA01','sourceA01'))
    def test_casefold(self):
        self.assertEqual(1,search_metadata((A,),'bL hyPERweave 6D')['matched'])
    def test_unclassified_kept(self):
        owner=replace(X,principal='BACH')
        self.assertEqual(1,coverage((A,owner),('F14','F00'))['unclassified_metadata'])
