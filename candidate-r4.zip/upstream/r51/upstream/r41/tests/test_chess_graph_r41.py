"""Public metadata graph gates. Does not touch the owner-native controller."""
import json
from pathlib import Path
from hashlib import sha256
import unittest
ROOT=Path(__file__).resolve().parent.parent
G=lambda:json.loads((ROOT/'CAPABILITY_EXTENSION_R41.json').read_text())

class ChessGraphGate(unittest.TestCase):
    def test_R4_continuity(self):
        x=G();self.assertEqual(x['continuity']['parent_job'],'JOB-DEUS-WORKSPACE-NATIVE-ACCEPTANCE-20261003-001')
        self.assertEqual(x['continuity']['predecessor_R4_sha256'],'15c644868f1ddd96de239d1f61f6e2540f553d82d9aa7c1aeea12459a76196d3')
    def test_scoped_nodes_and_edges(self):
        x=G();self.assertEqual((x['node_count'],x['edge_count']),(7,9))
        self.assertEqual((x['total_descriptive_nodes'],x['total_descriptive_edges']),(146,213))
        ids=[j['id'] for j in x['nodes']];self.assertEqual(len(ids),len(set(ids)))
        prior_ids=[]
        for name in ('CAPABILITY_GRAPH_R1.json','CAPABILITY_EXTENSION_R2.json','CAPABILITY_EXTENSION_R3.json','CAPABILITY_EXTENSION_R4.json'):
            prior_ids +=[n['id'] for n in json.loads((ROOT/name).read_text())['nodes']]
        known=set(prior_ids)|set(ids)
        self.assertTrue(all(e['from'] in known and e['to'] in known for e in x['edges']))
    def test_no_unearned_100x_comparison_or_runtime(self):
        x=G();self.assertFalse(x['actual_chess_engine_100x_match_verified'])
        for field in ('runtime_target_ack','native_adapters_bound','trained_weight_checkpoint_created','complete_chess_solved'):
            self.assertFalse(x[field])
        self.assertTrue(all(not n['runtime_callable'] and not n['private_bytes_included'] for n in x['nodes']))
    def test_provenance_only_public_archival(self):
        x=G();t=[n for n in x['nodes'] if n['id']=='CHESS-KQK-RETROGRADE'][0]
        self.assertTrue(t['source_ref'].startswith('Drive:'))
        self.assertEqual(t['state'],'LOCAL_PUBLIC_INDEPENDENT_PASS')
        self.assertEqual([z['state'] for z in x['nodes'] if z['id']=='CHESS-100X-COMPUTE-CLAIM'],['UNVERIFIED'])
    def test_full_R4_source_file_immutability(self):
        b=json.loads((ROOT/'R4_INHERITANCE_R41.json').read_text())
        self.assertEqual(len(b['files']),78)
        for name,digest in b['files'].items():
            self.assertEqual(sha256((ROOT/name).read_bytes()).hexdigest(),digest,name)

if __name__=='__main__':unittest.main()
