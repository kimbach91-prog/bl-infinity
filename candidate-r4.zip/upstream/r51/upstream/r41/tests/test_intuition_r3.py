import unittest
from deus_one.intuition_r3 import Cue,IntuitionRejected,hypothesis_triage
class IntuitionR3(unittest.TestCase):
    def setUp(self):self.cues=(Cue('H','one','g1',True,1),Cue('H','two','g2',True,2))
    def test_hypothesis_not_truth(self):
        x=hypothesis_triage(self.cues,2)
        self.assertEqual(x['candidates'][0]['state'],'PUBLIC_HYPOTHESIS_FOR_TEST')
        self.assertFalse(x['confidence_calibrated']);self.assertFalse(x['supernatural_claim'])
    def test_dissent_withholds(self):self.assertIn('HOLD',hypothesis_triage((self.cues[0],Cue('H','two','g2',False,2)),2)['candidates'][0]['state'])
    def test_duplicate_group_not_independent(self):
        with self.assertRaises(IntuitionRejected):hypothesis_triage((self.cues[0],Cue('H','same','g1',True,2)),2)
    def test_future_leakage(self):
        with self.assertRaises(IntuitionRejected):hypothesis_triage(self.cues,1)
    def test_private_denied(self):
        with self.assertRaises(IntuitionRejected):hypothesis_triage((self.cues[0],Cue('H','two','g2',True,2,data_class='OWNER_PRIVATE')),2)
    def test_bool_as_of(self):
        with self.assertRaises(IntuitionRejected):hypothesis_triage(self.cues,True)
    def test_not_enough(self):
        with self.assertRaises(IntuitionRejected):hypothesis_triage(self.cues[:1],2)
    def test_unknown_namespace(self):
        with self.assertRaises(IntuitionRejected):hypothesis_triage((Cue('H..','one','g1',True,1),self.cues[1]),2)
    def test_multi_hypothesis(self):
        x=hypothesis_triage(self.cues+(Cue('J','3','g3',True,2),Cue('J','4','g4',False,2)),2)
        self.assertEqual(len(x['candidates']),2)
