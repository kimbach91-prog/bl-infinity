import unittest
from dataclasses import replace
from deus_one.resources_r4 import Vector,Node,Demand,ResourceError,place_public
A=Node('a',Vector((8,8192,0,2000,200,100)),10,6)
B=Node('b',Vector((4,1024,0,2000,200,50)),7,3)
D=Demand(Vector((3,3000,0,0,10,10)),20,10)
class MultiResourceTests(unittest.TestCase):
    def test_single_fit(self):
        x=place_public((A,B),D)
        self.assertEqual('a',x['suggestion']['node'])
        self.assertFalse(x['lease_obtained'])
    def test_unusable_resources_do_not_add(self):
        self.assertIsNone(place_public((Node('x',Vector((9,10,0,0,0,0)),0,0),Node('y',Vector((0,9000,0,0,0,0)),0,0)),D)['suggestion'])
    def test_vram_mandatory(self):
        self.assertIsNone(place_public((A,),replace(D,required=Vector((1,1,1,0,0,0))))['suggestion'])
    def test_latency_cap(self):
        self.assertIsNone(place_public((A,),replace(D,max_latency_ms=9))['suggestion'])
    def test_cost_cap(self):
        self.assertIsNone(place_public((A,),replace(D,max_cost_microunits=5))['suggestion'])
    def test_tie_deterministic(self):
        x=place_public((A,replace(A,name='aa')),D)
        self.assertEqual('a',x['suggestion']['node'])
    def test_replay_digest_stable(self):
        self.assertEqual(place_public((A,),D)['witness_sha256'],place_public((A,),D)['witness_sha256'])
    def test_unknown_not_allowed(self):
        with self.assertRaises(ResourceError):place_public((replace(A,freshness='2026-08-01'),),D)
    def test_private_no(self):
        with self.assertRaises(ResourceError):place_public((A,),replace(D,data_class='OWNER_PRIVATE'))
    def test_effect_no(self):
        with self.assertRaises(ResourceError):place_public((A,),replace(D,effect='DEPLOY'))
    def test_unhealthy(self):
        self.assertIsNone(place_public((replace(A,healthy=False),),D)['suggestion'])
    def test_float(self):
        with self.assertRaises(ResourceError):place_public((replace(A,capacity=Vector((1.2,100,0,0,0,0))),),D)
    def test_duplicate_node(self):
        with self.assertRaises(ResourceError):place_public((A,A),D)
    def test_overbound(self):
        with self.assertRaises(ResourceError):place_public(tuple(replace(A,name='n'+str(i)) for i in range(33)),D)
    def test_report_no_physical(self):
        x=place_public((A,),D)
        self.assertFalse(x['measured_physical_capacity'])
        self.assertFalse(x['cross_node_aggregation'])
