"""Source-bound PUBLIC chess KQK endgame tests, NEVER owner-native release QA."""
from pathlib import Path
from hashlib import sha256
import json
import shutil
import unittest
from deus_one.chess_endgame_r41 import (
    REFERENCE_FILE, KQK_EXPECTED, run_scoped_kqk, TaskNotAdmitted, NegativeVerifier)

ROOT=Path(__file__).resolve().parent.parent
SPEC={
    'task_id':'R41-LOCAL-PUBLIC-KQK-001',
    'data_class':'PUBLIC',
    'domain':'KQK',
    'scope':'LOCAL_REFERENCE_ONLY',
    'effects':'NONE',
    'source_class':'PUBLIC_REFERENCE_ONLY',
}

def digest():return sha256((ROOT/REFERENCE_FILE).read_bytes()).hexdigest()

class ChessRetrograde(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not shutil.which('g++'):raise unittest.SkipTest('Local C++ compiler not installed')
        cls.result=run_scoped_kqk(SPEC,ROOT,digest())

    def test_full_kqk_state_space_and_retrograde(self):
        self.assertEqual({k:self.result['result'][k] for k in KQK_EXPECTED},KQK_EXPECTED)

    def test_fide_like_three_piece_witness_is_five_ply(self):
        r=self.result['result'];self.assertEqual(r['example_DTM_ply'],5)
        self.assertRegex(r['example_FEN'],r'^[1-8KQk/]+ w - - 0 1$')
        self.assertEqual(len(r['example_uci'].split()),5)

    def test_private_data_is_not_admitted(self):
        with self.assertRaises(TaskNotAdmitted):
            run_scoped_kqk({**SPEC,'data_class':'OWNER_PRIVATE'},ROOT,digest())

    def test_forged_ack_and_extra_authority_rejected(self):
        with self.assertRaises(TaskNotAdmitted):
            run_scoped_kqk({**SPEC,'runtime_target_ack':True},ROOT,digest())

    def test_claim_of_100x_head_to_head_not_conferred(self):
        r=self.result;self.assertFalse(r['historical_100x_head_to_head_verified'])
        self.assertIsNone(r['actual_compute_advantage_claim'])
        self.assertFalse(r['native_executor_ack'])

    def test_tampered_source_sha_rejected(self):
        with self.assertRaises(NegativeVerifier):
            run_scoped_kqk(SPEC,ROOT,'0'*64)

    def test_different_domain_is_rejected(self):
        with self.assertRaises(TaskNotAdmitted):
            run_scoped_kqk({**SPEC,'domain':'FULL_CHESS'},ROOT,digest())

    def test_absent_effectful_access_rejected(self):
        with self.assertRaises(TaskNotAdmitted):
            run_scoped_kqk({**SPEC,'effects':'REMOTE_DISPATCH'},ROOT,digest())

if __name__=='__main__':unittest.main(verbosity=2)
