import unittest
from deus_one.supermapping_r4 import AXES,AxisBridge,MappingError,map_public,commutation_test
S=tuple((a,'s0') for a in AXES)
A=AxisBridge('DOMAIN',(('s0','x'),('s1','y')))
B=AxisBridge('TIME',(('s0','t0'),))
class SupermappingTests(unittest.TestCase):
    def test_bijective(self):
        x=map_public(S,(A,B));self.assertTrue(x['inverse_roundtrip'])
        self.assertEqual('x',dict(x['mapped'])['DOMAIN'])
    def test_six_preserved(self):
        self.assertEqual(6,len(map_public(S,(A,))['protected_axes_preserved']))
    def test_commute_independent(self):
        self.assertTrue(commutation_test(S,A,B)['commutes'])
    def test_dependent_not_assumed(self):
        with self.assertRaises(MappingError):commutation_test(S,A,AxisBridge('DOMAIN',(('s0','z'),)))
    def test_noninjective_reject(self):
        with self.assertRaises(MappingError):map_public(S,(AxisBridge('DOMAIN',(('s0','x'),('s1','x'))),))
    def test_duplicate_source_reject(self):
        with self.assertRaises(MappingError):map_public(S,(AxisBridge('DOMAIN',(('s0','x'),('s0','y'))),))
    def test_missing_source_reject(self):
        with self.assertRaises(MappingError):map_public(S,(AxisBridge('DOMAIN',(('s1','x'),)),))
    def test_missing_axis(self):
        with self.assertRaises(MappingError):map_public(S[:-1],(A,))
    def test_bad_value(self):
        with self.assertRaises(MappingError):map_public(tuple((a,'bad:secret?') for a in AXES),(A,))
    def test_no_runtime(self):
        r=map_public(S,(A,));self.assertFalse(r['runtime_ack'])
    def test_no_real_cross_domain_equivalence(self):
        r=commutation_test(S,A,B);self.assertFalse(r['trusted_cross_domain_equivalence'])
    def test_same_axis_repeat_blocked(self):
        with self.assertRaises(MappingError):map_public(S,(A,A))
