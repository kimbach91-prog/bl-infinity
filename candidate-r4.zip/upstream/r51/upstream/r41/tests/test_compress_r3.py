import unittest
from deus_one.compress_r3 import exact_evidence_reuse,CompressionRejected
class CompressionR3(unittest.TestCase):
    def setUp(self):
        self.r={'id':'r','source':'LiveBus:A2','version':'v1','data_class':'PUBLIC',
                'status':'UNKNOWN','scar':'unknown_future','content':'still unknown'}
    def test_exact_duplicate(self):
        x=exact_evidence_reuse([self.r,self.r]);self.assertEqual(x['unique_count'],1);self.assertEqual(x['unknown_retained'],2)
    def test_reconstruction(self):
        x=exact_evidence_reuse([self.r,self.r]);self.assertEqual([x['dictionary'][k] for k in x['references']],[self.r,self.r])
    def test_replay_digest_stable(self):
        x=exact_evidence_reuse([self.r]);y=exact_evidence_reuse([self.r]);self.assertEqual(x['references'],y['references'])
    def test_changed_same_id_rejected(self):
        with self.assertRaises(CompressionRejected):exact_evidence_reuse([self.r,self.r|{'content':'changed'}])
    def test_changed_status_rejected(self):
        with self.assertRaises(CompressionRejected):exact_evidence_reuse([self.r,self.r|{'status':'PASS'}])
    def test_unknown_without_scar_rejected(self):
        with self.assertRaises(CompressionRejected):exact_evidence_reuse([self.r|{'scar':''}])
    def test_failed_scar_preserved(self):
        x=exact_evidence_reuse([self.r|{'status':'FAIL'}]);self.assertEqual(x['fail_retained'],1)
    def test_private_rejected(self):
        with self.assertRaises(CompressionRejected):exact_evidence_reuse([self.r|{'data_class':'OWNER_PRIVATE'}])
    def test_missing_data_class_rejected(self):
        x=dict(self.r);del x['data_class'];
        with self.assertRaises(CompressionRejected):exact_evidence_reuse([x])
    def test_unknown_extra_authority_key_rejected(self):
        with self.assertRaises(CompressionRejected):exact_evidence_reuse([self.r|{'authority':'GRANTED'}])
    def test_not_live(self):
        x=exact_evidence_reuse([self.r]);self.assertFalse(x['native_compression_executed']);self.assertFalse(x['runtime_ack'])
    def test_bad_source(self):
        with self.assertRaises(CompressionRejected):exact_evidence_reuse([self.r|{'source':'http://private.test'}])
    def test_bool_status_rejected(self):
        with self.assertRaises(CompressionRejected):exact_evidence_reuse([self.r|{'status':True}])
