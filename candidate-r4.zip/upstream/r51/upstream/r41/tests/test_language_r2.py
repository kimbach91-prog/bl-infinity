"""No real BLmu/BLsigma/HHIR executable adapter is imported here."""
import unittest
import copy
from deus_one.languages import (
    encode_ir, decode_ir, descriptive_language_route, LanguageRejected,
    LANGUAGE_STATES,
)

def packet(t='INT',v=42):
    return {'schema':'deus-one-r2-synthetic-datacodec/1','task_id':'task-r2-001',
            'role':'tool','data_class':'PUBLIC','effect':'PURE',
            'semantic_type':t,'source_sha256':'a'*64,'value':v}

class PublicDataLanguageTests(unittest.TestCase):
    def test_integer_roundtrip(self):
        p=packet();self.assertEqual(decode_ir(encode_ir(p)),p)
    def test_bool_roundtrip(self):
        p=packet('BOOL',True);self.assertEqual(decode_ir(encode_ir(p)),p)
    def test_vi_text_roundtrip(self):
        p=packet('TEXT','Kiểm chứng ngữ cảnh và sự bảo toàn kiểu');
        self.assertEqual(decode_ir(encode_ir(p)),p)
    def test_vector_roundtrip(self):
        p=packet('INT_VEC',[0,42,-12]);self.assertEqual(decode_ir(encode_ir(p)),p)
    def test_deterministic_dual_format(self):
        p=packet('TEXT','Sự thật nguồn');self.assertEqual(encode_ir(p),encode_ir(p))
    def test_roles_not_flattened(self):
        for role in ['system','user','assistant','tool']:
            p=packet();p['role']=role
            self.assertEqual(decode_ir(encode_ir(p))['role'],role)
    def test_tamper_tagged_fields(self):
        e=encode_ir(packet());e['tagged_fields'][0][1]='another-class'
        with self.assertRaises(LanguageRejected):decode_ir(e)
    def test_tamper_sha(self):
        e=encode_ir(packet());e['sha256']='0'*64
        with self.assertRaises(LanguageRejected):decode_ir(e)
    def test_tamper_json(self):
        e=encode_ir(packet());e['canonical_json']=e['canonical_json'].replace('42','43')
        with self.assertRaises(LanguageRejected):decode_ir(e)
    def test_metadata_cannot_claim_runtime_ack(self):
        e=encode_ir(packet());e['runtime_ack']=True
        with self.assertRaises(LanguageRejected):decode_ir(e)
    def test_private_denied(self):
        p=packet();p['data_class']='OWNER_PRIVATE'
        with self.assertRaises(LanguageRejected):encode_ir(p)
    def test_effect_denied(self):
        p=packet();p['effect']='NETWORK'
        with self.assertRaises(LanguageRejected):encode_ir(p)
    def test_unknown_type(self):
        p=packet();p['semantic_type']='NEURAL_INFERENCE'
        with self.assertRaises(LanguageRejected):encode_ir(p)
    def test_int_bool_confusion(self):
        with self.assertRaises(LanguageRejected):encode_ir(packet('INT',True))
    def test_vector_with_bool(self):
        with self.assertRaises(LanguageRejected):encode_ir(packet('INT_VEC',[True,4]))
    def test_bad_role(self):
        p=packet();p['role']='owner-admit'
        with self.assertRaises(LanguageRejected):encode_ir(p)
    def test_hidden_field(self):
        p=packet();p['grant']='root'
        with self.assertRaises(LanguageRejected):encode_ir(p)
    def test_unversioned_source(self):
        p=packet();p['source_sha256']='unknown'
        with self.assertRaises(LanguageRejected):encode_ir(p)
    def test_descriptive_no_permission_for_all_languages(self):
        for name in LANGUAGE_STATES:
            state=descriptive_language_route(name)
            self.assertTrue(state.startswith('HOLD_'))
    def test_blx_missing_semantics(self):
        self.assertEqual(descriptive_language_route('BL-X'),'HOLD_LANGUAGE_SEMANTICS_UNKNOWN')
    def test_candidate_dialect_not_real(self):
        self.assertEqual(descriptive_language_route('BL-INFINITY-C'),'HOLD_COMPILER_NOT_ADMITTED')
    def test_unknown_language(self):
        self.assertEqual(descriptive_language_route('MagicLang'),'HOLD_UNKNOWN_LANGUAGE')
    def test_private_route(self):
        self.assertEqual(descriptive_language_route('BLmu','OWNER_PRIVATE'),'HOLD_DATA_AUTHORITY')

if __name__=='__main__':unittest.main()
