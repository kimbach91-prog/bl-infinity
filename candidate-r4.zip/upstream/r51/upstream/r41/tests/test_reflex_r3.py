import unittest
from deus_one.reflex_r3 import Signal, ReflexRejected, simulate_reflex
class ReflexR3(unittest.TestCase):
    def test_salience(self):self.assertEqual(simulate_reflex((Signal(0,4),))['attention_count'],1)
    def test_inhibition(self):self.assertEqual(simulate_reflex((Signal(0,4,3),))['attention_count'],0)
    def test_refractory(self):self.assertEqual(simulate_reflex((Signal(0,4),Signal(1,4),Signal(2,4)))['attention_count'],2)
    def test_toy_only(self):
        x=simulate_reflex((Signal(0,4),))
        for k in ('native_bio_reflex_executed','real_world_action','authority_granted','runtime_ack','biological_fidelity_proven'):
            self.assertFalse(x[k])
    def test_private_block(self):
        with self.assertRaises(ReflexRejected):simulate_reflex((Signal(0,4,data_class='OWNER_PRIVATE'),))
    def test_wrong_tick(self):
        with self.assertRaises(ReflexRejected):simulate_reflex((Signal(3,4),))
    def test_negative_stimulus(self):
        with self.assertRaises(ReflexRejected):simulate_reflex((Signal(0,-1),))
    def test_boolean_stimulus(self):
        with self.assertRaises(ReflexRejected):simulate_reflex((Signal(0,True),))
    def test_too_many(self):
        with self.assertRaises(ReflexRejected):simulate_reflex(tuple(Signal(i,4) for i in range(81)))
    def test_invalid_threshold(self):
        with self.assertRaises(ReflexRejected):simulate_reflex((Signal(0,4),),threshold=0)
    def test_energy_budget(self):self.assertTrue(all(0<=f['remaining_energy']<=1 for f in simulate_reflex((Signal(0,4),Signal(1,4),Signal(2,4)),energy_max=1)['frames']))
    def test_deterministic_digest(self):
        s=(Signal(0,4),Signal(1,4));self.assertEqual(simulate_reflex(s)['trace_sha256'],simulate_reflex(s)['trace_sha256'])
