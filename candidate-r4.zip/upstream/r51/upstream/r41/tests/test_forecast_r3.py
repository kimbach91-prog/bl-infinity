import unittest
from deus_one.forecast_r3 import Window, ForecastRejected, forecast_public,Backchain,backchain_public

class ForecastR3(unittest.TestCase):
    def setUp(self):self.good=Window((0,1,2,3,4),(10,12,14,16,18),4)
    def test_historical_linear(self):
        x=forecast_public(self.good);self.assertEqual(x['forecast_value'],20)
        self.assertFalse(x['future_observed']);self.assertFalse(x['probability_calibrated'])
    def test_horizon(self):self.assertEqual(forecast_public(Window((0,1,2,3,4),(10,12,14,16,18),4,3))['forecast_value'],24)
    def test_drift_rejected(self):self.assertIn('HOLD',forecast_public(Window((0,1,2,3,4),(10,12,14,16,80),4))['state'])
    def test_private_fail(self):
        with self.assertRaises(ForecastRejected):forecast_public(Window(self.good.ticks,self.good.values,4,data_class='OWNER_PRIVATE'))
    def test_future_leakage(self):
        with self.assertRaises(ForecastRejected):forecast_public(Window(self.good.ticks,self.good.values,3))
    def test_skipped_timestamp(self):
        with self.assertRaises(ForecastRejected):forecast_public(Window((0,1,2,4,5),self.good.values,5))
    def test_duplicate_timestamp(self):
        with self.assertRaises(ForecastRejected):forecast_public(Window((0,1,2,2,3),self.good.values,3))
    def test_boolean_value(self):
        with self.assertRaises(ForecastRejected):forecast_public(Window(self.good.ticks,(10,12,True,16,18),4))
    def test_large_series(self):
        with self.assertRaises(ForecastRejected):forecast_public(Window(tuple(range(65)),tuple(range(65)),64))
    def test_bad_horizon(self):
        with self.assertRaises(ForecastRejected):forecast_public(Window(self.good.ticks,self.good.values,4,horizon=0))
    def test_odd_median_fraction_abstains(self):
        with self.assertRaises(ForecastRejected):forecast_public(Window((0,1,2,3,4,5),(10,11,12,14,16,18),5))
    def test_actual_goal_path(self):
        a=backchain_public(Backchain('now','goal',(('now','mid'),('mid','goal'))));self.assertEqual(a['path'],['now','mid','goal']);self.assertFalse(a['runtime_ack'])
    def test_unreachable_holds(self):self.assertIn('HOLD',backchain_public(Backchain('now','goal',(('no','goal'),)))['state'])
    def test_private_backchain(self):
        with self.assertRaises(ForecastRejected):backchain_public(Backchain('now','goal',(('now','goal'),),data_class='OWNER_PRIVATE'))
    def test_cycles_stop(self):self.assertEqual(backchain_public(Backchain('now','goal',(('now','mid'),('mid','now'),('mid','goal'))))['steps'],2)
    def test_duplicate_transition(self):
        with self.assertRaises(ForecastRejected):backchain_public(Backchain('now','goal',(('now','goal'),('now','goal'))))
    def test_wrong_depth(self):self.assertIn('HOLD',backchain_public(Backchain('now','goal',(('now','mid'),('mid','goal')),max_depth=1))['state'])
