"""R2 public local composition is evidence of integration only in this toy harness."""
from pathlib import Path
import json
import unittest
from dataclasses import replace
from deus_one.mapping import MappingWitness,MappingRejected
from deus_one.neuro import Synapse,NeuroScenario,NeuroRejected
from deus_one.pipeline_r2 import compose_public_reference,CompositionRejected
from deus_one.extension import ExtensionRejected
ROOT=Path(__file__).resolve().parent.parent

def fixtures():
    base=json.loads((ROOT/'CAPABILITY_GRAPH_R1.json').read_text())
    ext=json.loads((ROOT/'CAPABILITY_EXTENSION_R2.json').read_text())
    mapping=MappingWitness(source_domain='S',target_domain='T',forward={'s0':'t0','s1':'t1'},
        source_invariants={'s0':'x','s1':'y'},target_invariants={'t0':'x','t1':'y'},
        source_transition={'s0':'s1','s1':'s1'},target_transition={'t0':'t1','t1':'t1'})
    scenario=NeuroScenario(nodes=2,synapses=(Synapse(0,1,2),),stimuli=((4,0),(0,2),(4,0),(0,2)))
    return base,ext,mapping,scenario

class IntegrationTests(unittest.TestCase):
    def test_one_inert_typed_flow(self):
        b,x,m,n=fixtures();p=compose_public_reference(b,x,m,n,'TASK-R2-01')
        self.assertTrue(p['integrity_replay']);self.assertFalse(p['runtime_ack'])
        self.assertEqual(p['external_model_calls'],0)
        self.assertFalse(p['independent_native_verifier'])
        self.assertEqual(p['state'],'PUBLIC_SYNTHETIC_COMPOSITION_ONLY')
    def test_deterministic_replay(self):
        b,x,m,n=fixtures()
        self.assertEqual(compose_public_reference(b,x,m,n,'T'),compose_public_reference(b,x,m,n,'T'))
    def test_disjoint_task_ids(self):
        b,x,m,n=fixtures();a=compose_public_reference(b,x,m,n,'A');c=compose_public_reference(b,x,m,n,'B')
        self.assertNotEqual(a['typed_packet_digest'],c['typed_packet_digest'])
    def test_wrong_base_fails(self):
        b,x,m,n=fixtures();b['nodes'][0]['status']='UNKNOWN'
        with self.assertRaises(ExtensionRejected):compose_public_reference(b,x,m,n,'T')
    def test_mapping_loss_fails(self):
        b,x,m,n=fixtures();m.forward['s1']='t0'
        with self.assertRaises(MappingRejected):compose_public_reference(b,x,m,n,'T')
    def test_private_data_denied(self):
        b,x,m,n=fixtures()
        with self.assertRaises(NeuroRejected):compose_public_reference(b,x,m,replace(n,data_class='OWNER_PRIVATE'),'T')
    def test_unknown_task_id(self):
        b,x,m,n=fixtures()
        with self.assertRaises(CompositionRejected):compose_public_reference(b,x,m,n,'../../AB')

if __name__=='__main__':unittest.main()
