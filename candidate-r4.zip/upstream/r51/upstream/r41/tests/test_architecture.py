"""Metadata-only R1 negative coverage; production and owner-private DEUS untouched."""
import copy
import json
import pathlib
import unittest
from deus_one.architecture import (
    validate_graph, graph_digest, GraphContractError, candidate_binding_state,
    report_summary,
)
P=pathlib.Path(__file__).resolve().parent.parent/'CAPABILITY_GRAPH_R1.json'

def fresh():
    return json.loads(P.read_text(encoding='utf-8'))

class ArchitectureContractTests(unittest.TestCase):
    def test_complete_manifest(self):
        g=validate_graph(fresh())
        self.assertEqual((len(g['nodes']),len(g['edges'])),(36,41))
        self.assertEqual(g['effectful_admission'],False)
    def test_reproducible_digest(self):
        a=fresh();b=fresh()
        b['nodes'][0]['purpose']=b['nodes'][0]['purpose']
        self.assertEqual(graph_digest(a),graph_digest(b))
        self.assertEqual(report_summary(a)['digest'],graph_digest(a))
    def test_cannot_force_runtime_ack(self):
        x=fresh();x['runtime_target_ack']=True
        with self.assertRaises(GraphContractError):validate_graph(x)
    def test_cannot_admit_native_capability(self):
        x=fresh();x['nodes'][0]['admitted']=True
        with self.assertRaises(GraphContractError):validate_graph(x)
    def test_private_is_not_admitted(self):
        self.assertEqual(candidate_binding_state(fresh(),'MATRIX-CORE','OWNER_PRIVATE'), 'HOLD_PRIVATE_ADMISSION')
    def test_public_needs_native_lease(self):
        self.assertEqual(candidate_binding_state(fresh(),'MATRIX-CORE','PUBLIC'), 'HOLD_NATIVE_ADAPTER_AND_LEASE_NOT_BOUND')
    def test_fake_data_class(self):
        with self.assertRaises(GraphContractError):candidate_binding_state(fresh(),'MATRIX-CORE','UNCLASSIFIED')
    def test_no_unknown_atoms(self):
        with self.assertRaises(GraphContractError):candidate_binding_state(fresh(),'COUNCIL-FAKE','PUBLIC')
    def test_missing_node_denied(self):
        x=fresh();x['nodes'].pop();x['node_count']-=1
        with self.assertRaises(GraphContractError):validate_graph(x)
    def test_duplicate_nodes_denied(self):
        x=fresh();x['nodes'][1]['id']=x['nodes'][0]['id']
        with self.assertRaises(GraphContractError):validate_graph(x)
    def test_bad_source_denied(self):
        x=fresh();x['nodes'][0]['source']='https://malicious.example/admit'
        with self.assertRaises(GraphContractError):validate_graph(x)
    def test_forged_internal_weights_denied(self):
        x=fresh();x['nodes'][0]['model_weights_included']=True
        with self.assertRaises(GraphContractError):validate_graph(x)
    def test_unverified_cell_cannot_self_promote(self):
        x=fresh();next(n for n in x['nodes'] if n['id']=='BIO-CELL-SIM')['status']='SCOPED_TEST'
        with self.assertRaises(GraphContractError):validate_graph(x)
    def test_unverified_brain_cannot_self_promote(self):
        x=fresh();next(n for n in x['nodes'] if n['id']=='BIO-BRAIN-SIM')['status']='SCOPED_TEST'
        with self.assertRaises(GraphContractError):validate_graph(x)
    def test_jev_cannot_claim_learning(self):
        x=fresh();next(n for n in x['nodes'] if n['id']=='JEV')['status']='SCOPED_TEST'
        with self.assertRaises(GraphContractError):validate_graph(x)
    def test_own_weight_cannot_claim_language_parity(self):
        x=fresh();next(n for n in x['nodes'] if n['id']=='DNB-OWN-WEIGHTS')['status']='SCOPED_TEST'
        with self.assertRaises(GraphContractError):validate_graph(x)
    def test_blinfinity_c_is_not_compiled_runtime(self):
        x=fresh();next(n for n in x['nodes'] if n['id']=='BLINF-C')['status']='SCOPED_TEST'
        with self.assertRaises(GraphContractError):validate_graph(x)
    def test_edges_no_execution_authority(self):
        x=fresh();x['edges'][0]['runtime_callable']=True
        with self.assertRaises(GraphContractError):validate_graph(x)
    def test_unknown_edge_type_denied(self):
        x=fresh();x['edges'][0]['kind']='ACTIVATE_ALL'
        with self.assertRaises(GraphContractError):validate_graph(x)
    def test_unknown_endpoint_denied(self):
        x=fresh();x['edges'][0]['to']='UNDECLARED'
        with self.assertRaises(GraphContractError):validate_graph(x)
    def test_duplicate_edge_denied(self):
        x=fresh();x['edges'].append(copy.deepcopy(x['edges'][0]));x['edge_count']+=1
        with self.assertRaises(GraphContractError):validate_graph(x)
    def test_cycle_denied(self):
        x=fresh();x['edges'].append({'from':'WEBSITE-R32','to':'BL-ROOT','kind':'LINEAGE','runtime_callable':False});x['edge_count']+=1
        with self.assertRaises(GraphContractError):validate_graph(x)
    def test_bad_parent_denied(self):
        x=fresh();x['continuity']['parent']='JOB-OTHER'
        with self.assertRaises(GraphContractError):validate_graph(x)
    def test_no_scientific_hidden_claim(self):
        x=fresh();x['constraints']['arc3_official_hidden_score']='VERIFIED_100'
        with self.assertRaises(GraphContractError):validate_graph(x)
    def test_unknown_fields_denied(self):
        x=fresh();x['nodes'][0]['secret_token']='should-never-be-here'
        with self.assertRaises(GraphContractError):validate_graph(x)
    def test_report_cannot_claim_runtime(self):
        out=report_summary(fresh());self.assertFalse(out['runtime_promoted']);self.assertFalse(out['target_ack']);self.assertFalse(out['new_trained_weight_checkpoint'])

if __name__=='__main__':unittest.main()
