import unittest,copy,json
from pathlib import Path
from deus_one.extension_r4 import validate_r4,R4Rejected,scoped_report
from deus_one.pipeline_r4 import demo_r4
ROOT=Path(__file__).resolve().parents[1]
def inputs():return [json.loads((ROOT/k).read_text()) for k in ('CAPABILITY_GRAPH_R1.json','CAPABILITY_EXTENSION_R2.json','CAPABILITY_EXTENSION_R3.json','CAPABILITY_EXTENSION_R4.json')]
class R4GraphTests(unittest.TestCase):
    def setUp(self):self.a=inputs()
    def test_valid(self):
        x=validate_r4(*self.a);self.assertTrue(x['source_candidate_only']);self.assertGreaterEqual(len(x['nodes']),20)
    def test_previous_checksum(self):
        a=copy.deepcopy(self.a);a[3]['r3_source_sha256']='0'*64
        with self.assertRaises(R4Rejected):validate_r4(*a)
    def test_safety_limits(self):
        a=copy.deepcopy(self.a);a[3]['limits']['whole_corpus_completeness']='VERIFIED'
        with self.assertRaises(R4Rejected):validate_r4(*a)
    def test_fake_runtime_ack(self):
        a=copy.deepcopy(self.a);a[3]['runtime_target_ack']=True
        with self.assertRaises(R4Rejected):validate_r4(*a)
    def test_fake_private(self):
        a=copy.deepcopy(self.a);a[3]['nodes'][0]['private_bytes_included']=True
        with self.assertRaises(R4Rejected):validate_r4(*a)
    def test_fake_physical(self):
        a=copy.deepcopy(self.a);a[3]['actual_multidimensional_compute_gain']=True
        with self.assertRaises(R4Rejected):validate_r4(*a)
    def test_whole_corpus(self):
        a=copy.deepcopy(self.a);a[3]['whole_corpus_exhausted']=True
        with self.assertRaises(R4Rejected):validate_r4(*a)
    def test_duplicate_alias(self):
        a=copy.deepcopy(self.a);a[3]['nodes'][1]['id']=a[3]['nodes'][0]['id']
        with self.assertRaises(R4Rejected):validate_r4(*a)
    def test_cycle(self):
        a=copy.deepcopy(self.a);a[3]['edges'].append({'from':'DEUS-ONE-API','to':'HYPERGRAPH-SYNERGY','kind':'RESEARCH_LINK','runtime_callable':False});a[3]['edge_count']+=1
        with self.assertRaises(R4Rejected):validate_r4(*a)
    def test_runtime_edge(self):
        a=copy.deepcopy(self.a);a[3]['edges'][0]['runtime_callable']=True
        with self.assertRaises(R4Rejected):validate_r4(*a)
    def test_bad_source(self):
        a=copy.deepcopy(self.a);a[3]['nodes'][0]['source_ref']='privatekey://foo'
        with self.assertRaises(R4Rejected):validate_r4(*a)
    def test_wrong_job(self):
        a=copy.deepcopy(self.a);a[3]['continuity']['child']='new-task'
        with self.assertRaises(R4Rejected):validate_r4(*a)
    def test_no_old_tree_rewrite(self):
        x=scoped_report(*self.a)
        self.assertGreater(x['descriptive_nodes'],96);self.assertFalse(x['native_ack'])
    def test_pipeline(self):
        x=demo_r4(*self.a)
        self.assertFalse(x['native_multi_node_ack']);self.assertFalse(x['august_to_now_full_corpus_audited'])
        self.assertGreaterEqual(x['descriptive_nodes'],120)
    def test_pending_real_search(self):
        x=demo_r4(*self.a);self.assertFalse(x['native_deus_xsearch_used'])
    def test_no_scope_elevation(self):
        x=validate_r4(*self.a);self.assertEqual('9_PRESERVE_ISOLATION',x['limits']['out_of_domain_20261008'])
