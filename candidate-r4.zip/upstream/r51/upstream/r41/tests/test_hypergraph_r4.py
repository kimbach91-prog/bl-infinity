import unittest
from dataclasses import replace
from deus_one.hypergraph_r4 import HyperCell,HyperRelation,AXES,compose_public,HypergraphError
F=tuple((a,'same') for a in AXES)
def cells():return tuple(HyperCell(x,F) for x in ('a','b','c','d'))
def edge(i,*ms):return HyperRelation(i,ms,(('DOMAIN','same'),))
class HypergraphTests(unittest.TestCase):
    def test_connected_multiary(self):
        r=compose_public(cells(),(edge('h1','a','b','c'),edge('h2','c','d')),('a','d'))
        self.assertEqual('PUBLIC_HYPERRELATION_REFERENCE_ONLY',r['state'])
        self.assertEqual(2,len(r['witness']))
        self.assertFalse(r['native_dispatch'])
        self.assertEqual(0,r['physical_capacity_gain'])
    def test_repeat_stable(self):
        args=(cells(),(edge('h1','a','b','c'),edge('h2','c','d')),('a','d'))
        self.assertEqual(compose_public(*args)['witness_sha256'],compose_public(*args)['witness_sha256'])
    def test_disconnected_hold(self):
        v=compose_public(cells(),(edge('x','a','b'),edge('y','c','d')),('a','d'))
        self.assertTrue(v['state'].startswith('HOLD'))
    def test_unconstrained_edge_refused(self):
        with self.assertRaises(HypergraphError):compose_public(cells(),(HyperRelation('x',('a','b'),()),),('a','b'))
    def test_missing_facet_holds(self):
        r=compose_public(cells(),(HyperRelation('x',('a','b'),(('TIME','changed'),)),),('a','b'))
        self.assertTrue(r['state'].startswith('HOLD'))
    def test_bad_six_axes(self):
        with self.assertRaises(HypergraphError):compose_public((HyperCell('a',F[:-1]),),(),('a',))
    def test_duplicate_cell(self):
        with self.assertRaises(HypergraphError):compose_public((cells()[0],cells()[0]),(),('a',))
    def test_duplicate_edge(self):
        with self.assertRaises(HypergraphError):compose_public(cells(),(edge('x','a','b'),edge('x','b','c')),('a','b'))
    def test_unauthorized(self):
        with self.assertRaises(HypergraphError):compose_public(cells(),(replace(edge('x','a','b'),inferred_authority=True),),('a','b'))
    def test_private(self):
        with self.assertRaises(HypergraphError):compose_public((replace(cells()[0],data_class='OWNER_PRIVATE'),),(),('a',))
    def test_forged_real_cell(self):
        with self.assertRaises(HypergraphError):compose_public((replace(cells()[0],simulated=False),),(),('a',))
    def test_no_unknown_participant(self):
        with self.assertRaises(HypergraphError):compose_public(cells(),(edge('x','a','ghost'),),('a','b'))
    def test_no_globally_optimal_claim(self):
        r=compose_public(cells(),(edge('x','a','b'),),('a','b'))
        self.assertFalse(r['proves_global_optimum'])
    def test_no_axis_elevation(self):
        with self.assertRaises(HypergraphError):compose_public(cells(),(HyperRelation('x',('a','b'),(('AUTHORITY','admin'),)),),('a','b'))
    def test_bounded_edges(self):
        with self.assertRaises(HypergraphError):compose_public(cells(),tuple(edge('x'+str(i),'a','b') for i in range(49)),('a','b'))
