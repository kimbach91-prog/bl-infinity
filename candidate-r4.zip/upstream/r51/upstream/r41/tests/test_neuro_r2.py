"""Actual bounded synthetic simulation, no assertion of biology or owner runtime."""
import unittest
from dataclasses import replace
from deus_one.neuro import NeuroRejected,NeuroScenario,Synapse,simulate_neuro,verify_toy_trace

def baseline():
    return NeuroScenario(nodes=3,synapses=(Synapse(0,1,2),Synapse(1,2,1)),
       stimuli=tuple((4,0,0) if i%2==0 else (0,0,0) for i in range(10)))
class NeuroTests(unittest.TestCase):
    def test_deterministic_trace(self):
        s=baseline();a=simulate_neuro(s);b=simulate_neuro(s)
        self.assertEqual(a,b);self.assertEqual(len(a['frames']),10)
        self.assertEqual(a['state'],'SYNTHETIC_DISCRETE_NETWORK_ONLY')
        self.assertFalse(a['neuroscience_fidelity'])
        self.assertFalse(a['deus_neuro_daemon_executed'])
        self.assertFalse(a['runtime_ack'])
    def test_input_latency_is_one_step(self):
        a=simulate_neuro(NeuroScenario(nodes=2,synapses=(Synapse(0,1,2),),
                              stimuli=((4,0),(0,2),(0,1),(0,1))))
        self.assertEqual(a['frames'][0]['spikes'],[1,0])
        self.assertEqual(a['frames'][1]['spikes'][1],1)
    def test_inhibition_changes_target_activity(self):
        stim=((4,0,4),(0,2,0)) * 5
        no=simulate_neuro(NeuroScenario(nodes=3,synapses=(Synapse(0,1,2),),stimuli=stim))
        yes=simulate_neuro(NeuroScenario(nodes=3,synapses=(Synapse(0,1,2),Synapse(2,1,-2)),stimuli=stim))
        cnt=lambda o: sum(f['spikes'][1] for f in o['frames'])
        self.assertLessEqual(cnt(yes),cnt(no))
    def test_energy_bounds(self):
        a=simulate_neuro(baseline())
        self.assertTrue(a['energy_bounds_verified'])
        self.assertTrue(all(0<=v<=5 for f in a['frames'] for v in f['energy']))
    def test_replay_check(self):
        s=baseline();t=simulate_neuro(s)
        self.assertTrue(verify_toy_trace(s,t))
        t['frames'][0]['spikes'][0]=0
        self.assertFalse(verify_toy_trace(s,t))
    def test_owner_private_denied(self):
        with self.assertRaises(NeuroRejected):simulate_neuro(replace(baseline(),data_class='OWNER_PRIVATE'))
    def test_large_network_denied(self):
        with self.assertRaises(NeuroRejected):simulate_neuro(NeuroScenario(17,(),((0,)*17,)))
    def test_many_steps_denied(self):
        with self.assertRaises(NeuroRejected):simulate_neuro(replace(baseline(),stimuli=((0,0,0),)*97))
    def test_invalid_voltage_denied(self):
        with self.assertRaises(NeuroRejected):simulate_neuro(replace(baseline(),stimuli=((999,0,0),)))
    def test_nan_denied(self):
        with self.assertRaises(NeuroRejected):simulate_neuro(replace(baseline(),stimuli=((float('nan'),0,0),)))
    def test_bool_is_not_neuron_index(self):
        s=replace(baseline(),synapses=(Synapse(True,1,2),))
        with self.assertRaises(NeuroRejected):simulate_neuro(s)
    def test_self_connection_denied(self):
        s=replace(baseline(),synapses=(Synapse(1,1,1),))
        with self.assertRaises(NeuroRejected):simulate_neuro(s)
    def test_duplicate_synapse_denied(self):
        s=replace(baseline(),synapses=(Synapse(0,1,1),Synapse(0,1,2)))
        with self.assertRaises(NeuroRejected):simulate_neuro(s)
    def test_unbounded_strength_denied(self):
        s=replace(baseline(),synapses=(Synapse(0,1,5),))
        with self.assertRaises(NeuroRejected):simulate_neuro(s)
    def test_broken_initial_budget(self):
        with self.assertRaises(NeuroRejected):simulate_neuro(replace(baseline(),initial_energy=0))
    def test_private_signal_not_relabelable(self):
        with self.assertRaises(NeuroRejected):simulate_neuro(replace(baseline(),data_class='PRIVATE_PUBLIC'))
    def test_no_real_actuation(self):
        self.assertFalse(simulate_neuro(baseline())['real_world_actuation'])

if __name__=='__main__':unittest.main()
