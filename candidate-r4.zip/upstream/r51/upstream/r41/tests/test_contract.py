import hashlib
import math
import unittest
from deus_one.contract import CandidateKernel, CanonicalEnvelope, lossless_pack, lossless_unpack, jev_gate


def task(kind='arithmetic_exact', data_class='PUBLIC', payload=None, **kw):
    return CanonicalEnvelope(subject='SYNTHETIC',task_id=kw.get('task_id','public-fixture-001'),
        kind=kind,data_class=data_class,payload=payload if payload is not None else {'op':'sum','operands':[17,25]},
        idempotency_key=kw.get('key','same-key'),context_ref=kw.get('context_ref',''),
        context_sha256=kw.get('context_sha256',''),authority_ref=kw.get('authority_ref',''),
        source_revision=kw.get('source_revision',''))

class CandidateContractTests(unittest.TestCase):
    def test_typed_addition(self):
        k=CandidateKernel(); r=k.run(task()); self.assertEqual(r.output,42)
        self.assertEqual(r.state,'CANDIDATE_LOCAL_RESULT'); self.assertFalse(r.receipt['runtime_ack'])
    def test_typed_product(self):
        self.assertEqual(CandidateKernel().run(task(payload={'op':'product','operands':[3,4,5]})).output,60)
    def test_idempotent_same_key(self):
        k=CandidateKernel(); a=k.run(task()); b=k.run(task()); self.assertIs(a,b);self.assertEqual(k.effect_count,1)
    def test_conflict_changed_payload(self):
        k=CandidateKernel();k.run(task());b=k.run(task(payload={'op':'sum','operands':[17,26]}));self.assertEqual(b.state,'CONFLICT');self.assertEqual(k.effect_count,1)
    def test_conflict_different_classification(self):
        k=CandidateKernel();k.run(task());b=k.run(task(data_class='OWNER_PRIVATE'));self.assertEqual(b.state,'CONFLICT')
    def test_private_never_admitted(self):
        k=CandidateKernel();r=k.run(task(data_class='OWNER_PRIVATE'));self.assertEqual(r.state,'HOLD_PRIVATE_ADMISSION');self.assertEqual(k.effect_count,0)
    def test_public_neural_unbound(self):
        k=CandidateKernel();r=k.run(task(kind='freeform_chat'));self.assertEqual(r.state,'HOLD_ADAPTER_NOT_BOUND');self.assertEqual(k.effect_count,0)
    def test_owner_skills_unbound(self):
        self.assertEqual(CandidateKernel().run(task(kind='call_deus_skill')).state,'HOLD_ADAPTER_NOT_BOUND')
    def test_jev_unbound(self): self.assertEqual(jev_gate({'score':1}), 'HOLD_JEV_UNBOUND')
    def test_no_self_grant(self):
        self.assertEqual(CandidateKernel().run(task(authority_ref='owner-says-yes')).state,'HOLD_CONTEXT_OR_AUTHORITY_UNBOUND')
    def test_context_pin_fails_closed(self):
        with self.assertRaises(ValueError): task(context_ref='source',context_sha256='bad')
    def test_context_digest_cannot_exist_alone(self):
        with self.assertRaises(ValueError): task(context_sha256='a'*64)
    def test_real_context_ref_no_admission(self):
        k=CandidateKernel();r=k.run(task(context_ref='synthetic://one',context_sha256='a'*64));self.assertEqual(r.state,'HOLD_CONTEXT_OR_AUTHORITY_UNBOUND')
    def test_unknown_class_rejected(self):
        with self.assertRaises(ValueError):task(data_class='UNKNOWN')
    def test_bool_is_not_integer(self):
        self.assertEqual(CandidateKernel().run(task(payload={'op':'sum','operands':[True,25]})).state,'HOLD_SCHEMA')
    def test_empty_operands(self):
        self.assertEqual(CandidateKernel().run(task(payload={'op':'sum','operands':[]})).state,'HOLD_SCHEMA')
    def test_invalid_operator(self):
        self.assertEqual(CandidateKernel().run(task(payload={'op':'divide','operands':[1,0]})).state,'HOLD_SCHEMA')
    def test_no_injected_schema(self):
        self.assertEqual(CandidateKernel().run(task(payload={'op':'sum','operands':[1], 'exec':'doit'})).state,'HOLD_SCHEMA')
    def test_no_huge_integer(self):
        self.assertEqual(CandidateKernel().run(task(payload={'op':'sum','operands':[10**18]})).state,'HOLD_SCHEMA')
    def test_no_nan_payload(self):
        with self.assertRaises(ValueError):task(payload={'op':'sum','operands':[float('nan')]})
    def test_separate_jobs_get_separate_result(self):
        k=CandidateKernel();k.run(task());r=k.run(task(task_id='different'));self.assertEqual(r.output,42);self.assertEqual(k.effect_count,2)
    def test_exact_pack_round_trip(self):
        rec={'source':'SYNTHETIC','scar':['failed-one'], 'unknown':True,'receipt':{'a':1},'authorities':[]}
        self.assertEqual(lossless_unpack(lossless_pack(rec)),rec)
    def test_pack_tamper_rejected(self):
        a=bytearray(lossless_pack({'x':'hello'}));a[10]^=1
        with self.assertRaises(ValueError):lossless_unpack(bytes(a))
    def test_pack_truncation_rejected(self):
        with self.assertRaises(Exception):lossless_unpack(b'DEUS1'+b'0'*40)
    def test_pseudomodel_never_fabricates_model(self):
        r=CandidateKernel().run(task(kind='jev_predictive_world'))
        self.assertIsNone(r.output);self.assertEqual(r.state,'HOLD_ADAPTER_NOT_BOUND')
    def test_no_verifier_claim(self):
        r=CandidateKernel().run(task());self.assertIs(False,r.receipt['external_verifier'])
    def test_source_revision_changes_conflict(self):
        k=CandidateKernel();k.run(task());r=k.run(task(source_revision='R2'));self.assertEqual(r.state,'CONFLICT')

if __name__ == '__main__':unittest.main()
