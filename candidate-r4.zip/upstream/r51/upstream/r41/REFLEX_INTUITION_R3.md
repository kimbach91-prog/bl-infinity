# Reflex and "superintuition" as an experimental attention subsystem

`143_V7_OMNICORE_BINDINGS!A210:H211`: Bio-Reflex is a scoped sparse event attention/advisory pre-router and Neuro-Organism is a CNS/body coordinator. Historical provider source/build evidence exists, while exact authenticated owner canary/host reception, runtime usefulness and biophysical brain fidelity are still not established for the integrated DEUS-ONE system.

`64_COGNITIVE_SYNERGY_FABRIC` distinguishes V1 semantic exploratory hypotheses and V2 typed compiler/verifier. `178_V8_BL_HISTORY_DEEP_REDISCOVERY` EYE/EYE2 adds weak-signal/nuisance filtering and semantic falsifiers. `204_V8_AUTONOMOUS_EVOLUTION_KERNEL` explicitly notes that REFLEX1 state reconciliation is **not** a trained predictive world model.

Safe candidate composition: an admitted observation → signal extraction with timestamps and independent source IDs → reflex salience proposal → hypothesis/uncertainty packet → typed HHIR planner → authority gate → independent verification → memory/scar. It is forbidden for reflex to perform tasks, grant access, classify private data as public, or promote its own hypothesis.

`reflex_r3.py` and `intuition_r3.py` are PUBLIC bounded surrogates with explicit inhibition, refractory, source independence, lookahead protection and all-live-output booleans false. The synthetic trace must not be presented as neuronal, synaptic, connectomic or organism biophysics.
