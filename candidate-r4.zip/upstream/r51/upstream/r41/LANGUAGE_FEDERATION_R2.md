# DEUS-ONE R2 — BL∞ language federation and typed semantics

Source: `LiveBus:62_BL_INFINITY_LANGUAGE_FEDERATION!A1:H14`, `LiveBus:101_DEUS_NATIVE_BRAIN_V0!A6:G14`, `LiveBus:153_V8_CORE_MAP!A2:H10`.

**Do not equate distinct languages, IRs and runtimes.** The purpose is interoperability with typed effects, information conservation and measured workload fit, not an all-encompassing new syntax invented by this package.

| Family | Semantic function | Current evidence boundary | Allowed R2 behavior |
| --- | --- | --- | --- |
| `DIC/1` | Natural intent to typed TaskContract | Adjacent bounded natural-command tests, not a universal native parser | Source reference only |
| `BLμ` | Scalar/numeric parser–optimizer–bytecode, VM/Wasm | Historical 41/41 restore, 30 tests, generated and edge fixtures; workload-specific speedups vs VM | DO NOT claim R2 has a BLμ compiler |
| `BLΣ` | Exact representation/codec | Scoped source/tests, broader cognition A/B open | Data provenance role only |
| `BLμ/OS` | Capability/effect boundary | Concept implemented in own scope | No new permission from syntax |
| `BL-Fabric` | Dataflow/graph orchestration | Synthetic graph evidence | Not a machine resource |
| `ATOM–DEFECT L20` | Multi-semantic workload selector | Synthetic Boolean/analog/time tests; semantic workload fit | Advisory/source bounded |
| `BL Semantic IR` | SSA/dataflow + effects/resources/provenance | Candidate compiler stack | Not executable native backend in R2 |
| `HHIR` | Typed heterogeneous graph and conversion edges | Scoped canonical/runtime predecessors | Pin current successor before admission |
| `BLX` | Higher-lineage language | Direct semantics gap in canon | **HOLD** until sourced |
| Backend federation | MLIR/LLVM/Wasm/StableHLO/GPU target codecs | Only specific BLμ/Wasm and other scoped targets evidenced | No arbitrary code execution |
| Bounded self-reprogramming | Task-local strategy/compiler-pass repair | 100-task matched proof pending | Never mutate root/authority/weights |
| `BL-DATA-IR/1` | Typed exact JSON/MAP1/Python/JS/SQL/HTML/SExpr carriers | Scoped 654 cases/7 adapters and 4578 roundtrips as canon describes | R2 PUBLIC synthetic codec is NOT BL-DATA-IR implementation |
| `BL∞-C` | Declarative cognitive program (TASK/INVARIANT/SKILL/VERIFY) | **PROPOSED** in `101_DEUS_NATIVE_BRAIN_V0` | HOLD — no registered compiler |

## Explicit conversion contract

Any future lowering has to include source hash, source/target semantics, declared type, role (`system`, `user`, `assistant`, `tool`), data class, effect class, precondition, postcondition, verifier, inverse/sidecar where needed, and semantic-loss measurements. Never drop `OWNER_PRIVATE` class, role distinctions, UNKNOWN, or provenance because a format looks smaller.

## R2 code implemented

`deus_one/languages.py`: a narrow PUBLIC-only toy typed packet carrier with canonical JSON + sorted tagged-field envelope and SHA-256 integrity. Decode verifies identical semantics, role, data-class, source identity and exact fields. `descriptive_language_route()` always returns HOLD for actual DEUS language programs until real native compiler admission. No BL language source is copied; no model inference or tool execution.

`deus_one/pipeline_r2.py`: one finite synthetic mapping + network + typed-packet composition under the unchanged R1 candidate graph. It returns `PUBLIC_SYNTHETIC_COMPOSITION_ONLY`; never produces a native ACK.

## Promotion gate

For each language separately: exact authoritative source/version → source-to-IR lowering on real input → dual implementation or independent oracle → commutation/effects/privacy negative controls → measured cost/benefit → native adapter ack → rollback/readback. The presence of BLμ success is not evidence that BLX/BL∞-C/backends run.
