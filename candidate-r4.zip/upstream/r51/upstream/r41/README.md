# DEUS-ONE · PUBLIC CONFORMANCE SCAFFOLD · R0

**This is not the DEUS owner-private core, a trained language model, or production release.**

Purpose: a minimal standalone public reference validating an integration ABI: typed intent, exact source/context lineage, classify-before-route, fail-closed unknown adapters, no self-minted grants, fixed-result idempotency, immutable output hash, exact-byte compression, and no fraudulent target ACK. It never downloads private artifacts, calls models, creates remote jobs, trains weights, or reads secrets.

`python -m unittest discover -s tests -v`

`deus_one.contract.CandidateKernel` deliberately supports only local PUBLIC typed arithmetic as a conformance test. All owner-private, open-ended neural/JEPA/JEV, Skill/Matrix/Brain execution stays HOLD until an existing admitted controller supplies appropriate task-specific authority, versioned checkpoint/adapter, lease and independent verifier. No generated grant or authoritative claim is possible from the user's message or this example.

**Canonical source:** DEUS owner Google Drive, not this generated demo. Status is SOURCE_CANDIDATE_WITH_LOCAL_TESTS, NOT VERIFIED_DONE. Deploy/coding under the canonical DEUS gate only.

See `UNIFICATION_CONTRACT.json` for statuses, placeholders and the proposed architecture. Original August/September/October scars and rollback remain on Drive; this package does not overwrite them.


## R1 expansion (16 October 2026) — metadata only

R1 **extends** R0 and preserves its fail-closed conformance kernel. It does NOT
replace the owner-private DEUS kernel, perform training, or deploy a website.
`CAPABILITY_GRAPH_R1.json` connects **36 scoped architectural anchors** with
**41 declarative source/provenance/design edges**. These are NOT capability
counts and the graph is explicitly NOT an executable control plane.

Added anchored source families: stable/candidate constitutions, task-fit
authority, BL philosophical and Millennium-7 operators, BLµ versus proposed
BL∞-C, biomimetic Bio-Cloud/Organism OS, connectomics-inspired reflex and
neuro-organism controller, distinct NOT-PROVEN scientific cell/brain simulation,
DNB own-weight pilot, skill/governance, compression, CAS and evolution.

`deus_one.architecture` rejects forged admissions, unsupported biological
claims, model/promoted language claims, unknown capabilities, cyclic references,
privacy downgrade and fake target ACK. It DOES NOT execute any DAG node.

From a fresh extraction directory:

    python -m unittest discover -s tests -v

**53 local synthetic/scoped contract tests** pass (R0 27 + R1 26). There are
zero new native jobs, new model calls, owner-private accesses or release actions.
The meta-registry is deliberately incomplete pending an admitted private
source/capability census. Read SOURCE_PINS_R1.md and SOURCE_BOUNDARIES_R1.md.

## R2 ADDENDUM — Mapping / Language Federation / neuro public source package

R2 **extends** the immutable R1 graph by a source-bound new graph, not by mutating R1 canonical status. New modules: `deus_one.mapping`, `deus_one.languages`, `deus_one.neuro`, `deus_one.extension`, `deus_one.pipeline_r2`. New evidence: `CAPABILITY_EXTENSION_R2.json` and three detailed research/gate documents. `create_extension.py` deterministically regenerates the addon metadata; it cannot query Drive/Brain3 or read secrets.

Run `python -W error -m unittest discover -s tests -v` from the ZIP extracted root, and `python verify_artifact.py` for local SHA integrity. Original R1 tests must still pass. Synthetic tests cannot claim official DEUS native runtime/brain science or general-language model capability. Check `DELTA_R1_TO_R2.md` for the preserved test scar and version boundaries.

## R3 additive source-bound extension (2026-10-16)

See `DELTA_R2_TO_R3.md` and the four focused R3 notes. `CAPABILITY_EXTENSION_R3.json` pins **both** predecessor digests and adds 31 metadata-only components and 51 typed relations. Tests cover bounded public network routing, time-fenced future scenario and inverse goal backchain, source-separated intuition, no-effect reflex attention, and exact evidence reuse with FAIL/UNKNOWN retention. R3 preserves all R2 files and has **zero** native/model/owner-private calls or target ACK. A toy forecast ≠ BL-SFRET native or a calibrated world model.

The inherited `FILE_SHA256_R2.json` is historical to the **original R2 ZIP**, not a claim that the append-only README/MODEL_CARD are still R2-identical. Use `FILE_SHA256_R3.json` and `verify_r3.py` for this R3 archive; prior R1/R2 *source and test files* remain unchanged.
