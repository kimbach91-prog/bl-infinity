# DEUS-ONE R1 → R2 preservation ledger

- Parent job retained: `JOB-DEUS-WORKSPACE-NATIVE-ACCEPTANCE-20261003-001`; child `DEUS-WORKSPACE-OSS-CODEX-20261012-001`.
- R1 archive source SHA-256: `1ef3df4095293f86508bee99f746e9565885801b0b119af99889d358bcc82bf2`. Do not mutate or delete the owner Drive R1 ZIP. R2 republishes R1 files as baseline, preserving R1 manifest.
- **R1 graph stays 36 nodes / 41 edges**, unchanged. A separate R2 extension adds **29 nodes / 42 source-bound relationships** to avoid self-promoting R1 state. Total descriptive graph: **65 nodes / 83 edges**. This does NOT represent fully connected adapters.
- R2 adds local reference-only finite mapping witness, role-preserving packet codec, bounded synthetic neuro network and one inert composition layer.
- R2 runs the original 53 R1 tests plus new negative/control suites. First R2 test run **FAILED 1/127** because a one-step spiking fixture expected threshold firing with too little input; the fixture was corrected to match the declared leak/threshold equation and full suite rerun, then integration tests added. Preserve initial failure as a fixture scar, not a production bug.
- No private code, model weights, tokens, unauthorized endpoint/adapter or network calls included; no R32 website deploy, model training, GPU allocation or billing.
- This source candidate is a contract for existing admitted native adapters, not a successor to `CURRENT` / verifier receipts until independently accepted. No automatic merge into R32 app or AI model registry.
