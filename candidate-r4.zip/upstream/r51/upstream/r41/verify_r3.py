"""Validate an already-unpacked R3 candidate; no network or protected effects."""
from pathlib import Path
from hashlib import sha256
import json
import sys
from deus_one.extension_r3 import validate_r3, source_report
from deus_one.pipeline_r3 import run_public_synthetic_r3

P=Path(__file__).resolve().parent
r1=json.loads((P/'CAPABILITY_GRAPH_R1.json').read_text(encoding='utf-8'))
r2=json.loads((P/'CAPABILITY_EXTENSION_R2.json').read_text(encoding='utf-8'))
r3=json.loads((P/'CAPABILITY_EXTENSION_R3.json').read_text(encoding='utf-8'))
validate_r3(r1,r2,r3)
report=source_report(r1,r2,r3)
flow=run_public_synthetic_r3(r1,r2,r3)
manifest=json.loads((P/'FILE_SHA256_R3.json').read_text(encoding='utf-8'))
for name,digest in manifest['files'].items():
    actual=sha256((P/name).read_bytes()).hexdigest()
    if actual!=digest:raise SystemExit('Fail-closed: corrupted source file '+name)
if report['total_descriptive_nodes']!=96 or report['total_descriptive_edges']!=134:
    raise SystemExit('Cardinality drift')
if flow['runtime_target_ack'] is not False or flow['owner_private_egress'] is not False:
    raise SystemExit('Unverified runtime status forged')
print('R3 SOURCE-CANDIDATE: graph pinned PASS, files exact PASS, synthetic composition PASS; no native ACK')
