"""Deterministic offline source-package verification, NOT runtime admission."""
from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
from deus_one.extension_r4 import validate_r4,sha
from deus_one.pipeline_r4 import demo_r4
ROOT=Path(__file__).resolve().parent

def sha256(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def run():
    baseline=json.loads((ROOT/'R3_INHERITANCE_R4.json').read_text())
    assert baseline['source_package_sha256']=='799d822e5cda96256127cc84da09939c19c1dbe674b1c5bdf487b44b92e7a279'
    assert len(baseline['files'])==57
    for file,digest in baseline['files'].items():
        p=ROOT/file
        assert p.is_file() and sha256(p)==digest, 'Inherited R3 damaged: '+file
    man=json.loads((ROOT/'FILE_SHA256_R4.json').read_text())
    for file,digest in man['files'].items():
        assert (ROOT/file).is_file() and sha256(ROOT/file)==digest, 'R4 file tamper: '+file
    names=('CAPABILITY_GRAPH_R1.json','CAPABILITY_EXTENSION_R2.json',
           'CAPABILITY_EXTENSION_R3.json','CAPABILITY_EXTENSION_R4.json')
    a=[json.loads((ROOT/n).read_text()) for n in names]
    v=validate_r4(*a);result=demo_r4(*a)
    assert sha(v)==result['r4_sha256']
    assert not any((result['target_ack'],result['native_multi_node_ack'],
                    result['august_to_now_full_corpus_audited'],result['trained_weights']))
    print(json.dumps({'state':'R4_LOCAL_SOURCE_CANDIDATE_VERIFIED',
       'inherited_r3_files_exact':57,'r4_manifest_files_verified':len(man['files']),
       'nodes':result['descriptive_nodes'],'edges':result['descriptive_edges'],
       'native_ack':False,'full_census':False,'digest':result['r4_sha256']},
       ensure_ascii=False,sort_keys=True))

if __name__=='__main__':run()
