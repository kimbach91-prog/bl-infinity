"""R1-R4 single PUBLIC synthetic demonstration; no real DEUS capability activation."""
from pathlib import Path
import json
from collections.abc import Mapping
from .extension_r4 import scoped_report
from .pipeline_r3 import run_public_synthetic_r3
from .hypergraph_r4 import AXES,HyperCell,HyperRelation,compose_public
from .resources_r4 import Vector,Node,Demand,place_public
from .supersearch_r4 import SourceCard,search_metadata,triangulate,coverage

def demo_r4(r1:Mapping,r2:Mapping,r3:Mapping,r4:Mapping)->dict:
    base=run_public_synthetic_r3(r1,r2,r3)
    report=scoped_report(r1,r2,r3,r4)
    facets=tuple((a,'p0') for a in AXES)
    g=compose_public(tuple(HyperCell(x,facets) for x in ('core','world','verifier')),
          (HyperRelation('edge-a',('core','world'),(('DOMAIN','p0'),)),
           HyperRelation('edge-b',('world','verifier'),(('PROVENANCE','p0'),))),
          ('core','world','verifier'))
    fit=place_public((Node('node_a',Vector((8,8192,0,4096,100,100)),10,5),
                       Node('node_b',Vector((2,1024,0,4096,100,50)),8,1)),
                     Demand(Vector((4,2048,0,0,10,10)),15,10))
    c=(SourceCard('src10001','HyperWeave six dimensional', 'F14','ownerA',aliases=('HyperWeave',)),
       SourceCard('src10002','HyperWeave mirror', 'F14','ownerA',source_kind='LIVEBUS_TAB'),
       SourceCard('src10003','Memory Search','F04','ownerB'))
    search=search_metadata(c,'HyperWeave')
    lineage=triangulate(c,('src10001','src10002'))
    cov=coverage(c,('F04','F14','F25'))
    if not (g['state']=='PUBLIC_HYPERRELATION_REFERENCE_ONLY'
            and len(g['witness'])==2 and fit['suggestion']['node']=='node_a'
            and lineage['independent_lineages_claimable']==1
            and cov['missing_families']==['F25'] and base['runtime_target_ack'] is False):
        raise ValueError('Synthetic multi-domain fixture not valid')
    return {'state':'R4_PUBLIC_SOURCE_CANDIDATE_ONLY',
        'descriptive_nodes':report['descriptive_nodes'],
        'descriptive_edges':report['descriptive_edges'],
        'r4_sha256':report['r4_sha256'],
        'hypergraph_witness_sha256':g['witness_sha256'],
        'resource_single_node':fit['suggestion']['node'],
        'metadata_matches':search['matched'],
        'independent_lineage_roots':lineage['independent_lineages_claimable'],
        'uninspected_family':cov['missing_families'],
        'native_deus_xsearch_used':False,'native_multi_node_ack':False,
        'trained_weights':False,'target_ack':False,'real_lease':False,
        'owner_private_bytes_read':False,'new_credits_spent':False,
        'august_to_now_full_corpus_audited':False,
        'previous_r3_sha256':base['r3_graph_sha256']}

if __name__=='__main__':
    p=Path(__file__).resolve().parents[1]
    x=[json.loads((p/k).read_text()) for k in (
      'CAPABILITY_GRAPH_R1.json','CAPABILITY_EXTENSION_R2.json',
      'CAPABILITY_EXTENSION_R3.json','CAPABILITY_EXTENSION_R4.json')]
    print(json.dumps(demo_r4(*x),sort_keys=True,indent=2))
