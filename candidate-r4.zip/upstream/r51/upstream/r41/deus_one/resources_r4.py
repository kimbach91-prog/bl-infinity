"""Exact multidimensional capacity selector on PUBLIC synthetic fixtures.

Resource dimensions cannot be added across different hosts unless a separate
admitted sharding/transfer protocol proves semantics, lease and data movement.
"""
from dataclasses import dataclass
from hashlib import sha256
import json,re

METRICS=('CPU_SLOT','RAM_MIB','VRAM_MIB','DISK_MIB','NIC_MBPS','IO_MBPS')
class ResourceError(ValueError): pass
ID=re.compile(r'^[a-zA-Z][a-zA-Z0-9_-]{0,40}$')

@dataclass(frozen=True)
class Vector:
    units:tuple[int,int,int,int,int,int]

@dataclass(frozen=True)
class Node:
    name:str
    capacity:Vector
    latency_ms:int
    cost_microunits:int
    healthy:bool=True
    freshness:'str'='CURRENT_SYNTHETIC'
    data_class:str='PUBLIC'

@dataclass(frozen=True)
class Demand:
    required:Vector
    max_latency_ms:int
    max_cost_microunits:int
    data_class:str='PUBLIC'
    effect:str='PURE'


def _vec(v):
    return (isinstance(v,Vector) and type(v.units) is tuple and len(v.units)==len(METRICS)
            and all(type(x) is int and 0<=x<=10**7 for x in v.units))


def place_public(nodes:tuple[Node,...], demand:Demand)->dict:
    if (type(nodes) is not tuple or not 1<=len(nodes)<=32 or not isinstance(demand,Demand)
        or not _vec(demand.required) or demand.data_class!='PUBLIC' or demand.effect!='PURE'
        or type(demand.max_latency_ms) is not int or not 0<=demand.max_latency_ms<=10**7
        or type(demand.max_cost_microunits) is not int or not 0<=demand.max_cost_microunits<=10**9):
        raise ResourceError('Malformed or privileged demand')
    seen=set(); eligible=[]; rejected=[]
    for n in nodes:
        if (not isinstance(n,Node) or type(n.name) is not str or not ID.fullmatch(n.name)
            or n.name in seen or not _vec(n.capacity) or type(n.healthy) is not bool
            or type(n.latency_ms) is not int or not 0<=n.latency_ms<=10**7
            or type(n.cost_microunits) is not int or not 0<=n.cost_microunits<=10**9
            or n.data_class!='PUBLIC' or n.freshness!='CURRENT_SYNTHETIC'):
            raise ResourceError('Invalid, private or stale node capacity')
        seen.add(n.name)
        if not n.healthy or n.latency_ms>demand.max_latency_ms or n.cost_microunits>demand.max_cost_microunits:
            rejected.append((n.name,'HEALTH_OR_BUDGET'));continue
        if any(avail<need for avail,need in zip(n.capacity.units,demand.required.units)):
            rejected.append((n.name,'DIMENSION_CAPACITY'));continue
        eligible.append(n)
    if not eligible:
        return {'state':'HOLD_NO_SINGLE_NODE_CAPACITY','suggestion':None,
                'reason':'NO_UNJUSTIFIED_CROSS_NODE_RESOURCE_SUM',**_limits()}
    eligible.sort(key=lambda n:(n.cost_microunits,n.latency_ms,n.name))
    best=eligible[0]
    # Exact 6-axis witness; never claims a physical lease or signed telemetry.
    w={'node':best.name,'capacity':dict(zip(METRICS,best.capacity.units)),
       'required':dict(zip(METRICS,demand.required.units)),
       'latency_ms':best.latency_ms,'cost_microunits':best.cost_microunits}
    return {'state':'PUBLIC_RESOURCE_FIT_REFERENCE_ONLY','suggestion':w,
            'eligible_nodes':[x.name for x in eligible],
            'witness_sha256':sha256(json.dumps(w,sort_keys=True).encode()).hexdigest(),**_limits()}


def _limits():
    return {'measured_physical_capacity':False,'lease_obtained':False,
            'runtime_target_ack':False,'authority_granted':False,'cross_node_aggregation':False}
