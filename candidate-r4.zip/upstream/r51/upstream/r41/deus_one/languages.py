"""PUBLIC synthetic data/IR codec and descriptive BL language route ledger.

Not BLμ parser/compiler, HHIR full interpreter, BLΣ compressor or BL∞-C runtime.
It enforces distinctions those backends MUST preserve before integration.
"""
from __future__ import annotations
import json
from hashlib import sha256
import re
from collections.abc import Mapping

class LanguageRejected(ValueError):
    pass

HEX = re.compile(r'^[a-f0-9]{64}$')
_ALLOWED_ROLES = frozenset({'system', 'user', 'assistant', 'tool'})
_ALLOWED_TYPES = frozenset({'INT', 'BOOL', 'TEXT', 'INT_VEC'})
_REQUIRED = frozenset({'schema', 'task_id', 'role', 'data_class', 'effect',
                       'semantic_type', 'source_sha256', 'value'})

# Historical SOURCE evidence only, not a callable compiler registration.
LANGUAGE_STATES = {
    'DIC/1': 'SOURCE_SCOPED',
    'BLmu': 'HISTORICAL_SCOPED',
    'BL-SIGMA': 'HISTORICAL_SCOPED',
    'BLmu/OS': 'SOURCE_SCOPED',
    'BL-FABRIC': 'SOURCE_SCOPED',
    'ATOM-DEFECT-L20': 'HISTORICAL_SCOPED',
    'BL-SEMANTIC-IR': 'SPEC_CANDIDATE',
    'HHIR': 'SOURCE_SCOPED',
    'BL-DATA-IR/1': 'HISTORICAL_SCOPED',
    'BL-X': 'UNVERIFIED_SCOPE',
    'BL-INFINITY-C': 'SPEC_CANDIDATE',
}


def _norm_packet(packet: object) -> dict:
    if not isinstance(packet, Mapping) or set(packet) != _REQUIRED:
        raise LanguageRejected('Typed packet must declare all and only contract fields')
    p = dict(packet)
    if p['schema'] != 'deus-one-r2-synthetic-datacodec/1':
        raise LanguageRejected('Unknown schema')
    if p['data_class'] != 'PUBLIC' or p['effect'] != 'PURE':
        raise LanguageRejected('No private data or side effects through PUBLIC bridge')
    if (type(p['task_id']) is not str or not 1 <= len(p['task_id']) <= 128 or
            p['role'] not in _ALLOWED_ROLES or
            p['semantic_type'] not in _ALLOWED_TYPES or
            type(p['source_sha256']) is not str or
            not HEX.fullmatch(p['source_sha256'])):
        raise LanguageRejected('Invalid role/type/source identity')
    v = p['value']
    kind = p['semantic_type']
    if (kind == 'INT' and (type(v) is not int or abs(v) > 10**12)) or \
       (kind == 'BOOL' and type(v) is not bool) or \
       (kind == 'TEXT' and (type(v) is not str or len(v) > 2048)) or \
       (kind == 'INT_VEC' and (type(v) is not list or len(v) > 64 or
                              any(type(t) is not int or abs(t) > 10**12 for t in v))):
        raise LanguageRejected('Value violates declared semantics')
    return p


def _bytes(p: dict) -> bytes:
    return json.dumps(p, ensure_ascii=False, sort_keys=True, separators=(',', ':'),
                      allow_nan=False).encode('utf-8')


def encode_ir(packet: Mapping) -> dict:
    """Encode a narrow typed record in two independently reversible envelopes."""
    p = _norm_packet(packet)
    blob = _bytes(p)
    sha = sha256(blob).hexdigest()
    # Explicit tagged fields; unlike a flattened dialogue this keeps roles separate.
    fields = [[k, p[k]] for k in sorted(_REQUIRED)]
    return {'encoding': 'DEUS_ONE_R2_PUBLIC_REFERENCE', 'sha256': sha,
            'canonical_json': blob.decode('utf-8'), 'tagged_fields': fields,
            'runtime_ack': False}


def decode_ir(envelope: Mapping) -> dict:
    if not isinstance(envelope, Mapping) or set(envelope) != {
            'encoding','sha256','canonical_json','tagged_fields','runtime_ack'}:
        raise LanguageRejected('Unexpected envelope fields')
    if envelope['encoding'] != 'DEUS_ONE_R2_PUBLIC_REFERENCE' or envelope['runtime_ack'] is not False:
        raise LanguageRejected('Unadmitted or forged runtime boundary')
    blob = envelope['canonical_json']
    if type(blob) is not str or len(blob) > 6000 or type(envelope['sha256']) is not str:
        raise LanguageRejected('Malformed payload')
    p = _norm_packet(json.loads(blob))
    if blob != _bytes(p).decode('utf-8') or sha256(blob.encode()).hexdigest() != envelope['sha256']:
        raise LanguageRejected('Codec integrity/normal form mismatch')
    t = envelope['tagged_fields']
    if (type(t) is not list or len(t) != len(_REQUIRED) or
            any(type(z) is not list or len(z) != 2 or type(z[0]) is not str for z in t)
            or t != [[k, p[k]] for k in sorted(_REQUIRED)]):
        raise LanguageRejected('Tagged representation disagrees with canonical JSON')
    return p


def descriptive_language_route(language: str, data_class: str = 'PUBLIC') -> str:
    if data_class != 'PUBLIC':
        return 'HOLD_DATA_AUTHORITY'
    state = LANGUAGE_STATES.get(language)
    if state is None:
        return 'HOLD_UNKNOWN_LANGUAGE'
    if state == 'UNVERIFIED_SCOPE':
        return 'HOLD_LANGUAGE_SEMANTICS_UNKNOWN'
    if state == 'SPEC_CANDIDATE':
        return 'HOLD_COMPILER_NOT_ADMITTED'
    return 'HOLD_NATIVE_COMPILER_BINDING_AND_VERIFIER'
