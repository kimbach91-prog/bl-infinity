"""Pure illustrative capability-network route selection. Never dispatches or leases.

Source principle: Brain Federation and computing authority are separable;
logical topology does not imply physical capacity or live native admission.
"""
from dataclasses import dataclass
from hashlib import sha256
from collections import deque
import json
import re

class NetworkRejected(ValueError): pass

@dataclass(frozen=True)
class Cell:
    name: str
    capabilities: tuple[str,...]
    healthy: bool
    capacity: int
    data_ceiling: str = 'PUBLIC'

@dataclass(frozen=True)
class RouteRequest:
    start: str
    goal: str
    capability: str
    units: int=1
    data_class: str='PUBLIC'
    effect: str='PURE'


def route_public(cells: tuple[Cell,...],edges: tuple[tuple[str,str],...],r:RouteRequest)->dict:
    if type(cells) is not tuple or not 1<=len(cells)<=24 or type(edges) is not tuple or len(edges)>128 or not isinstance(r,RouteRequest):
        raise NetworkRejected('Unbounded or malformed routing fabric')
    if (r.data_class!='PUBLIC' or r.effect!='PURE' or type(r.units) is not int
            or not 1<=r.units<=16):
        raise NetworkRejected('No protected data or effect admission from synthetic router')
    name_ok=lambda x: type(x) is str and bool(re.fullmatch('[A-Za-z0-9_-]{1,48}',x))
    registry={}
    for cell in cells:
        if (not isinstance(cell,Cell) or not name_ok(cell.name) or cell.name in registry
                or type(cell.healthy) is not bool or type(cell.capacity) is not int
                or not 0<=cell.capacity<=100 or cell.data_ceiling!='PUBLIC'
                or type(cell.capabilities) is not tuple or len(cell.capabilities)>16
                or any(not name_ok(c) for c in cell.capabilities)
                or len(cell.capabilities)!=len(set(cell.capabilities))):
            raise NetworkRejected('Invalid or duplicate cell')
        registry[cell.name]=cell
    if not name_ok(r.start) or not name_ok(r.goal) or not name_ok(r.capability) or r.start not in registry or r.goal not in registry:
        raise NetworkRejected('Unbound route endpoint or capability')
    links={n:[] for n in registry}
    seen=set()
    for e in edges:
        if (type(e) is not tuple or len(e)!=2 or any(n not in registry for n in e)
                or e[0]==e[1] or e in seen):
            raise NetworkRejected('Invalid/duplicate route edge')
        seen.add(e);links[e[0]].append(e[1])
    eligible=lambda n: registry[n].healthy and registry[n].capacity>=r.units
    if not eligible(r.start) or not eligible(r.goal) or r.capability not in registry[r.goal].capabilities:
        return _hold('HOLD_RESOURCE_OR_CAPABILITY_MISSING')
    q=deque([[r.start]]);visited={r.start}
    while q:
        path=q.popleft()
        if path[-1]==r.goal:
            return {'state':'PUBLIC_GRAPH_PATH_REFERENCE_ONLY','route':path,
                    'route_digest':sha256(json.dumps(path,separators=(',', ':')).encode()).hexdigest(),
                    'real_lease':False,'provider_permission':False,'native_dispatch':False,
                    'runtime_ack':False,'physical_resource_credit':0,'external_effect':False}
        for nxt in sorted(links[path[-1]]):
            if nxt not in visited and eligible(nxt):
                visited.add(nxt);q.append(path+[nxt])
    return _hold('HOLD_NO_BOUNDED_PATH')


def _hold(state):
    return {'state':state,'route':None,'real_lease':False,
            'provider_permission':False,'native_dispatch':False,
            'runtime_ack':False,'physical_resource_credit':0,'external_effect':False}
