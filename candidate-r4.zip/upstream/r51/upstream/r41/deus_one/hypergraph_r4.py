"""PUBLIC synthetic multi-axis hypergraph. No execution or rights inheritance.

This module models multiary *relations*, not physical dimensionality or actual
DEUS multi-node dispatch. An all-member, all-axis witness is required. Never
interpret a connection as admission, bandwidth, or transferable authority.
"""
from dataclasses import dataclass
from hashlib import sha256
import json, re

AXES=('DOMAIN','REPRESENTATION','TIME','LOCALITY','PROVENANCE','VALIDITY')
KINDS=frozenset({'COMPOSES','CORROBORATES','PRESERVES','CONSTRAINS'})
TOK=re.compile(r'^[A-Za-z0-9_.:-]{1,64}$')
class HypergraphError(ValueError): pass

@dataclass(frozen=True)
class HyperCell:
    id: str
    facets: tuple[tuple[str,str],...]
    data_class: str='PUBLIC'
    simulated: bool=True

@dataclass(frozen=True)
class HyperRelation:
    id: str
    members: tuple[str,...]
    constraints: tuple[tuple[str,str],...]
    kind: str='COMPOSES'
    inferred_authority: bool=False


def _valid_facets(facets):
    return type(facets) is tuple and len(facets)==6 and tuple(a for a,_ in facets)==AXES and all(type(v) is str and TOK.fullmatch(v) for _,v in facets)


def _cell_map(cells):
    if type(cells) is not tuple or not 1<=len(cells)<=24: raise HypergraphError('Finite tuple of cells required')
    out={}
    for c in cells:
        if (not isinstance(c,HyperCell) or type(c.id) is not str or not TOK.fullmatch(c.id)
                or c.id in out or not _valid_facets(c.facets) or c.data_class!='PUBLIC'
                or c.simulated is not True):
            raise HypergraphError('Invalid/duplicate cell, nonpublic, or forged native status')
        out[c.id]=c
    return out


def compose_public(cells:tuple[HyperCell,...], relations:tuple[HyperRelation,...],wanted:tuple[str,...])->dict:
    """Return certificates for bounded relations covering requested participants.

    A hyperedge is admitted as a *logical witness* only if each mandatory
    participant is present and satisfies every declared dimension constraint.
    No rule can grant rights or infer equivalence from shared labels.
    """
    nodes=_cell_map(cells)
    if (type(relations) is not tuple or len(relations)>48 or type(wanted) is not tuple
            or not 1<=len(wanted)<=12 or len(set(wanted))!=len(wanted)
            or any(w not in nodes for w in wanted)):
        raise HypergraphError('Unbounded or missing requested cells')
    seen=set(); accepted=[]; rejected=[]
    for e in relations:
        if (not isinstance(e,HyperRelation) or type(e.id) is not str or not TOK.fullmatch(e.id)
                or e.id in seen or type(e.members) is not tuple or not 2<=len(e.members)<=6
                or len(set(e.members))!=len(e.members) or any(m not in nodes for m in e.members)
                or type(e.constraints) is not tuple or not 1<=len(e.constraints)<=6 or e.kind not in KINDS
                or e.inferred_authority is not False):
            raise HypergraphError('Malformed edge or forged permission')
        seen.add(e.id)
        axes=set()
        for a,v in e.constraints:
            if a not in AXES or a in axes or type(v) is not str or not TOK.fullmatch(v):
                raise HypergraphError('Invalid dimensional constraint')
            axes.add(a)
        compatible=all(all(dict(nodes[m].facets)[a]==v for a,v in e.constraints) for m in e.members)
        report={'edge':e.id,'members':tuple(sorted(e.members)),'kind':e.kind}
        (accepted if compatible else rejected).append(report)
    # A collection of disconnected relations cannot be sold as superconnection.
    reached={wanted[0]};witness=[];unused=sorted(accepted,key=lambda x:x['edge'])
    changed=True
    while changed:
        changed=False
        for item in list(unused):
            ms=set(item['members'])
            if ms & reached and ms-reached:
                reached.update(ms);witness.append(item);unused.remove(item)
                changed=True
    missing=sorted(set(wanted)-reached)
    if missing:
        return {'state':'HOLD_DISCONNECTED_OR_INCOMPATIBLE_HYPERGRAPH','witness':[],
                'missing':missing,**_no_effect()}
    digest=sha256(json.dumps(witness,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    return {'state':'PUBLIC_HYPERRELATION_REFERENCE_ONLY','witness':witness,
            'missing':[],'witness_sha256':digest,'rejected_count':len(rejected),
            'proves_global_optimum':False,**_no_effect()}


def _no_effect():
    return {'target_ack':False,'real_lease':False,'authority_granted':False,
            'native_dispatch':False,'external_effect':False,'physical_capacity_gain':0}
