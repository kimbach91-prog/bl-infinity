"""R4 source-bound, inoperable metadata graph for hyperdimensions and search.

Not a native DEUS census. No private source hydration, provider grant, physical
capacity, trained model, target ACK, or whole-universe completeness claims.
"""
from collections.abc import Mapping
from hashlib import sha256
import json,re
from .architecture import validate_graph, graph_digest
from .extension import validate_extension
from .extension_r3 import validate_r3,sha

SCHEMA='deus-one-source-extension-r4/1'
FAMILIES=frozenset({'HYPERDIMENSION','MULTINODE','SEARCH','COMPRESSION',
                   'MAPPING','AUDIT','SECONDARY','SOURCE_GAP'})
STATES=frozenset({'CANON_DESIGN','SOURCE_METADATA_ONLY','HISTORICAL_SCOPED',
                  'RESEARCH_CANDIDATE','SOURCE_GAP','SYNTHETIC_LOCAL_TEST'})
KINDS=frozenset({'SOURCE_BRIDGE','LINEAGE','SEARCH_INDEX','RESEARCH_LINK',
                 'INVARIANT_OBLIGATION','HYPEREDGE_CONCEPT','SYNTHETIC_REFERENCE',
                 'CURRENT_GATE','ANTI_FALSE_ACCEPT'})
LIMITS={
 'source_content_census':'UNKNOWN_NOT_HYDRATED',
 'august_primary_content':'UNVERIFIED',
 'whole_corpus_completeness':'UNVERIFIED',
 'unclassified_20261008':'643_METADATA_UNRESOLVED',
 'out_of_domain_20261008':'9_PRESERVE_ISOLATION',
 'hyperdimensional_computing':'MATH_OR_REPRESENTATION_NOT_PHYSICAL_HARDWARE',
 'node_composition':'NO_CROSS_NODE_CAPACITY_AGGREGATION_WITHOUT_LEASE',
 'search':'METADATA_TRIANGULATION_NOT_NATIVE_XSEARCH',
 'backend':'NO_ACTUAL_ADMITTED_BRAIN_OR_PROVIDER',
 'private_source':'NOT_READ_NOT_COPIED',
 'prior_scar':'ALL_PRESERVED',
 'release':'SOURCE_CANDIDATE_NO_TARGET_ACK',
}
ROOT={'schema','model','version','r1_source_sha256','r2_source_sha256',
      'r3_source_sha256','nodes','edges','node_count','edge_count','continuity',
      'limits','source_candidate_only','runtime_target_ack','native_adapters_bound',
      'private_core_copied','whole_corpus_exhausted','real_multi_node_dispatch',
      'actual_multidimensional_compute_gain','new_model_weights'}
NODE={'id','title','family','state','source_ref','evidence_boundary',
      'runtime_callable','private_bytes_included','physical_credit',
      'whole_corpus_verified'}
EDGE={'from','to','kind','runtime_callable'}
IDENT=re.compile(r'^[A-Z][A-Z0-9-]{2,64}$')
class R4Rejected(ValueError): pass

def _canonical(o):
    try:
        s=json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
        x=json.loads(s)
    except (TypeError,ValueError,OverflowError) as exc:raise R4Rejected('Malformed source JSON') from exc
    if type(x) is not dict:raise R4Rejected('Object expected')
    return x

def validate_r4(r1:Mapping,r2:Mapping,r3:Mapping,r4:Mapping)->dict:
    try:
        b=validate_graph(r1);e=validate_extension(b,r2);f=validate_r3(b,e,r3)
    except (TypeError,ValueError,KeyError) as exc:raise R4Rejected('R1/R2/R3 predecessors not exact') from exc
    z=_canonical(r4)
    if (set(z)!=ROOT or z['schema']!=SCHEMA or z['model']!='DEUS-ONE'
        or z['version']!='R4-SOURCE-CANDIDATE' or z['continuity']!=b['continuity']
        or z['r1_source_sha256']!=graph_digest(b)
        or z['r2_source_sha256']!=sha(e) or z['r3_source_sha256']!=sha(f)):
        raise R4Rejected('Revision, pinned predecessors or continuity changed')
    if z['limits']!=LIMITS or z['source_candidate_only'] is not True or any(z[k] is not False for k in (
         'runtime_target_ack','native_adapters_bound','private_core_copied',
         'whole_corpus_exhausted','real_multi_node_dispatch',
         'actual_multidimensional_compute_gain','new_model_weights')):
        raise R4Rejected('Unjustified promotion/permissions/private copy')
    if (type(z['nodes']) is not list or type(z['edges']) is not list
        or type(z['node_count']) is not int or type(z['edge_count']) is not int
        or not 1<=len(z['nodes'])<=90 or not 1<=len(z['edges'])<=160
        or len(z['nodes'])!=z['node_count'] or len(z['edges'])!=z['edge_count']):
        raise R4Rejected('Unbounded metadata scope')
    old={x['id'] for x in b['nodes']+e['nodes']+f['nodes']}
    new={}
    for n in z['nodes']:
        if (type(n) is not dict or set(n)!=NODE
            or type(n['id']) is not str or not IDENT.fullmatch(n['id'])
            or n['id'] in old or n['id'] in new or n['state'] not in STATES
            or n['family'] not in FAMILIES or type(n['title']) is not str
            or not 1<=len(n['title'])<=130 or type(n['source_ref']) is not str
            or not n['source_ref'].startswith(('LiveBus:','Drive:','GitHub:'))
            or not 12<=len(n['source_ref'])<=195
            or any(w in n['source_ref'] for w in ('\n','\r','?','../','token=','key='))
            or type(n['evidence_boundary']) is not str
            or not 15<=len(n['evidence_boundary'])<=360
            or any(n[x] is not False for x in ('runtime_callable','private_bytes_included',
                                              'physical_credit','whole_corpus_verified'))):
            raise R4Rejected('Malformed or inflated capability descriptor')
        new[n['id']]=n
    if not FAMILIES.issubset({n['family'] for n in new.values()}):
        raise R4Rejected('A required audit dimension was silently omitted')
    for x in ('HYPERGRAPH-PUBLIC-TOY','MULTIRESOURCE-PUBLIC-TOY','SEARCH-METADATA-PUBLIC-TOY'):
        if x not in new or new[x]['state']!='SYNTHETIC_LOCAL_TEST':
            raise R4Rejected('Missing synthetic evidence label')
    if any(n['state']=='SYNTHETIC_LOCAL_TEST' and not n['id'].endswith('PUBLIC-TOY') for n in new.values()):
        raise R4Rejected('Unmarked synthetic surrogate')
    edges=set();nodes=old|set(new);child={n:[] for n in nodes}
    for ed in b['edges']+e['edges']+f['edges']+z['edges']:
        if (type(ed) is not dict or set(ed)!=EDGE or ed['from'] not in nodes
            or ed['to'] not in nodes or ed['from']==ed['to'] or ed['runtime_callable'] is not False):
            raise R4Rejected('Unauthorized/dangling connection')
        trip=(ed['from'],ed['to'],ed['kind'])
        if trip in edges:raise R4Rejected('Duplicate relationship, including across ancestors')
        edges.add(trip);child[ed['from']].append(ed['to'])
        if ed in z['edges'] and (ed['kind'] not in KINDS or
               (ed['from'] not in new and ed['to'] not in new)):
            raise R4Rejected('Unsupported or redundant R4 bridge')
    pending=set();visited=set()
    def dfs(n):
        if n in pending:raise R4Rejected('Causal cycle across R1-R4')
        if n in visited:return
        pending.add(n)
        for t in child[n]:dfs(t)
        pending.remove(n);visited.add(n)
    for n in child:dfs(n)
    return z

def scoped_report(r1,r2,r3,r4):
    g=validate_r4(r1,r2,r3,r4)
    return {'state':'SOURCE_METADATA_GRAPH_ONLY',
        'descriptive_nodes':sum(len(x['nodes']) for x in (r1,r2,r3,g)),
        'descriptive_edges':sum(len(x['edges']) for x in (r1,r2,r3,g)),
        'r4_sha256':sha(g),'native_bodies_read':False,
        'native_xsearch_called':False,'complete_corpus_claim':False,
        'physical_compute_gain_verified':False,'native_ack':False,
        'all_scars_preserved':True}
