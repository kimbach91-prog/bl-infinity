"""One PUBLIC finite reference flow over R2 graph; absolutely no native effects.

It ties metadata graph → finite map witness → synthetic neuro trace → typed
language envelope; execution is local and cannot produce production receipts.
"""
from __future__ import annotations
import re
from collections.abc import Mapping
from .extension import validate_extension, extension_summary
from .mapping import certify_finite_map, MappingWitness
from .neuro import simulate_neuro, verify_toy_trace, NeuroScenario
from .languages import encode_ir, decode_ir

class CompositionRejected(ValueError):
    pass

def compose_public_reference(base: Mapping, extension: Mapping,
                             witness: MappingWitness, scenario: NeuroScenario,
                             task_id: str) -> dict:
    if type(task_id) is not str or not re.fullmatch(r'[a-zA-Z0-9:_-]{1,96}', task_id):
        raise CompositionRejected('Invalid local task identifier')
    g = validate_extension(base, extension)
    mapped = certify_finite_map(witness)
    network = simulate_neuro(scenario)
    if not verify_toy_trace(scenario,network):
        raise CompositionRejected('Local synthetic trace failed reproducibility')
    from .extension import extension_summary
    summary=extension_summary(base,g)
    packet={'schema':'deus-one-r2-synthetic-datacodec/1',
            'task_id':task_id,'role':'tool','data_class':'PUBLIC','effect':'PURE',
            'semantic_type':'TEXT','source_sha256':summary['extension_sha256'],
            'value':mapped['witness_sha256']+':'+network['trace_sha256']}
    carrier=encode_ir(packet)
    if decode_ir(carrier)!=packet:
        raise CompositionRejected('Typed source/role mapping drift')
    return {'state':'PUBLIC_SYNTHETIC_COMPOSITION_ONLY','source_digest':summary['extension_sha256'],
            'mapping_proof':mapped,'neuro_trace_digest':network['trace_sha256'],
            'typed_packet_digest':carrier['sha256'],'integrity_replay':True,
            'runtime_ack':False,'native_skill_loaded':False,
            'external_model_calls':0,'owner_private_data_used':False,
            'independent_native_verifier':False}
