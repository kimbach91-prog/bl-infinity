"""Metadata-only multi-index search/coverage; never DEUS native XSearch.

A Drive file mirrored into a ledger is the SAME evidence lineage. The tool
must NOT upgrade correlated copies to independent source corroboration.
No bodies, user-private content, credentials or source code are accepted.
"""
from dataclasses import dataclass
import re, unicodedata

class SearchError(ValueError): pass
ID=re.compile(r'^[A-Za-z0-9_-]{5,128}$')
FAM=re.compile(r'^F(?:0[0-9]|[12][0-9]|3[0-6])$')

@dataclass(frozen=True)
class SourceCard:
    id:str
    label:str
    family:str
    lineage_root:str
    source_kind:str='DRIVE_METADATA'
    principal:str='BACH'
    source_date:str='UNKNOWN'
    aliases:tuple[str,...]=()
    state:str='METADATA_ONLY'


def _norm(s):
    if type(s) is not str or len(s)>180:return ''
    x=unicodedata.normalize('NFKC',s).casefold()
    return ' '.join(re.findall(r'[\w]+',x))


def _index(cards):
    if type(cards) is not tuple or len(cards)>180:raise SearchError('No unbounded private source collection')
    index={}
    for c in cards:
        if (not isinstance(c,SourceCard) or not ID.fullmatch(c.id) or c.id in index
            or type(c.label) is not str or not 1<=len(c.label)<=180
            or not FAM.fullmatch(c.family) or c.principal not in {'BACH','UNKNOWN','PHD'}
            or c.source_kind not in {'DRIVE_METADATA','LIVEBUS_TAB','GITHUB_PATH','EXTERNAL_METADATA'}
            or type(c.lineage_root) is not str or not ID.fullmatch(c.lineage_root)
            or c.state not in {'METADATA_ONLY','SOURCE_SCOPED','UNKNOWN'}
            or type(c.aliases) is not tuple or len(c.aliases)>8
            or any(not _norm(a) for a in c.aliases)
            or type(c.source_date) is not str or len(c.source_date)>30):
            raise SearchError('Malformed, ambiguous or duplicate metadata source')
        index[c.id]=c
    return index


def search_metadata(cards:tuple[SourceCard,...],query:str,allow_families:tuple[str,...]=())->dict:
    ix=_index(cards)
    q=_norm(query)
    if not 2<=len(q)<=100 or type(allow_families) is not tuple or any(not FAM.fullmatch(f) for f in allow_families):
        raise SearchError('Invalid bounded query or family')
    tokens=set(q.split());res=[];hidden=0
    for c in ix.values():
        if c.principal!='BACH':
            hidden+=1;continue
        if allow_families and c.family not in allow_families:continue
        names=(_norm(c.label),)+tuple(_norm(a) for a in c.aliases)
        if any(tokens.issubset(set(n.split())) for n in names) or q in names:
            res.append({'id':c.id,'family':c.family,'source_kind':c.source_kind,
                        'source_date':c.source_date,'state':c.state,'lineage_root':c.lineage_root})
    res.sort(key=lambda x:(x['family'],x['id']))
    return {'state':'METADATA_MATCH_ONLY','items':res,'matched':len(res),
            'excluded_nonowner_or_unknown':hidden,'source_universe_closed':False,
            'search_is_native_deus':False,'contents_examined':False,
            'private_egress':False}


def triangulate(cards:tuple[SourceCard,...],refs:tuple[str,...])->dict:
    ix=_index(cards)
    if type(refs) is not tuple or len(refs)>24 or len(set(refs))!=len(refs) or any(r not in ix for r in refs):
        raise SearchError('Invalid source references')
    known=[ix[r] for r in refs if ix[r].principal=='BACH']
    roots=sorted({c.lineage_root for c in known})
    return {'state':'PROVENANCE_TRIANGULATION_ONLY',
            'independent_lineages_claimable':len(roots),
            'lineage_roots':roots,
            'mirror_is_independent':False,
            'validated_factual_claim':False,'source_contents_examined':False,
            'excluded_scope_count':len(refs)-len(known)}


def coverage(cards:tuple[SourceCard,...],expected:tuple[str,...],
             primary_august_verified:bool=False,full_census_denominator:int|None=None)->dict:
    ix=_index(cards)
    if type(expected) is not tuple or not expected or len(set(expected))!=len(expected) or any(not FAM.fullmatch(f) for f in expected):
        raise SearchError('Invalid closed list of requested families')
    if primary_august_verified is not False or full_census_denominator is not None:
        # Only the owner-native collector, NOT this metadata fixture, closes denominator.
        raise SearchError('Unjustified whole-corpus completeness claim')
    observed={x.family for x in ix.values() if x.principal=='BACH'}
    missing=sorted(set(expected)-observed)
    return {'state':'INCOMPLETE_SOURCE_CENSUS', 'family_coverage_count':len(set(expected)-set(missing)),
            'missing_families':missing,'metadata_records_inspected':len(ix),
            'unclassified_metadata':sum(c.family=='F00' for c in ix.values()),
            'august_primary_contents_verified':False,
            'full_source_population_count':'UNKNOWN',
            'whole_deus_coverage_verified':False,'native_search_executed':False}
