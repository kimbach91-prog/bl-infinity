// DEUS-ONE PUBLIC independent KQK retrograde audit (not the private DEUS core).
// Chess scope: white king + white queen vs black king, no pawns/castling/en passant,
// legal king constraints; queen capture => immediate drawn terminal; cycles => draw.
// Metric is DTM in half-moves in this constrained 3-piece state model.
// Reproduces scope of archival 2026-09-08 KQK benchmark for independent reference.
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdlib>
#include <functional>
#include <iostream>
#include <limits>
#include <queue>
#include <sstream>
#include <string>
#include <tuple>
#include <vector>
using namespace std;

struct State {uint8_t wk, wq, bk, turn;};
constexpr int RAW = 64*64*64*2;
inline int file_(int s) {return s%8;}
inline int rank_(int s) {return s/8;}
inline int dist(int a, int b) {return max(abs(file_(a)-file_(b)),abs(rank_(a)-rank_(b)));}
inline bool adjacent(int a,int b) {return dist(a,b)<=1;}
inline int code(int wk,int wq,int bk,int turn) {return (((wk*64+wq)*64+bk)*2+turn);}

bool queen_checks(int q,int b,int w) {
  int dx=file_(b)-file_(q), dy=rank_(b)-rank_(q);
  if(!(dx==0||dy==0||abs(dx)==abs(dy))) return false;
  int n=max(abs(dx),abs(dy)), sx=(dx>0)-(dx<0), sy=(dy>0)-(dy<0);
  for(int k=1;k<n;k++) if((rank_(q)+k*sy)*8+file_(q)+k*sx==w) return false;
  return true;
}

bool valid(int wk,int wq,int bk,int turn) {
  if(wk==wq||wk==bk||wq==bk||adjacent(wk,bk)) return false;
  if(turn==0 && queen_checks(wq,bk,wk)) return false; // black cannot end own turn in check
  return true;
}

struct Arena {
  vector<State> st;
  vector<int> index;
  explicit Arena() : index(RAW,-1) {
    st.reserve(370000);
    for(int wk=0;wk<64;wk++) for(int wq=0;wq<64;wq++)
      for(int bk=0;bk<64;bk++) for(int turn=0;turn<2;turn++)
        if(valid(wk,wq,bk,turn)) {int id=code(wk,wq,bk,turn);index[id]=int(st.size());st.push_back({uint8_t(wk),uint8_t(wq),uint8_t(bk),uint8_t(turn)});}
  }
  template<class Fn> void edges(int i,Fn&& f) const {
    const auto &a=st.at(i);int wk=a.wk,wq=a.wq,bk=a.bk;
    if(a.turn==0) {
      for(int dr=-1;dr<=1;dr++) for(int df=-1;df<=1;df++) {
        if(!df&&!dr) continue;
        int nr=rank_(wk)+dr,nf=file_(wk)+df;
        if(nr<0||nr>=8||nf<0||nf>=8)continue;
        int nw=nr*8+nf;
        if(nw==wq||adjacent(nw,bk))continue;
        int j=index[code(nw,wq,bk,1)];if(j<0) abort();f(j);
      }
      for(int dr=-1;dr<=1;dr++)for(int df=-1;df<=1;df++){
        if(!df&&!dr) continue;
        int nr=rank_(wq)+dr,nf=file_(wq)+df;
        while(nr>=0&&nr<8&&nf>=0&&nf<8){int nq=nr*8+nf;
          if(nq==wk||nq==bk) break;
          int j=index[code(wk,nq,bk,1)];if(j<0) abort();f(j);
          nr+=dr;nf+=df;
        }
      }
    }else{
      for(int dr=-1;dr<=1;dr++)for(int df=-1;df<=1;df++){
        if(!df&&!dr)continue;
        int nr=rank_(bk)+dr,nf=file_(bk)+df;
        if(nr<0||nr>=8||nf<0||nf>=8)continue;
        int nb=nr*8+nf;
        if(nb==wk||adjacent(nb,wk))continue;
        if(nb==wq){f(-1);continue;} // Black takes queen: terminal draw
        if(queen_checks(wq,nb,wk))continue;
        int j=index[code(wk,wq,nb,0)];if(j<0)abort();f(j);
      }
    }
  }
};

struct Result { int valid=0,edges=0,checkmates=0,white_wins=0,draws=0,dtm_max=0,symmetry_fail=0,recurrence_fail=0,terminal_draw_edges=0;string example_fen;string example_uci;int example_dtm=-1;};
int reflected(int s,int sy,int sx,bool transpose){int r=rank_(s),f=file_(s);if(transpose) swap(r,f);if(sy)r=7-r;if(sx)f=7-f;return r*8+f;}

Result solve(const Arena &a){
  Result out;int n=int(a.st.size());out.valid=n;
  vector<vector<int>> predecessors(n);
  vector<int> remaining(n,0), dtm(n,-1), max_child(n,0);
  vector<uint8_t> win(n,0); // White can FORCE checkmate; unresolved loops are draws
  priority_queue<pair<int,int>,vector<pair<int,int>>,greater<pair<int,int>>> pq;
  for(int i=0;i<n;i++){
    const auto &s=a.st[i];
    a.edges(i,[&](int to){out.edges++;remaining[i]++;if(to<0)out.terminal_draw_edges++;else predecessors[to].push_back(i);});
    if(s.turn==1 && remaining[i]==0 && queen_checks(s.wq,s.bk,s.wk)){
      win[i]=1;dtm[i]=0;pq.emplace(0,i);out.checkmates++;
    }
  }
  while(!pq.empty()){
    const auto [d,u]=pq.top();pq.pop();
    for(int p:predecessors[u]){
      if(win[p])continue;
      if(a.st[p].turn==0){
        win[p]=1;dtm[p]=d+1;pq.emplace(d+1,p);
      }else{
        remaining[p]--;
        max_child[p]=max(max_child[p],d);
        if(remaining[p]==0){win[p]=1;dtm[p]=max_child[p]+1;pq.emplace(dtm[p],p);}
      }
    }
  }
  for(int i=0;i<n;i++) {
    if(win[i]){out.white_wins++;out.dtm_max=max(out.dtm_max,dtm[i]);}
    else out.draws++;
    int minimum=n+1,maximum=-1;bool has_nonwin=false;int successors=0;
    a.edges(i,[&](int to){successors++;if(to<0||!win[to])has_nonwin=true;else{minimum=min(minimum,dtm[to]);maximum=max(maximum,dtm[to]);}});
    if(win[i]){
      if(dtm[i]==0) {if(a.st[i].turn!=1||successors||!queen_checks(a.st[i].wq,a.st[i].bk,a.st[i].wk))out.recurrence_fail++;}
      else if(a.st[i].turn==0){if(minimum==n+1||dtm[i]!=minimum+1)out.recurrence_fail++;}
      else {if(has_nonwin||maximum<0||dtm[i]!=maximum+1)out.recurrence_fail++;}
    }else{
      if(a.st[i].turn==0 && minimum!=n+1)out.recurrence_fail++;
      if(a.st[i].turn==1 && !has_nonwin && successors>0)out.recurrence_fail++;
    }
    const auto &s=a.st[i];
    for(int swap_=0;swap_<2;swap_++)for(int sy=0;sy<2;sy++)for(int sx=0;sx<2;sx++) {
      int j=a.index[code(reflected(s.wk,sy,sx,swap_),reflected(s.wq,sy,sx,swap_),reflected(s.bk,sy,sx,swap_),s.turn)];
      if(j<0||dtm[j]!=dtm[i]||win[j]!=win[i])out.symmetry_fail++;
    }
  }
  // A concrete principal variation from a deterministic mate-in-5-ply state.
  // This is a winning reference sequence; all black alternatives were checked
  // by the full AND-side Bellman verifier above, not a single cherry-picked PV.
  for(int i=0;i<n;i++) if(a.st[i].turn==0 && dtm[i]==5) {
    const auto st=a.st[i];
    string fen;for(int row=7;row>=0;row--){int empties=0;
      for(int col=0;col<8;col++){int sq=row*8+col;char piece='\0';
        if(sq==st.wk)piece='K';else if(sq==st.wq)piece='Q';else if(sq==st.bk)piece='k';
        if(!piece)empties++;else{if(empties){fen+=to_string(empties);empties=0;}fen+=piece;}
      }
      if(empties)fen+=to_string(empties);
      if(row)fen+='/';
    }
    out.example_fen=fen+" w - - 0 1";out.example_dtm=5;
    int cursor=i;string pv;
    while(dtm[cursor]>0){int chosen=-1,opt=(a.st[cursor].turn==0?100000:-1);
      a.edges(cursor,[&](int to){if(to<0||!win[to])return;
        if((a.st[cursor].turn==0&&dtm[to]<opt)||(a.st[cursor].turn==1&&dtm[to]>opt)){
          chosen=to;opt=dtm[to];
        }
      });
      if(chosen<0||dtm[chosen]!=dtm[cursor]-1){out.recurrence_fail++;break;}
      const auto cur=a.st[cursor], nxt=a.st[chosen];
      int from=-1,to=-1;
      if(cur.turn==0){if(cur.wk!=nxt.wk){from=cur.wk;to=nxt.wk;}
        else{from=cur.wq;to=nxt.wq;}}
      else{from=cur.bk;to=nxt.bk;}
      auto coord=[](int sq){string t;t+=char('a'+file_(sq));t+=char('1'+rank_(sq));return t;};
      if(!pv.empty())pv+=' ';
      pv+=coord(from)+coord(to);cursor=chosen;
    }
    out.example_uci=pv;break;
  }
  return out;
}

int main(int argc,char** argv) {
  bool json=(argc>1 && string(argv[1])=="--json");
  Arena a;Result r=solve(a);
  bool match=(r.valid==368452 && r.checkmates==364 && r.white_wins==345404 && r.draws==23048 && r.dtm_max==20 && !r.symmetry_fail && !r.recurrence_fail);
  if(json){
    cout<<"{\"domain\":\"KQK_WHITE_FORCE_MATE\",\"source\":\"PUBLIC_INDEPENDENT_REFERENCE\",\"states\":"<<r.valid
       <<",\"edges_including_queen_capture_draw\":"<<r.edges<<",\"terminal_checkmates\":"<<r.checkmates
       <<",\"winning_states\":"<<r.white_wins<<",\"draw_states\":"<<r.draws<<",\"max_DTM_ply\":"<<r.dtm_max
       <<",\"symmetry_failures\":"<<r.symmetry_fail<<",\"bellman_failures\":"<<r.recurrence_fail
       <<",\"draw_capture_edges\":"<<r.terminal_draw_edges<<",\"example_DTM_ply\":"<<r.example_dtm<<",\"example_FEN\":\""<<r.example_fen<<"\",\"example_uci\":\""<<r.example_uci<<"\",\"historical_state_count_match\":"<<(match?"true":"false")
       <<",\"head_to_head_100x_claim_tested\":false,\"native_DEUS_runtime_ack\":false}"<<'\n';
  }else{
    cout<<"PUBLIC independent KQK retrograde solve: states "<<r.valid<<" edges "<<r.edges<<" checkmates "<<r.checkmates<<" wins "<<r.white_wins<<" draws "<<r.draws<<" maxDTM "<<r.dtm_max<<" symmetryFails "<<r.symmetry_fail<<" recurrenceFails "<<r.recurrence_fail<<" match "<<match<<'\n';
  }
  return match?0:1;
}
