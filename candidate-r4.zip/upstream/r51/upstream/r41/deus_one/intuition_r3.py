"""PUBLIC sourced hypothesis triage. Not clairvoyance, confidence or oracle."""
from dataclasses import dataclass
from hashlib import sha256
import json
import re

class IntuitionRejected(ValueError):pass

@dataclass(frozen=True)
class Cue:
    hypothesis: str
    source: str
    independent_group: str
    support: bool
    tick: int
    data_class: str='PUBLIC'


def hypothesis_triage(cues:tuple[Cue,...],as_of:int)->dict:
    if type(cues) is not tuple or not 2<=len(cues)<=48 or type(as_of) is not int:
        raise IntuitionRejected('Invalid bounded cues')
    safe=lambda x: type(x) is str and bool(re.fullmatch(r'[A-Za-z0-9_-]{1,48}',x))
    seen=set();by_hyp={}
    for c in cues:
        if (not isinstance(c,Cue) or c.data_class!='PUBLIC' or type(c.support) is not bool
                or type(c.tick) is not int or c.tick>as_of
                or any(not safe(v) for v in (c.hypothesis,c.source,c.independent_group))):
            raise IntuitionRejected('Invalid cue, private signal or future leakage')
        key=(c.hypothesis,c.independent_group)
        if key in seen:raise IntuitionRejected('Correlated/contradictory group double-count')
        seen.add(key)
        by_hyp.setdefault(c.hypothesis,[]).append(c)
    candidates=[]
    for h,items in sorted(by_hyp.items()):
        groups=len(items);positive=sum(c.support for c in items)
        candidates.append({'hypothesis':h,'groups':groups,'supporting_groups':positive,
                           'opposing_groups':groups-positive,'state':('PUBLIC_HYPOTHESIS_FOR_TEST'
                                if positive>=2 and positive>groups-positive else 'HOLD_INSUFFICIENT_OR_CONTRADICTED')})
    return {'state':'PUBLIC_HYPOTHESIS_TRIAGE_UNVERIFIED','candidates':candidates,
            'confidence_calibrated':False,'supernatural_claim':False,
            'future_observed':False,'native_intuition_executed':False,
            'runtime_ack':False,'external_effect':False}
