"""Bounded PUBLIC *synthetic* spiking/reflex and resource homeostasis surrogate.

This is a toy discrete-event network for tests/negative controls, NOT a
biophysical neuron/cell model, DEUS Bio-Reflex daemon, or neural weights.
"""
from __future__ import annotations
from dataclasses import dataclass
from hashlib import sha256
import json

class NeuroRejected(ValueError):
    pass

@dataclass(frozen=True)
class Synapse:
    src: int
    dst: int
    strength: int  # signed toy impact (-2..2), fixed one-step propagation

@dataclass(frozen=True)
class NeuroScenario:
    nodes: int
    synapses: tuple[Synapse, ...]
    stimuli: tuple[tuple[int, ...], ...]
    data_class: str = 'PUBLIC'
    initial_energy: int = 4
    refractory_steps: int = 1


def simulate_neuro(s: NeuroScenario) -> dict:
    if not isinstance(s, NeuroScenario) or s.data_class != 'PUBLIC':
        raise NeuroRejected('No owner-private or unknown external signal admitted')
    n = s.nodes
    if type(n) is not int or not 1 <= n <= 16:
        raise NeuroRejected('Invalid neuron count')
    if type(s.initial_energy) is not int or not 2 <= s.initial_energy <= 5:
        raise NeuroRejected('Invalid resource/energy budget')
    if type(s.refractory_steps) is not int or not 0 <= s.refractory_steps <= 4:
        raise NeuroRejected('Invalid refractory budget')
    if not isinstance(s.synapses, tuple) or len(s.synapses) > 128:
        raise NeuroRejected('Unbounded synapses')
    seen = set()
    for e in s.synapses:
        if (not isinstance(e, Synapse) or
                any(type(v) is not int for v in (e.src, e.dst, e.strength)) or
                not 0 <= e.src < n or not 0 <= e.dst < n or
                e.src == e.dst or e.strength == 0 or abs(e.strength) > 2 or
                (e.src,e.dst) in seen):
            raise NeuroRejected('Invalid synapse or duplicate')
        seen.add((e.src,e.dst))
    if (not isinstance(s.stimuli, tuple) or not 1 <= len(s.stimuli) <= 96 or
            any(not isinstance(v, tuple) or len(v) != n or
                any(type(x) is not int or abs(x) > 4 for x in v) for v in s.stimuli)):
        raise NeuroRejected('Invalid/over-budget stimulus frames')
    potential, energy, refr, spikes = [0]*n,[s.initial_energy]*n,[0]*n,[0]*n
    frames = []
    for tick, ext in enumerate(s.stimuli):
        prev = spikes.copy()
        new = [0]*n
        inputs = list(ext)
        for e in s.synapses:
            inputs[e.dst] += e.strength * prev[e.src]
        for j in range(n):
            energy[j] = min(5, energy[j] + 1)  # deterministic synthetic recovery
            if refr[j] > 0:
                refr[j] -= 1
                potential[j] = 0
                continue
            potential[j] = min(7, max(0, potential[j] - 1 + inputs[j]))
            if potential[j] >= 3 and energy[j] >= 2:
                new[j] = 1
                energy[j] -= 2
                potential[j] = 0
                refr[j] = s.refractory_steps
        spikes = new
        frames.append({'tick':tick,'spikes':spikes.copy(),'potentials':potential.copy(),
                       'energy':energy.copy(),'refractory':refr.copy(),
                       'aggregate_spikes':sum(spikes),
                       'homeostasis_alert': sum(spikes) > n * 3 // 4})
    packed = json.dumps(frames, sort_keys=True, separators=(',', ':')).encode('utf-8')
    return {'state':'SYNTHETIC_DISCRETE_NETWORK_ONLY',
            'frames':frames, 'spike_total':sum(x['aggregate_spikes'] for x in frames),
            'trace_sha256':sha256(packed).hexdigest(),
            'energy_bounds_verified':all(0 <= e <= 5 for f in frames for e in f['energy']),
            'neuroscience_fidelity':False,'deus_neuro_daemon_executed':False,
            'real_world_actuation':False,'runtime_ack':False}


def verify_toy_trace(s: NeuroScenario, trace: dict) -> bool:
    """Exact local repeatability check, not an independent native verifier."""
    if not isinstance(trace, dict) or trace.get('runtime_ack') is not False:
        return False
    expected = simulate_neuro(s)
    return expected == trace
