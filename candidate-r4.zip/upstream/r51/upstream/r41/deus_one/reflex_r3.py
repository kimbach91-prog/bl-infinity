"""PUBLIC synthetic reflex salience/attention, not a DEUS native Bio-Reflex daemon.

A spike only triggers an advisory attention packet, never owner effects.
"""
from dataclasses import dataclass
from hashlib import sha256
import json

class ReflexRejected(ValueError): pass

@dataclass(frozen=True)
class Signal:
    tick: int
    exc: int
    inh: int=0
    data_class: str='PUBLIC'


def simulate_reflex(signals:tuple[Signal,...],threshold:int=3,
                    refractory:int=1,energy_max:int=3)->dict:
    if (type(signals) is not tuple or not 1<=len(signals)<=80
            or type(threshold) is not int or not 1<=threshold<=8
            or type(refractory) is not int or not 0<=refractory<=8
            or type(energy_max) is not int or not 1<=energy_max<=8):
        raise ReflexRejected('Invalid bounded reflex configuration')
    last=-100; energy=energy_max; frames=[]
    for i,v in enumerate(signals):
        if (not isinstance(v,Signal) or v.data_class!='PUBLIC'
                or type(v.tick) is not int or v.tick!=i
                or type(v.exc) is not int or type(v.inh) is not int
                or not 0<=v.exc<=8 or not 0<=v.inh<=8):
            raise ReflexRejected('Malformed/nonpublic input signal')
        energy=min(energy_max,energy+1)
        salience=max(0,v.exc-v.inh)
        refractory_now=i-last<=refractory
        alert=not refractory_now and energy>=1 and salience>=threshold
        if alert:
            energy-=1;last=i
        frames.append({'tick':i,'salience':salience,'inhibited':v.inh>0,
                       'refractory':refractory_now,'attention_suggested':alert,
                       'remaining_energy':energy})
    return {'state':'PUBLIC_REFLEX_ATTENTION_SHADOW_ONLY',
            'trace_sha256':sha256(json.dumps(frames,sort_keys=True,separators=(',', ':')).encode()).hexdigest(),
            'frames':frames,'attention_count':sum(f['attention_suggested'] for f in frames),
            'native_bio_reflex_executed':False,'real_world_action':False,
            'neural_weight_updated':False,'biological_fidelity_proven':False,
            'authority_granted':False,'runtime_ack':False}
