"""PUBLIC R2 source-bounded extension graph; makes no new authority claims.

R1 source graph is immutable. The extension adds descriptive mapping/language/
neuro lineages and cannot modify any R1 claim, state, edge or runtime flag.
"""
from __future__ import annotations
import json
from hashlib import sha256
from collections.abc import Mapping
import re
from .architecture import validate_graph, graph_digest, GraphContractError

SCHEMA_R2 = 'deus-one-source-extension-r2/1'
STATES = frozenset({'SOURCE_SCOPED','HISTORICAL_SCOPED','SOURCE_METADATA_ONLY',
                    'RESEARCH_SCOPED','SPEC_CANDIDATE','UNVERIFIED_SCOPE',
                    'SYNTHETIC_LOCAL_TEST'})
KINDS = frozenset({'LINEAGE','SOURCE_BRIDGE','ANALOGY','RESEARCH_LINK',
                   'SYNTHETIC_REFERENCE','INVARIANT_OBLIGATION','GOVERNANCE'})
ID = re.compile(r'^[A-Z][A-Z0-9-]{2,64}$')

class ExtensionRejected(ValueError): pass

def _safe_source(source: object) -> bool:
    return (type(source) is str and len(source) < 190 and
            (source.startswith('LiveBus:') or source.startswith('Drive:')) and
            all(x not in source for x in ('\\n','\\r','secret','TOKEN','../','?')))

def _normal(x: object) -> dict:
    try:
        b=json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',', ':'),allow_nan=False)
        obj=json.loads(b)
        if type(obj) is not dict:
            raise ValueError('not object')
        return obj
    except (ValueError,TypeError,OverflowError) as exc:
        raise ExtensionRejected('Noncanonical extension') from exc


def validate_extension(base: Mapping, extension: Mapping) -> dict:
    try:
        b=validate_graph(base)
    except GraphContractError as exc:
        raise ExtensionRejected('R1 base failed validation') from exc
    x=_normal(extension)
    expected={'schema','version','base_model','base_graph_sha256','source_candidate_only',
              'runtime_ack','native_adapter_admission','training_checkpoint_included',
              'scientific_neural_fidelity','effect_count','nodes','edges',
              'node_count','edge_count','continuity','limits'}
    if set(x)!=expected or x['schema']!=SCHEMA_R2 or x['version']!='R2-SOURCE-CANDIDATE' or x['base_model']!='DEUS-ONE':
        raise ExtensionRejected('Wrong extension schema/fields/version')
    if x['base_graph_sha256']!=graph_digest(b):
        raise ExtensionRejected('Source base pin mismatch')
    if (x['source_candidate_only'] is not True or
            any(x[p] is not False for p in ('runtime_ack','native_adapter_admission',
                                           'training_checkpoint_included',
                                           'scientific_neural_fidelity')) or
            type(x['effect_count']) is not int or x['effect_count']!=0):
        raise ExtensionRejected('Attempted promotion/authority/physical effect')
    if x['continuity']!=b['continuity']:
        raise ExtensionRejected('Job lineage changed')
    if x['limits']!={'new_neural_weights':'NONE','new_private_source':'NONE',
                     'neuro_role':'SYNTHETIC_REFERENCE_ONLY',
                     'language_role':'PUBLIC_STRUCTURAL_REFERENCE_ONLY',
                     'mapping_role':'FINITE_PUBLIC_PROOF_ONLY',
                     'official_arc_score':'NOT_CLAIMED'}:
        raise ExtensionRejected('A material safety boundary is missing')
    if (type(x['nodes']) is not list or type(x['edges']) is not list or
            type(x['node_count']) is not int or type(x['edge_count']) is not int or
            len(x['nodes'])!=x['node_count'] or len(x['edges'])!=x['edge_count'] or
            not x['nodes']):
        raise ExtensionRejected('Invalid extension size')
    all_nodes={n['id'] for n in b['nodes']}
    new_nodes=set()
    for n in x['nodes']:
        fields={'id','title','family','state','source_ref','evidence_boundary',
                'admitted','private_bytes_included','model_weights_included',
                'biological_fidelity_proven'}
        if type(n) is not dict or set(n)!=fields:
            raise ExtensionRejected('Node schema mismatch')
        v=n['id']
        if (type(v) is not str or not ID.fullmatch(v) or
                v in all_nodes or v in new_nodes or
                type(n['title']) is not str or not n['title'] or len(n['title'])>125 or
                type(n['family']) is not str or n['family'] not in {'MAPPING','LANGUAGE','NEURO','CELL','PHILOSOPHY'} or
                n['state'] not in STATES or not _safe_source(n['source_ref']) or
                type(n['evidence_boundary']) is not str or not n['evidence_boundary'] or
                len(n['evidence_boundary'])>320 or
                any(n[p] is not False for p in ('admitted','private_bytes_included',
                         'model_weights_included','biological_fidelity_proven'))):
            raise ExtensionRejected('Duplicate node, unsafe source or forged claim')
        new_nodes.add(v)
    for protected in ('NEURO-TOY-LIF','CELL-HOMEOSTASIS-SYNTH','MAP-FINITE-REFERENCE','LANG-PACKET-REFERENCE'):
        hit=next((n for n in x['nodes'] if n['id']==protected),None)
        if not hit or hit['state']!='SYNTHETIC_LOCAL_TEST':
            raise ExtensionRejected('Synthetic surrogate promoted or removed')
    if any(n['id']=='LANG-BLX' and n['state']!='UNVERIFIED_SCOPE' for n in x['nodes']):
        raise ExtensionRejected('Unverified BLX semantics promoted')
    all_nodes.update(new_nodes)
    children={n:[] for n in all_nodes}
    prior=set()
    for e in b['edges']:
        children[e['from']].append(e['to'])
        prior.add((e['from'],e['to'],e['kind']))
    for e in x['edges']:
        if (type(e) is not dict or set(e)!={'from','to','kind','runtime_callable'} or
                e['from'] not in all_nodes or e['to'] not in all_nodes or
                e['from']==e['to'] or e['kind'] not in KINDS or e['runtime_callable'] is not False):
            raise ExtensionRejected('Non-typed or executable source edge')
        key=(e['from'],e['to'],e['kind'])
        if key in prior:
            raise ExtensionRejected('Duplicate edge')
        prior.add(key)
        children[e['from']].append(e['to'])
    active,done=set(),set()
    def walk(node):
        if node in active: raise ExtensionRejected('Combined graph cycle')
        if node in done:return
        active.add(node)
        for k in children[node]:walk(k)
        active.remove(node);done.add(node)
    for node in children:walk(node)
    return x


def extension_summary(base: Mapping, extension: Mapping)->dict:
    x=validate_extension(base,extension)
    return {'state':'SOURCE_R2_LOCAL_GRAPH_CONFORMANCE',
            'base_nodes':len(base['nodes']), 'extended_nodes':len(x['nodes']),
            'base_edges':len(base['edges']), 'extended_edges':len(x['edges']),
            'runtime_ack':False,'neural_checkpoint':False,
            'private_core_copied':False,
            'extension_sha256':sha256(json.dumps(x,sort_keys=True,ensure_ascii=False,
                                          separators=(',', ':')).encode()).hexdigest()}
