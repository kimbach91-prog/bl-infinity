"""PUBLIC, finite, falsifiable forward-regression and reverse-planning surrogates.

NO DEUS BL-SFRET execution, supernatural prophecy, neural world model, authority,
model weights, actual future-data access or live action. Source-bound only.
"""
from __future__ import annotations
from dataclasses import dataclass
from hashlib import sha256
import json
import re

class ForecastRejected(ValueError): pass

@dataclass(frozen=True)
class Window:
    ticks: tuple[int, ...]
    values: tuple[int, ...]
    as_of: int
    horizon: int = 1
    tolerance: int = 2
    data_class: str = 'PUBLIC'


def _median_int(a: list[int]):
    ordered = sorted(a)
    n = len(ordered)
    middle = n // 2
    if n % 2:
        return ordered[middle]
    # Fractions not needed if all steps are integral and odd-count slope is required.
    if (ordered[middle - 1] + ordered[middle]) % 2:
        raise ForecastRejected('Fractional slope not supported; HOLD')
    return (ordered[middle - 1] + ordered[middle]) // 2


def forecast_public(w: Window) -> dict:
    if not isinstance(w, Window) or w.data_class != 'PUBLIC':
        raise ForecastRejected('Public-only synthetic forecast')
    if (type(w.ticks) is not tuple or type(w.values) is not tuple or
        not 5 <= len(w.ticks) <= 64 or len(w.ticks) != len(w.values) or
        any(type(x) is not int for x in w.ticks+w.values) or
        type(w.as_of) is not int or type(w.horizon) is not int or not 1 <= w.horizon <= 8 or
        type(w.tolerance) is not int or not 0 <= w.tolerance <= 1000 or
        any(abs(v) > 1000000 for v in w.values)):
        raise ForecastRejected('Invalid bounded window')
    if (w.ticks[-1] != w.as_of or
        any(b-a != 1 for a,b in zip(w.ticks,w.ticks[1:]))):
        raise ForecastRejected('Stale, missing, duplicate, or future data detected')
    changes=[w.values[i+1]-w.values[i] for i in range(len(w.values)-1)]
    slope=_median_int(changes[:-1])
    last_change=changes[-1]
    fit_error=abs(last_change-slope)
    baseline_error=abs(last_change)
    state='PUBLIC_FORECAST_SCENARIO_UNVERIFIED'
    reason='bounded backward-checked trend, not calibrated future probability'
    prediction=None
    if fit_error>w.tolerance:
        state='HOLD_REGIME_CHANGE_OR_DRIFT'
        reason='last observed transition falsifies the supported historical slope'
    elif fit_error>baseline_error:
        state='HOLD_NO_BENEFIT_OVER_PERSISTENCE'
        reason='persistence baseline has lower holdout error'
    else:
        prediction=w.values[-1]+slope*w.horizon
        if abs(prediction)>10000000:
            state='HOLD_PREDICTION_OUT_OF_BOUND'
            prediction=None
    return {'state':state,'reason':reason,'as_of':w.as_of,'forecast_tick':w.as_of+w.horizon,
            'forecast_value':prediction,'fit_holdout_error':fit_error,
            'persistence_holdout_error':baseline_error,'horizon':w.horizon,
            'probability_calibrated':False,'external_effect':False,
            'future_observed':False,'runtime_ack':False,'native_sfret_invoked':False}


@dataclass(frozen=True)
class Backchain:
    start: str
    goal: str
    transitions: tuple[tuple[str,str],...]
    max_depth: int=8
    data_class: str='PUBLIC'


def backchain_public(p: Backchain) -> dict:
    if not isinstance(p,Backchain) or p.data_class!='PUBLIC':
        raise ForecastRejected('Public-only bounded backchain')
    safe=lambda x: type(x) is str and bool(re.fullmatch(r'[A-Za-z0-9_-]{1,48}',x))
    if (not safe(p.start) or not safe(p.goal) or p.start==p.goal or
        type(p.max_depth) is not int or not 1<=p.max_depth<=12 or
        type(p.transitions) is not tuple or len(p.transitions)>128 or
        any(type(e) is not tuple or len(e)!=2 or not all(safe(v) for v in e)
            for e in p.transitions)):
        raise ForecastRejected('Malformed bounded backchain')
    if len(set(p.transitions))!=len(p.transitions):
        raise ForecastRejected('Duplicate transition')
    reverse={}
    for a,b in p.transitions: reverse.setdefault(b,[]).append(a)
    path=[p.goal]
    frontier=[(p.goal,[p.goal])]
    seen={p.goal}
    while frontier:
        node,path=frontier.pop(0)
        if node==p.start:
            path=list(reversed(path))
            return {'state':'PUBLIC_HYPOTHETICAL_GOAL_PATH_ONLY','path':path,
                    'steps':len(path)-1,'independently_verified_reality':False,
                    'native_bl_regression_invoked':False,'runtime_ack':False,
                    'external_effect':False}
        if len(path)-1>=p.max_depth:continue
        for prev in sorted(reverse.get(node,[])):
            if prev not in seen:
                seen.add(prev);frontier.append((prev,path+[prev]))
    return {'state':'HOLD_GOAL_UNREACHABLE_IN_DECLARED_GRAPH','path':None,
            'steps':None,'independently_verified_reality':False,
            'native_bl_regression_invoked':False,'runtime_ack':False,
            'external_effect':False}
