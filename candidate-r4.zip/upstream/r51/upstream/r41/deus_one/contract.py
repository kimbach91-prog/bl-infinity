"""DEUS-ONE: PUBLIC ONLY reference contract; not owner-private DEUS core or deployed model.

No network, file I/O, model loading, credentials, or authority grants. Stable typed
ABI/provenance/negative tests for integrating existing independently admitted modules.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from hashlib import sha256
import json
import re
import zlib
from typing import Any, Mapping

_ALLOWED_CLASSES = {"PUBLIC", "OWNER_PRIVATE"}
_HASH_RE = re.compile(r"^[0-9a-f]{64}$")


def canon(x: Any) -> bytes:
    return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def digest(x: Any) -> str:
    return sha256(canon(x)).hexdigest()


@dataclass(frozen=True)
class CanonicalEnvelope:
    """No raw history in public reference code; hashes identify canonical references."""
    subject: str
    task_id: str
    kind: str
    data_class: str
    payload: Mapping[str, Any]
    idempotency_key: str
    context_ref: str = ""
    context_sha256: str = ""
    authority_ref: str = ""
    source_revision: str = ""

    def __post_init__(self):
        if self.data_class not in _ALLOWED_CLASSES:
            raise ValueError("Unknown data classification")
        if not self.subject or not self.task_id or not self.idempotency_key:
            raise ValueError("Missing immutable job identity")
        if self.context_ref and not _HASH_RE.fullmatch(self.context_sha256):
            raise ValueError("Context reference must have exact SHA256")
        if self.context_sha256 and not self.context_ref:
            raise ValueError("Context digest without authorized source reference")
        if not isinstance(self.payload, Mapping):
            raise ValueError("Invalid payload")
        canon(dict(self.payload))  # Reject non-JSON values and NaN up front.

    def fingerprint(self) -> str:
        return digest({"subject": self.subject, "task_id": self.task_id,
                       "kind": self.kind, "data_class": self.data_class,
                       "payload": dict(self.payload), "idempotency_key": self.idempotency_key,
                       "context_ref": self.context_ref, "context_sha256": self.context_sha256,
                       "authority_ref": self.authority_ref, "source_revision": self.source_revision})


LocalCandidateTask = CanonicalEnvelope


@dataclass(frozen=True)
class CandidateResult:
    state: str
    task_id: str
    method: str
    output: Any
    receipt: Mapping[str, Any]
    notes: str = ""


@dataclass
class CandidateKernel:
    """Deliberately restricted synthetic leaf. NOT the complete DEUS runtime."""
    _ledger: dict[tuple[str, str, str], tuple[str, CandidateResult]] = field(default_factory=dict)
    _effects: int = 0

    @property
    def effect_count(self) -> int:
        return self._effects

    def run(self, request: CanonicalEnvelope) -> CandidateResult:
        key = (request.subject, request.task_id, request.idempotency_key)
        fp = request.fingerprint()
        if key in self._ledger:
            oldfp, result = self._ledger[key]
            if oldfp != fp:
                return CandidateResult("CONFLICT", request.task_id, "idempotency", None, {},
                                       "Same key, changed typed input; no effect allowed")
            return result
        # This PUBLIC-ONLY local reference does not authenticate owner or execute remote effects.
        if request.data_class != "PUBLIC":
            result = self._hold(request, "HOLD_PRIVATE_ADMISSION", "Owner data cannot enter PUBLIC candidate")
        elif request.context_ref or request.authority_ref:
            result = self._hold(request, "HOLD_CONTEXT_OR_AUTHORITY_UNBOUND",
                                "A source reference/authority token cannot self-admit an adapter")
        elif request.kind == "arithmetic_exact":
            result = self._exact_math(request)
        else:
            result = self._hold(request, "HOLD_ADAPTER_NOT_BOUND",
                                "Neural/JEV/skill/Matrix/JEPA adapters require a qualified native consumer")
        self._ledger[key] = (fp, result)
        return result

    def _hold(self, request: CanonicalEnvelope, state: str, notes: str) -> CandidateResult:
        return CandidateResult(state, request.task_id, "none", None, {"fingerprint":request.fingerprint()}, notes)

    def _exact_math(self, request: CanonicalEnvelope) -> CandidateResult:
        p = request.payload
        if set(p) != {"op", "operands"} or p["op"] not in ("sum", "product"):
            return self._hold(request, "HOLD_SCHEMA", "No untyped evaluation or text-to-code allowed")
        xs = p["operands"]
        if not isinstance(xs, list) or not (1 <= len(xs) <= 16) or any(type(v) is not int or abs(v) > 10**9 for v in xs):
            return self._hold(request, "HOLD_SCHEMA", "Bounded explicit integers only")
        output = sum(xs) if p["op"] == "sum" else _product(xs)
        # Independent verification is required at target; this only shows local candidate arithmetic.
        receipt = {"contract": "deus-one-public-contract/0", "task": request.task_id,
                   "input_sha256": request.fingerprint(), "output_sha256": digest({"value": output}),
                   "scope": "ISOLATED_PUBLIC_LOCAL", "model_calls": 0,
                   "runtime_ack": False, "external_verifier": False}
        self._effects += 1
        return CandidateResult("CANDIDATE_LOCAL_RESULT", request.task_id, "typed_arithmetic", output, receipt,
                               "No production target; do not promote to VERIFIED_DONE")


def _product(xs: list[int]) -> int:
    result = 1
    for v in xs:
        result *= v
    return result


def lossless_pack(record: Mapping[str, Any]) -> bytes:
    """Exact-byte compacting, not a claim of semantic lossless cognition."""
    data = canon(dict(record))
    return b"DEUS1" + bytes.fromhex(sha256(data).hexdigest()) + zlib.compress(data, level=9)


def lossless_unpack(packed: bytes) -> dict[str, Any]:
    if not isinstance(packed, bytes) or len(packed) < 39 or packed[:5] != b"DEUS1":
        raise ValueError("Invalid archive format")
    blob = zlib.decompress(packed[37:])
    if sha256(blob).digest() != packed[5:37]:
        raise ValueError("Integrity violation")
    result = json.loads(blob)
    if not isinstance(result, dict) or canon(result) != blob:
        raise ValueError("Noncanonical archive")
    return result


def jev_gate(candidate: Mapping[str, Any]) -> str:
    """JEV placeholder: NO model weights or score semantics are sourced/admitted."""
    if not isinstance(candidate, Mapping):
        return "HOLD_JEV_UNBOUND"
    return "HOLD_JEV_UNBOUND"
