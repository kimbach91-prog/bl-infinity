"""R3 bounded source metadata extension: network, reflex, forecast and compression.

Does not hydrate or reconstruct private DEUS, implement actual BL-SFRET/JEV, grant
permission, train neural weights, invoke existing models or certify future events.
"""
from __future__ import annotations
from collections.abc import Mapping
from hashlib import sha256
import json
import re
from .architecture import graph_digest, validate_graph
from .extension import validate_extension

SCHEMA='deus-one-source-extension-r3/1'
STATES=frozenset({'SOURCE_METADATA_ONLY','SOURCE_SCOPED','CANON_DESIGN',
                  'HISTORICAL_SCOPED','RESEARCH_CANDIDATE','QUALITY_HOLD',
                  'SYNTHETIC_LOCAL_TEST','UNVERIFIED_SCOPE'})
FAMILIES=frozenset({'NETWORK','COMPRESSION','REFLEX','INTUITION',
                    'FORECAST','BACKCHAIN','NEURAL','EVOLUTION'})
EDGE_TYPES=frozenset({'LINEAGE','SOURCE_BRIDGE','ANALOGY','RESEARCH_LINK',
                      'INVARIANT_OBLIGATION','GOVERNANCE','SYNTHETIC_REFERENCE'})
LIMITS={
    'private_data_egress':'DENY_WITHOUT_TASK_FIT_ADMISSION',
    'brain_simulation':'SYNTHETIC_BIOMIMETIC_REFERENCE_NOT_FIDELITY',
    'intuition':'EVIDENCE_BOUND_HYPOTHESIS_NOT_CLAIRVOYANCE',
    'prophecy':'FALSIFIABLE_FORECAST_OR_GOAL_BACKCHAIN_NOT_CERTAINTY',
    'regression':'HISTORICAL_DATA_ONLY_NO_FUTURE_LEAKAGE',
    'compression':'LOSSLESS_PROTECTED_SCARS_AND_UNKNOWN_REQUIRED',
    'network':'NO_LIVE_LEASE_NO_ADMISSION_NO_PHYSICAL_RESOURCE_CREDIT',
    'neural':'NO_NEW_WEIGHT_CHECKPOINT_NO_GENERAL_LANGUAGE_PROOF',
    'previous_negatives':'PRESERVED',
    'release':'NO_DEPLOY_NO_NATIVE_ACK',
}
ROOT_FIELDS={'schema','version','model','r1_source_sha256','r2_source_sha256',
             'source_candidate_only','runtime_target_ack','live_native_adapter_bound',
             'private_source_copied','own_weight_checkpoint_included',
             'scientific_brain_fidelity_proven','physical_compute_credited',
             'nodes','edges','node_count','edge_count','continuity','limits'}
NODE_FIELDS={'id','title','family','state','source_ref','evidence_boundary',
             'runtime_callable','owner_private_included','model_weights_included',
             'biological_fidelity_proven','forecast_certainty_claim'}
EDGE_FIELDS={'from','to','kind','runtime_callable'}
ID=re.compile(r'^[A-Z][A-Z0-9-]{2,64}$')

class R3Rejected(ValueError):pass


def canonical(x):
    try:
        b=json.dumps(x,sort_keys=True,separators=(',', ':'),
                     ensure_ascii=False,allow_nan=False)
        val=json.loads(b)
        if type(val) is not dict:raise ValueError('Not a dict')
        return val
    except (TypeError,ValueError,OverflowError) as exc:
        raise R3Rejected('Noncanonical manifest') from exc


def sha(x):
    return sha256(json.dumps(x,sort_keys=True,separators=(',', ':'),
                             ensure_ascii=False,allow_nan=False).encode()).hexdigest()


def validate_r3(base:Mapping,r2:Mapping,r3:Mapping)->dict:
    try:
        b=validate_graph(base)
        e=validate_extension(b,r2)
    except (ValueError,TypeError,KeyError) as exc:
        raise R3Rejected('Predecessor R1/R2 cannot be independently validated') from exc
    x=canonical(r3)
    if (set(x)!=ROOT_FIELDS or x['schema']!=SCHEMA or
            x['version']!='R3-SOURCE-CANDIDATE' or x['model']!='DEUS-ONE'
            or x['r1_source_sha256']!=graph_digest(b) or
            x['r2_source_sha256']!=sha(e)):
        raise R3Rejected('Wrong R3 schema or previous source pins')
    if x['limits']!=LIMITS or x['continuity']!=b['continuity']:
        raise R3Rejected('Protected limits or job identity changed')
    if x['source_candidate_only'] is not True or any(
            x[k] is not False for k in ('runtime_target_ack','live_native_adapter_bound',
                'private_source_copied','own_weight_checkpoint_included',
                'scientific_brain_fidelity_proven','physical_compute_credited')):
        raise R3Rejected('Forged authority, native weights, biology or deployment')
    if (type(x['nodes']) is not list or type(x['edges']) is not list or
            type(x['node_count']) is not int or type(x['edge_count']) is not int or
            not 1<=len(x['nodes'])<=80 or not 1<=len(x['edges'])<=160 or
            len(x['nodes'])!=x['node_count'] or len(x['edges'])!=x['edge_count']):
        raise R3Rejected('Unbounded/mismatched candidate graph')
    seen={n['id'] for n in b['nodes']} | {n['id'] for n in e['nodes']}
    newer={}
    for n in x['nodes']:
        if type(n) is not dict or set(n)!=NODE_FIELDS:
            raise R3Rejected('Invalid capability fields')
        name=n['id']
        if (type(name) is not str or not ID.fullmatch(name) or name in seen
                or name in newer or n['family'] not in FAMILIES or n['state'] not in STATES
                or type(n['title']) is not str or not 1<=len(n['title'])<=128
                or type(n['source_ref']) is not str or not 8<=len(n['source_ref'])<=190
                or not n['source_ref'].startswith(('Drive:','LiveBus:'))
                or any(y in n['source_ref'] for y in ('\n','\r','?','../','TOKEN','secret'))
                or type(n['evidence_boundary']) is not str or not 1<=len(n['evidence_boundary'])<=360
                or any(n[k] is not False for k in (
                    'runtime_callable','owner_private_included','model_weights_included',
                    'biological_fidelity_proven','forecast_certainty_claim'))):
            raise R3Rejected('Duplicate, ungrounded or inflated source node')
        newer[name]=n
    protected={'FORECAST-PUBLIC-TOY','BACKCHAIN-PUBLIC-TOY','REFLEX-PUBLIC-TOY',
               'INTUITION-PUBLIC-TOY','NETWORK-PUBLIC-TOY','COMPRESSION-PUBLIC-TOY'}
    if any(k not in newer or newer[k]['state']!='SYNTHETIC_LOCAL_TEST' for k in protected):
        raise R3Rejected('Synthetic surrogates must remain explicitly synthetic')
    if any(n['state']=='SYNTHETIC_LOCAL_TEST' and not n['id'].endswith('PUBLIC-TOY')
            for n in newer.values()):
        raise R3Rejected('Unattributed toy evidence')
    if not FAMILIES.issubset({v['family'] for v in newer.values()}):
        raise R3Rejected('Missing required cross-family source scope')
    all_nodes=seen|set(newer)
    edges=set(); children={n:[] for n in all_nodes}
    for ed in b['edges']+e['edges']+x['edges']:
        if (type(ed) is not dict or set(ed)!=EDGE_FIELDS or
                ed['from'] not in all_nodes or ed['to'] not in all_nodes or
                ed['from']==ed['to'] or ed['runtime_callable'] is not False):
            raise R3Rejected('Cross-graph edge is not strictly descriptive')
        if ed in x['edges'] and ed['kind'] not in EDGE_TYPES:
            raise R3Rejected('Unknown typed relationship')
        tup=(ed['from'],ed['to'],ed['kind'])
        if tup in edges:raise R3Rejected('Duplicate relationship across versions')
        edges.add(tup);children[ed['from']].append(ed['to'])
    visiting=set(); done=set()
    def visit(n):
        if n in visiting:raise R3Rejected('Dependency/causal cycle detected')
        if n in done:return
        visiting.add(n)
        for k in children[n]:visit(k)
        visiting.remove(n);done.add(n)
    for k in children:visit(k)
    if any(ed['from'] not in newer and ed['to'] not in newer for ed in x['edges']):
        raise R3Rejected('Dangling older-only edge in R3')
    return x


def source_report(base,r2,r3):
    r=validate_r3(base,r2,r3)
    return {'state':'R3_PUBLIC_SOURCE_GRAPH_ONLY',
            'total_descriptive_nodes':len(base['nodes'])+len(r2['nodes'])+len(r['nodes']),
            'total_descriptive_edges':len(base['edges'])+len(r2['edges'])+len(r['edges']),
            'r3_sha256':sha(r),'native_runtime_connected':False,
            'model_weight_training':False,'scientific_brain_validation':False,
            'future_certainty':False,'independent_runtime_verifier':False,
            'new_target_receipt':False}
