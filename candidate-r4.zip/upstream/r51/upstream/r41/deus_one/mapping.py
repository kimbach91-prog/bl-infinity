"""PUBLIC finite-domain mapping witness: a *surrogate* for typed BL Φ/Ψ checks.

This is not BL-EYE2/MAP/1 implementation or a native connector. It checks exact
finite diagrams and rejects any false quotient / stale-transition assumptions.
"""
from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import json
from collections.abc import Mapping


class MappingRejected(ValueError):
    pass


def _ensure_string_dict(x: object, name: str) -> dict[str, str]:
    if not isinstance(x, dict) or not x or len(x) > 64:
        raise MappingRejected(f"Invalid {name} mapping")
    if any(type(k) is not str or type(v) is not str or not k or not v or
           len(k) > 96 or len(v) > 96 for k, v in x.items()):
        raise MappingRejected(f"Invalid {name} value")
    return dict(x)


def _sha(x: dict) -> str:
    return sha256(json.dumps(x, sort_keys=True, separators=(',', ':'),
                             ensure_ascii=False, allow_nan=False).encode()).hexdigest()


@dataclass(frozen=True)
class MappingWitness:
    source_domain: str
    target_domain: str
    forward: dict[str, str]
    source_invariants: dict[str, str]
    target_invariants: dict[str, str]
    source_transition: dict[str, str]
    target_transition: dict[str, str]
    data_class: str = 'PUBLIC'
    source_pin: str = 'LiveBus:181_V8_MAPPING_CONTEXT!A2:J10'


def certify_finite_map(witness: MappingWitness) -> dict:
    """Certify bijection, invariant conservation and commuting transition square.

    A toy *finite* proof only. The canonical operator/semantic transport must be
    independently admitted and verified by DEUS. No authority granted here.
    """
    if not isinstance(witness, MappingWitness):
        raise MappingRejected('Unknown mapping witness type')
    if witness.data_class != 'PUBLIC':
        raise MappingRejected('OWNER_PRIVATE or unknown source needs separate native admission')
    if (not witness.source_domain or not witness.target_domain
            or witness.source_domain == witness.target_domain
            or len(witness.source_domain) > 80 or len(witness.target_domain) > 80
            or witness.source_pin != 'LiveBus:181_V8_MAPPING_CONTEXT!A2:J10'):
        raise MappingRejected('Invalid source/domain binding')
    phi = _ensure_string_dict(witness.forward, 'Phi')
    si = _ensure_string_dict(witness.source_invariants, 'source invariants')
    ti = _ensure_string_dict(witness.target_invariants, 'target invariants')
    st = _ensure_string_dict(witness.source_transition, 'source transition')
    tt = _ensure_string_dict(witness.target_transition, 'target transition')
    src, dst = set(phi), set(phi.values())
    if len(src) != len(dst):
        raise MappingRejected('Noninjective Phi would collapse distinguishable states')
    if (set(si) != src or set(st) != src or set(ti) != dst or set(tt) != dst
            or any(v not in src for v in st.values())
            or any(v not in dst for v in tt.values())):
        raise MappingRejected('Incomplete state/transition domain')
    psi = {v: k for k, v in phi.items()}
    for state, target in phi.items():
        if psi[target] != state:
            raise MappingRejected('Back-map not exact')
        if si[state] != ti[target]:
            raise MappingRejected('Protected invariant changed in translation')
        if phi[st[state]] != tt[target]:
            raise MappingRejected('Transition diagram does not commute')
    objective = {'source_domain': witness.source_domain,
                 'target_domain': witness.target_domain, 'phi': phi,
                 'source_invariants': si, 'target_invariants': ti,
                 'source_transition': st, 'target_transition': tt,
                 'source_pin': witness.source_pin}
    return {'state': 'FINITE_SYNTHETIC_MAPPING_PASS',
            'witness_sha256': _sha(objective), 'states_checked': len(src),
            'reverse_defined': True, 'invariants_preserved': True,
            'commuting_diagram': True, 'runtime_ack': False,
            'native_bl_mapping_executed': False, 'scientific_or_semantic_universality': False}
