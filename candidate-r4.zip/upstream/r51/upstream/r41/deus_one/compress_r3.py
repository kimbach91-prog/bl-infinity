"""Decision-safe exact record reuse; never removes FAIL/UNKNOWN or permission fields."""
import json
from hashlib import sha256
from collections.abc import Mapping

class CompressionRejected(ValueError): pass

REQUIRED={'id','source','version','data_class','status','scar','content'}

def _canonical(x):
    try:
        return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',', ':'),allow_nan=False)
    except (TypeError,ValueError,OverflowError) as exc:
        raise CompressionRejected('Unserializable record') from exc


def exact_evidence_reuse(records:list[dict])->dict:
    if type(records) is not list or not 1<=len(records)<=96:
        raise CompressionRejected('Invalid bounded ledger')
    unique={}; seen_ids={}; refs=[]
    for r in records:
        if not isinstance(r,dict) or set(r)!=REQUIRED:
            raise CompressionRejected('Record fields must preserve protected distinctions')
        if (r['data_class']!='PUBLIC' or r['status'] not in ('PASS','FAIL','UNKNOWN') or
            not isinstance(r['id'],str) or not 1<=len(r['id'])<=64 or
            not isinstance(r['source'],str) or not r['source'].startswith('LiveBus:') or
            not isinstance(r['version'],str) or not 1<=len(r['version'])<=64 or
            not isinstance(r['scar'],str) or not isinstance(r['content'],str)
            or len(r['content'])>10000 or len(r['scar'])>256 or
            (r['status']!='PASS' and not r['scar'])):
            raise CompressionRejected('Private, uncertified, missing scar or unsafe record')
        frozen=_canonical(r)
        digest=sha256(frozen.encode()).hexdigest()
        if r['id'] in seen_ids and seen_ids[r['id']]!=digest:
            raise CompressionRejected('Conflicting ID/state cannot be merged')
        seen_ids[r['id']]=digest
        unique[digest]=json.loads(frozen)
        refs.append(digest)
    result=[unique[k] for k in refs]
    if result!=records:
        raise CompressionRejected('Exact reconstructability violation')
    return {'state':'PUBLIC_EXACT_RECORD_REUSE_ONLY','references':refs,'dictionary':unique,
            'original_count':len(records),'unique_count':len(unique),
            'fail_retained':sum(r['status']=='FAIL' for r in records),
            'unknown_retained':sum(r['status']=='UNKNOWN' for r in records),
            'lossless_roundtrip':True,'model_quality_gain':False,
            'native_compression_executed':False,'runtime_ack':False}
