"""One PUBLIC non-effectful contract-demonstrator composing R1+R2+R3 only.

Not native DEUS, no Brain, weights, external model, owner data, deployment,
real forecast/prophecy, provider grant, independent oracle or final DONE state.
"""
from __future__ import annotations
from collections.abc import Mapping
from .extension_r3 import validate_r3, source_report
from .pipeline_r2 import compose_public_reference
from .mapping import MappingWitness
from .neuro import NeuroScenario, Synapse
from .network_r3 import Cell,RouteRequest,route_public
from .forecast_r3 import Window,ForecastRejected,forecast_public,Backchain,backchain_public
from .reflex_r3 import Signal,simulate_reflex
from .intuition_r3 import Cue,hypothesis_triage
from .compress_r3 import exact_evidence_reuse


def run_public_synthetic_r3(r1:Mapping,r2:Mapping,r3:Mapping)->dict:
    candidate=validate_r3(r1,r2,r3)
    prev=compose_public_reference(r1,r2,
        MappingWitness('S','T',{'a':'x','b':'y'},
                       {'a':'p','b':'q'},{'x':'p','y':'q'},
                       {'a':'b','b':'a'},{'x':'y','y':'x'}),
        NeuroScenario(2,(Synapse(0,1,1),),((4,0),(0,3),(0,0))),
        'PUBLIC_R3_INTEGRATION')
    net=route_public((Cell('a',('relay',),True,2),
                      Cell('b',('relay',),True,2),
                      Cell('c',('demo',),True,2)),
                     (('a','b'),('b','c')),RouteRequest('a','c','demo'))
    forecast=forecast_public(Window((0,1,2,3,4),(10,12,14,16,18),4))
    back=backchain_public(Backchain('now','goal',(('now','step'),('step','goal'))))
    refl=simulate_reflex((Signal(0,4),Signal(1,4),Signal(2,0,4)))
    intuition=hypothesis_triage((Cue('H1','s1','g1',True,1),
                                 Cue('H1','s2','g2',True,2)),2)
    ledger=exact_evidence_reuse([
        {'id':'k1','source':'LiveBus:EXAMPLE!A1','version':'v1','data_class':'PUBLIC',
         'status':'UNKNOWN','scar':'not-verifiable','content':'PUBLIC hypothetical'},
        {'id':'k1','source':'LiveBus:EXAMPLE!A1','version':'v1','data_class':'PUBLIC',
         'status':'UNKNOWN','scar':'not-verifiable','content':'PUBLIC hypothetical'}])
    if not (prev['runtime_ack'] is False and net['runtime_ack'] is False
            and forecast['forecast_value']==20 and back['path']==['now','step','goal']
            and refl['runtime_ack'] is False and intuition['confidence_calibrated'] is False
            and ledger['lossless_roundtrip'] and ledger['unknown_retained']==2):
        raise ValueError('Incompatible public synthetic composition; fail closed')
    report=source_report(r1,r2,candidate)
    return {'state':'PUBLIC_R3_FROZEN_SYNTHETIC_COMPOSITION_ONLY',
            'r2_result_sha256':prev['typed_packet_digest'],
            'r3_graph_sha256':report['r3_sha256'],
            'network_route_sha256':net['route_digest'],
            'forecast_scenario':forecast['forecast_value'],
            'future_observed':False,'regression_path':back['path'],
            'reflex_shadow_sha256':refl['trace_sha256'],
            'independent_hypotheses':intuition['candidates'][0]['groups'],
            'protected_unknowns_retained':ledger['unknown_retained'],
            'descriptive_nodes':report['total_descriptive_nodes'],
            'descriptive_edges':report['total_descriptive_edges'],
            'verified_native_inference':False,'runtime_target_ack':False,
            'native_connector_or_model_calls':0,'owner_private_egress':False,
            'model_training':False,'new_compute_leases':0,
            'independent_native_verifier':False}
