"""Reversible multi-axis symbolic mapping, NOT native BL Φ/Ψ or infinite geometry.

A forward edge must carry an inverse witness and preserve every declared axis.
Reordering independent mappings must commute; dependent maps must be admitted
as explicitly ordered, not inferred equivalent.
"""
from dataclasses import dataclass
from hashlib import sha256
import json,re

AXES=('DOMAIN','REPRESENTATION','TIME','LOCALITY','PROVENANCE','VALIDITY')
TOKEN=re.compile(r'^[a-zA-Z0-9_.:-]{1,64}$')
class MappingError(ValueError):pass

@dataclass(frozen=True)
class AxisBridge:
    axis:str
    pairs:tuple[tuple[str,str],...]


def _canonical_state(state):
    if type(state) is not tuple or len(state)!=6 or tuple(a for a,_ in state)!=AXES:
        raise MappingError('Exactly six typed ordered axes required')
    for a,b in state:
        if type(b) is not str or not TOKEN.fullmatch(b):raise MappingError('Noncanonical axis value')
    return dict(state)


def _bridge(b):
    if not isinstance(b,AxisBridge) or b.axis not in AXES or type(b.pairs) is not tuple or not 1<=len(b.pairs)<=32:
        raise MappingError('Invalid or unbounded axis bridge')
    d={};seen=set()
    for x,y in b.pairs:
        if (type(x) is not str or type(y) is not str or not TOKEN.fullmatch(x)
            or not TOKEN.fullmatch(y) or x in d or y in seen):
            raise MappingError('Noninvertible/collapsed representation')
        d[x]=y;seen.add(y)
    return d


def map_public(state:tuple[tuple[str,str],...],bridges:tuple[AxisBridge,...]):
    initial=_canonical_state(state)
    if type(bridges) is not tuple or not 1<=len(bridges)<=6:
        raise MappingError('Bounded transform sequence required')
    current=dict(initial);seen=set();inv=[]
    for b in bridges:
        d=_bridge(b)
        if b.axis in seen:raise MappingError('Dependent same-axis transform needs explicit typed program')
        seen.add(b.axis)
        if current[b.axis] not in d:raise MappingError('Source point outside declared bridge domain')
        current[b.axis]=d[current[b.axis]]
        inv.append((b.axis,{v:k for k,v in d.items()}))
    rebuilt=dict(current)
    for axis,d in reversed(inv):rebuilt[axis]=d[rebuilt[axis]]
    if rebuilt!=initial:raise MappingError('Failed inverse witness')
    out=tuple((a,current[a]) for a in AXES)
    blob=json.dumps({'source':state,'target':out},ensure_ascii=False,separators=(',',':')).encode()
    return {'state':'SYNTHETIC_6AXIS_REVERSIBLE_ONLY',
            'mapped':out,'inverse_roundtrip':True,
            'protected_axes_preserved':list(AXES),
            'witness_sha256':sha256(blob).hexdigest(),
            'runtime_ack':False,'native_mapping_executed':False,'private_source_copied':False}


def commutation_test(state,first:AxisBridge,second:AxisBridge):
    if first.axis==second.axis:raise MappingError('Noncommuting same-axis transforms must not be implied')
    p=map_public(state,(first,second))
    q=map_public(state,(second,first))
    return {'state':'SYNTHETIC_COMMUTATION_CHECK',
            'commutes':p['mapped']==q['mapped'],
            'native_proof':False,'trusted_cross_domain_equivalence':False}
