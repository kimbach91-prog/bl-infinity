"""PUBLIC standalone chess endgame ABI for DEUS-ONE candidate R4.1.

This is an independent benchmark reference and *not* the native BL-SFRET,
DEUS weights, admission bridge, external engine, or chess product serving.
Exact package state remains LOCAL_SCOPED_REFERENCE_ONLY.
"""
from __future__ import annotations
from collections.abc import Mapping
from pathlib import Path
from hashlib import sha256
import json
import shutil
import subprocess
import tempfile

REFERENCE_FILE = Path('deus_one/reference/chess_kqk_retrograde_r41.cpp')
KQK_EXPECTED = {
    'states': 368452,
    'edges_including_queen_capture_draw': 4891672,
    'terminal_checkmates': 364,
    'winning_states': 345404,
    'draw_states': 23048,
    'max_DTM_ply': 20,
    'symmetry_failures': 0,
    'bellman_failures': 0,
    'draw_capture_edges': 22176,
}
class TaskNotAdmitted(ValueError):
    pass
class NegativeVerifier(ValueError):
    pass

def _public_spec(spec: Mapping) -> None:
    if not isinstance(spec,Mapping):raise TaskNotAdmitted('Typed task required')
    keys={'task_id','data_class','domain','scope','effects','source_class'}
    if set(spec)!=keys:raise TaskNotAdmitted('Exact six-field request contract only')
    if not isinstance(spec['task_id'],str) or not spec['task_id'] or len(spec['task_id'])>100:
        raise TaskNotAdmitted('Invalid local task identity')
    if spec['data_class']!='PUBLIC' or spec['source_class']!='PUBLIC_REFERENCE_ONLY':
        raise TaskNotAdmitted('Private or unclassified data not permitted')
    if spec['domain']!='KQK' or spec['scope']!='LOCAL_REFERENCE_ONLY' or spec['effects']!='NONE':
        raise TaskNotAdmitted('No different games, native dispatch or external effects')

def run_scoped_kqk(spec: Mapping,root: Path,source_sha256: str) -> dict:
    """Compile and execute one allowlisted local C++ reference, never a live Brain job.

    No shell, no network, no owner private payloads. Hash pinned at source level.
    Compiler absence is a clean HOLD/blocked tool prerequisite, not success.
    """
    _public_spec(spec)
    src=Path(root)/REFERENCE_FILE
    if not src.is_file():raise NegativeVerifier('Public solver source absent')
    actual=sha256(src.read_bytes()).hexdigest()
    if actual!=source_sha256:raise NegativeVerifier('Source hash mismatch')
    compiler=shutil.which('g++')
    if not compiler:raise NegativeVerifier('No local compiler: HOLD')
    with tempfile.TemporaryDirectory(prefix='deus-one-r41-') as folder:
        binary=Path(folder)/'kqk'
        build=subprocess.run([compiler,'-std=c++17','-O3','-Wall','-Wextra','-Werror',str(src),'-o',str(binary)],
                             capture_output=True,text=True,timeout=60,check=False)
        if build.returncode!=0:raise NegativeVerifier('Source build FAILED: HOLD')
        output=subprocess.run([str(binary),'--json'],capture_output=True,text=True,timeout=20,check=False)
        if output.returncode!=0:raise NegativeVerifier('Independent KQK solver FAILED: HOLD')
        try:received=json.loads(output.stdout)
        except (json.JSONDecodeError,TypeError) as e:raise NegativeVerifier('Bad solver envelope') from e
    if any(received.get(key)!=value for key,value in KQK_EXPECTED.items()):
        raise NegativeVerifier('Independent state/Bellman/symmetry verification failed')
    if received.get('historical_state_count_match') is not True or received.get('head_to_head_100x_claim_tested') is not False or received.get('native_DEUS_runtime_ack') is not False:
        raise NegativeVerifier('Claim boundary violated')
    if received.get('example_DTM_ply')!=5 or len(received.get('example_uci','').split())!=5:
        raise NegativeVerifier('Mate-in-5-ply witness missing')
    return {
        'status':'PUBLIC_KQK_REFERENCE_LOCAL_SCOPED_PASS',
        'model':'DEUS-ONE R4.1 candidate (not native runtime)',
        'task_id':spec['task_id'],
        'source_sha256':actual,
        'benchmark_domain':'KQK',
        'verifier':'ALL_STATES_BELLMAN_PLUS_8_SYMMETRIES',
        'result':received,
        'native_executor_ack':False,
        'historical_100x_head_to_head_verified':False,
        'actual_compute_advantage_claim':None,
        'production_deployed':False,
        'owner_private_read':False,
        'trained_weights_changed':False,
    }
