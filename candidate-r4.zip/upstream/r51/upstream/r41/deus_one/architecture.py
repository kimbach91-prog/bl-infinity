"""PUBLIC metadata-only DEUS-ONE R1 architecture graph.

This module is intentionally inert: it cannot authenticate, invoke brains, install a
model, allocate compute, dispatch tools, or read owner-private DEUS implementations.
It enforces scope and source hygiene for a descriptive registry only.
"""
from __future__ import annotations

from hashlib import sha256
from collections.abc import Mapping
import json
import re

SCHEMA = 'deus-one-capability-architecture-r1/1'
STATUSES = frozenset({
    'CANON_DESIGN', 'SCOPED_TEST', 'SOURCE_METADATA_ONLY', 'SPEC_CANDIDATE',
    'RESEARCH_SCOPED', 'RESEARCH_CANDIDATE', 'DEPLOYED_ADVISORY_UNMEASURED',
    'DEPLOYED_CONTROL_UNMEASURED', 'PILOT_QUALITY_HOLD', 'UNVERIFIED_SCOPE',
    'SOURCE_CANDIDATE', 'SCOPED_RUNTIME_QUALITY_FAIL',
})
EDGE_TYPES = frozenset({'LINEAGE', 'GOVERNANCE', 'CANDIDATE_BRIDGE',
                        'DESIGN_ANALOGY', 'RESEARCH_LINK'})
ID_RE = re.compile(r'^[A-Z][A-Z0-9-]{2,64}$')
CANON_ROOT = 'https://docs.google.com/spreadsheets/d/'
REQUIRED_CONSTRAINTS = {
    'owner_private_egress': 'DENY_NO_ADMISSION',
    'scientific_cell_equivalence': 'NOT_PROVEN',
    'scientific_neural_fidelity': 'NOT_PROVEN',
    'jev_model_trained': 'UNKNOWN',
    'millennium_theorem_solved': 'NO_CLAIM',
    'arc3_official_hidden_score': 'NOT_CLAIMED',
    'native_weight_language_serving': 'NOT_VERIFIED',
    'skills_all_callable': 'NOT_VERIFIED',
    'release_status': 'NO_DEPLOY',
}


class GraphContractError(ValueError):
    pass


def _exact_keys(x: Mapping, fields: set[str], what: str) -> None:
    if not isinstance(x, Mapping) or set(x) != fields:
        raise GraphContractError(f'Bad {what} fields')


def _json_roundtrip(value):
    try:
        return json.loads(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(',', ':'), allow_nan=False))
    except (TypeError, ValueError, OverflowError) as exc:
        raise GraphContractError('Noncanonical data or unsupported type') from exc


def graph_digest(graph: Mapping) -> str:
    value = _json_roundtrip(graph)
    return sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                             separators=(',', ':')).encode('utf-8')).hexdigest()


def validate_graph(graph: Mapping) -> dict:
    """Fail closed on forged activation, source mismatch, invalid type or cycles.

    Returns an isolated normalized copy, never a dispatch-capable registry.
    """
    if not isinstance(graph, Mapping):
        raise GraphContractError('Not a mapping')
    g = _json_roundtrip(graph)
    expected = {'schema','model','version','canonical_drive','effectful_admission',
                'runtime_target_ack','source_body_census_complete',
                'copyright_and_private_core_bytes_included','node_count','edge_count',
                'status_semantics','nodes','edges','constraints','continuity'}
    _exact_keys(g, expected, 'root')
    if g['schema'] != SCHEMA or g['model'] != 'DEUS-ONE' or g['version'] != 'R1-SOURCE-CANDIDATE':
        raise GraphContractError('Invalid schema or state')
    if not isinstance(g['canonical_drive'], str) or not g['canonical_drive'].startswith(CANON_ROOT):
        raise GraphContractError('Unbound Drive canonical source')
    for flag in ('effectful_admission','runtime_target_ack','source_body_census_complete',
                 'copyright_and_private_core_bytes_included'):
        if g[flag] is not False:
            raise GraphContractError('A candidate cannot claim runtime/authority/private inclusion')
    if (not isinstance(g['nodes'], list) or not isinstance(g['edges'], list)
            or type(g['node_count']) is not int or type(g['edge_count']) is not int
            or len(g['nodes']) != g['node_count'] or len(g['edges']) != g['edge_count']
            or not g['nodes']):
        raise GraphContractError('Manifest cardinality mismatch')
    if not isinstance(g['constraints'], dict) or g['constraints'] != REQUIRED_CONSTRAINTS:
        raise GraphContractError('Required safety constraints modified')
    if (not isinstance(g['status_semantics'], dict)
            or set(g['status_semantics']) != STATUSES
            or any(not isinstance(s, str) or not s for s in g['status_semantics'].values())):
        raise GraphContractError('Invalid evidence states')
    if not isinstance(g['continuity'], dict) or set(g['continuity']) != {'parent','child','prior_candidate','source_of_truth'}:
        raise GraphContractError('Unbound work continuity')
    if g['continuity']['parent'] != 'JOB-DEUS-WORKSPACE-NATIVE-ACCEPTANCE-20261003-001':
        raise GraphContractError('Parent identity changed')
    if g['continuity']['child'] != 'DEUS-WORKSPACE-OSS-CODEX-20261012-001':
        raise GraphContractError('Child identity changed')

    node_fields = {'id','label','status','source','boundary','purpose','admitted','model_weights_included'}
    nodes = {}
    for n in g['nodes']:
        _exact_keys(n, node_fields, 'node')
        node_id = n['id']
        if (not isinstance(node_id,str) or not ID_RE.fullmatch(node_id)
                or node_id in nodes or n['status'] not in STATUSES
                or not all(isinstance(n[f], str) and n[f] for f in ('label','source','boundary','purpose'))
                or not (n['source'].startswith('LiveBus:') or n['source'].startswith('Drive:'))
                or n['admitted'] is not False or n['model_weights_included'] is not False):
            raise GraphContractError('Malformed/duplicate/forged node')
        nodes[node_id] = n

    # Claims requiring specialist validators must not emerge from metadata title or
    # biomimetic analogies. One source of truth cannot grant itself verified status.
    for n_id in ('BIO-CELL-SIM','BIO-BRAIN-SIM','JEV'):
        if n_id not in nodes or nodes[n_id]['status'] != 'UNVERIFIED_SCOPE':
            raise GraphContractError('Unverified scientific or JEV claim promoted')
    if nodes.get('BLINF-C',{}).get('status') != 'SPEC_CANDIDATE':
        raise GraphContractError('Unadmitted cognitive language promoted')
    if nodes.get('DNB-OWN-WEIGHTS',{}).get('status') != 'PILOT_QUALITY_HOLD':
        raise GraphContractError('Untrained own-weight language model promoted')
    if nodes.get('DEUS-ONE-API',{}).get('status') != 'SOURCE_CANDIDATE':
        raise GraphContractError('Runtime adoption forged')
    edge_fields = {'from','to','kind','runtime_callable'}
    edges = set()
    children = {k: [] for k in nodes}
    for e in g['edges']:
        _exact_keys(e,edge_fields,'edge')
        if (e['from'] not in nodes or e['to'] not in nodes or e['from'] == e['to']
                or e['kind'] not in EDGE_TYPES or e['runtime_callable'] is not False):
            raise GraphContractError('Invalid or executable edge')
        triple = (e['from'],e['to'],e['kind'])
        if triple in edges:
            raise GraphContractError('Duplicate relationship')
        edges.add(triple)
        children[e['from']].append(e['to'])
    # DAG on descriptive edges: a topology cycle would hide dependency/audit loops.
    visiting, visited = set(),set()
    def visit(node: str) -> None:
        if node in visiting:
            raise GraphContractError('Cyclic architecture')
        if node in visited:
            return
        visiting.add(node)
        for target in children[node]:
            visit(target)
        visiting.remove(node)
        visited.add(node)
    for node in nodes:
        visit(node)
    return g


def candidate_binding_state(graph: Mapping, component: str, data_class: str) -> str:
    """Never treat a reference, private prompt or UI checkbox as admission."""
    g=validate_graph(graph)
    if data_class not in ('PUBLIC', 'OWNER_PRIVATE'):
        raise GraphContractError('Unknown data class')
    if component not in {n['id'] for n in g['nodes']}:
        raise GraphContractError('Unknown capability ID')
    if data_class == 'OWNER_PRIVATE':
        return 'HOLD_PRIVATE_ADMISSION'
    return 'HOLD_NATIVE_ADAPTER_AND_LEASE_NOT_BOUND'


def report_summary(graph: Mapping) -> dict:
    """Stable public descriptive audit. No executable plan, no code, no private data."""
    g=validate_graph(graph)
    counts={state:sum(n['status']==state for n in g['nodes']) for state in sorted(STATUSES)}
    return {'schema':g['schema'], 'digest':graph_digest(g),
            'descriptive_nodes':len(g['nodes']),'descriptive_edges':len(g['edges']),
            'states':counts,'target_ack':False,'runtime_promoted':False,
            'new_trained_weight_checkpoint':False}
