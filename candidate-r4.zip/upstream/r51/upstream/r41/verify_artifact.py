"""PUBLIC offline exact-byte manifest verifier (same-process local only)."""
from pathlib import Path
from hashlib import sha256
import json

ROOT=Path(__file__).resolve().parent

def main():
    j=json.loads((ROOT/'FILE_SHA256_R2.json').read_text())
    if j['schema']!='deus-one-r2-file-manifest/1' or j['signed'] is not False:
        raise SystemExit('Manifest not recognized; no provenance signature asserted')
    expected=set(j['files'])
    actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and
            '__pycache__' not in p.parts and not p.name.endswith('.pyc') and
            p.name!='FILE_SHA256_R2.json'}
    if expected!=actual:
        raise SystemExit('Missing, unexpected or extraneous archive file')
    for name,sha in j['files'].items():
        digest=sha256((ROOT/name).read_bytes()).hexdigest()
        if sha!=digest:
            raise SystemExit('Digest mismatch: '+name)
    print(f'OFFLINE_FILE_HASHES_PASS: {len(expected)} files; NOT a native signature/ACK')

if __name__=='__main__':main()
