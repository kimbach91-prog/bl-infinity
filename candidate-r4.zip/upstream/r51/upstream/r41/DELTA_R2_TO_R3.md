# DEUS-ONE R3 — source-bound union for federation, compression, reflex, intuition, forecast/backchain

**SCOPE:** PUBLIC metadata, finite synthetic contracts only. Prior R1/R2 source modules, tests and manifests are retained byte-for-byte; README and MODEL_CARD receive appended R3 notes. This is a new *candidate* extension in the **same job**, not new weights, native adapters, brain simulation, prophecy, or website deployment.

## What was added

- `CAPABILITY_EXTENSION_R3.json`: 31 source-index nodes and 51 typed non-callable relationships. Cumulative R1+R2+R3: **96 descriptive nodes and 134 descriptive relationships**. Counts are graph coverage, not hardware/active skills.
- `deus_one/extension_r3.py`: pins both R1 and R2 source digests; validates provenance, no runtime/authority/weights claims, role+source boundaries, status semantics, no duplicate/cyclic cross-version relationships, and six synthetic nodes that cannot be promoted.
- `deus_one/network_r3.py`: public in-memory capability graph traversal with availability, nominal capacity and PUBLIC/PURE restrictions. **No lease, dispatch or physical capacity credit**.
- `deus_one/compress_r3.py`: exact record dictionary/sequence reuse without discarding FAIL/UNKNOWN/scars, without merging distinct policy/source versions. No neural intelligence gain claimed.
- `deus_one/reflex_r3.py`: finite event attention with excitation/inhibition/refractory/resource bound. Never does owner or provider actions; not actual Bio-Reflex.
- `deus_one/intuition_r3.py`: independent-cue hypothesis triage and dissent. Hypothesis is *not* truth or superintuition/clairvoyance.
- `deus_one/forecast_r3.py`: time-fenced trend scenario, crude holdout-vs-persistence, drift rejection, bounded reverse goal-path. **No calibrated future probability or native BL-SFRET**.
- `deus_one/pipeline_r3.py`: one local composition over R1+R2+R3, with typed mapping/neuro, route, protected evidence, hypothetic forward/backward planning, no runtime effects or model calls.

## Evidence and boundary

- R2 baseline: **134/134 PASS** in the original archive unmodified.
- First R3 run: **217/218 PASS**, one test fixture incorrectly expected a fractional-median rejection from odd-cardinality history; the HISTORY fixture was corrected. Production/reference code unchanged for this failed assertion.
- Corrected full suite: **218/218 PASS**, Python warning-as-error, no external model, no network, no owner-private data.
- All historical FAIL/UNKNOWN remain. R3 cannot claim `VERIFIED_DONE`, real model checkpoint, language parity, native admission/ACK, browser or website deployment.

## Operational closure still required

The owner-native controller must bind actual stable CURRENT successor/adapter and task-fit authority, data grants, expiry, lease/fence and independent oracle. Run one exact task in native executor, observe target ACK and real useful answer, retain owner-private no-egress, cold resume without duplicate effects, roll back, and read Drive. Do not convert this local demo into capability admission.
