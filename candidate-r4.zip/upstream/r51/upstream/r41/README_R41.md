# DEUS-ONE R4.1 — finite adversarial retrograde / historical audit continuation

**Continuation of R4, not a separate DEUS runtime or a new trained LLM.**

- Previous 78 files are byte-pinned and unchanged via `R4_INHERITANCE_R41.json`.
- KQK C++17 exact retrograde solver: `deus_one/reference/chess_kqk_retrograde_r41.cpp`.
- Python typed PUBLIC-scoped integration: `deus_one/chess_endgame_r41.py`.
- Extension to the SAME capability graph: `CAPABILITY_EXTENSION_R41.json` (7 nodes, 9 descriptive typed edges; 146/213 accumulated).
- Historical and local benchmark comparison: `CHESS_SFRET_RETROGRADE_R41.md`.
- Reproduce with `python -m unittest discover -s tests -q` and `python verify_r41.py`. `g++` is required for the chess-specific tests. No internet/cloud/DEUS native backend/API/owner-private input involved.

Source pins and failure scars remain. The archival September report did **not** benchmark a live 100x opponent. It did demonstrate a scoped, reproducible 3-piece endgame retrograde/tablebase efficiency effect. R4.1 independently reproduces complete legal KQK state counts, Bellman and symmetry properties; NOT proof of novel 100x-compute winning strength. No direct native model inference, new model weights, product change, authority grant, or target ACK.

On the real DEUS executor, the next eligible task is bind **one** exact existing domain adapter with source/checkpoint/expiry/fence/lease, run independent paired baseline and negative controls, cold resume and rollback, and write the verified target receipt to Drive. This local package cannot self-authorize that step.
