"""Source-only R4.1 verifier, not a production DEUS / strong engine acceptance."""
from pathlib import Path
from hashlib import sha256
import json
from deus_one.chess_endgame_r41 import run_scoped_kqk
ROOT=Path(__file__).resolve().parent

def run():
    baseline=json.loads((ROOT/'R4_INHERITANCE_R41.json').read_text())
    assert len(baseline['files'])==78
    for name,digest in baseline['files'].items():
        assert sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
    evidence=json.loads((ROOT/'EVIDENCE_R41.json').read_text())
    assert evidence['predecessor_R4_package_sha256']==baseline['predecessor_R4_source_sha256']
    task={'task_id':'R41-VERIFIER-PUBLIC','data_class':'PUBLIC','domain':'KQK',
          'scope':'LOCAL_REFERENCE_ONLY','effects':'NONE','source_class':'PUBLIC_REFERENCE_ONLY'}
    result=run_scoped_kqk(task,ROOT,evidence['new_chess_source_sha256'])
    assert result['status']=='PUBLIC_KQK_REFERENCE_LOCAL_SCOPED_PASS'
    assert result['result']['bellman_failures']==0
    assert not result['native_executor_ack']
    ext=json.loads((ROOT/'CAPABILITY_EXTENSION_R41.json').read_text())
    assert not ext['runtime_target_ack'] and not ext['actual_chess_engine_100x_match_verified']
    print(json.dumps({'source_state':'R41_LOCAL_ENDGAME_REFERENCE_VERIFIED',
        'R4_inherited_files_exact':len(baseline['files']),
        'scope':'KQK_FULL_LEGAL_GRAPH_ONLY',
        'legal_states':result['result']['states'],
        'valid_edges':result['result']['edges_including_queen_capture_draw'],
        'independent_recurrence_errors':result['result']['bellman_failures'],
        'symmetry_errors':result['result']['symmetry_failures'],
        'cumulative_nodes':ext['total_descriptive_nodes'],
        'cumulative_edges':ext['total_descriptive_edges'],
        'actual_native_ack':False,
        'verified_100x_head_to_head':False},sort_keys=True))

if __name__=='__main__':run()
