# DEUS-ONE R4.1 — Hồi quy từ Đại Kết Cục / Chess KQK

**Scope:** publicly reproducible **KQK** (white king + white queen vs black king) finite, perfect-information, adversarial state graph. **Not** the full chess game and **not** an actual head-to-head against a stronger chess engine. This source is a new independent C++17 implementation, not the private DEUS core nor the original September implementation.

## Why this belongs in the existing DEUS-ONE architecture

- BL∞ source family: Grand Ending / BL-SFRET / realization backchain / telos constrained planning (LiveBus `178_V8_BL_HISTORY_DEEP_REDISCOVERY!A5:F5`, `78_OPERATOR_FOUNDRY_V2!A77:F79`).
- O2/O3: compile the particular 3-piece domain into a bounded state graph, derive terminal conditions (checkmate/stalemate/queen capture), and apply retrograde/minimax over **all** adversarial moves.
- O5: independently check the Bellman min/max relation over all solved states, the opponent's complete response set, and all eight board symmetries; preserve cycles and queen capture as draws.
- O1/O6: a precomputed table may be reused only with the **same domain, rule set, state fingerprint and version**. Reuse savings must include the cost to build/load/refresh the table in lifecycle comparisons.
- O4: an effectful native DEUS adapter requires an admitted source, runtime manifest, task-specific authority, lease/fence and target receipt. This R4.1 C++ executable is **only a local-public reference**.

## Independent reproduction (local candidate)

Input domain: legal KQK states on 8x8 board, with the side to move in each state; 3 pieces, no castling/en passant/pawns. Queen capture transitions to draw. Kings may never be adjacent. White-to-move states in which Black is in check are rejected as impossible history. Repetition/cycles are not forced wins. KQK mate DTM is at most 20 plies from the *reconstructed* state model; this is below the usual 50-move limit when starting with halfmove-clock 0. Neither a previously accumulated halfmove clock nor full chess history is modeled.

| Result | Reproduced locally | September 8 owner report |
| --- | ---: | ---: |
| Legal state positions | 368,452 | 368,452 |
| Legal transition edges including queen-capture-to-draw | 4,891,672 | 4,891,672 |
| Terminal checkmates | 364 | 364 |
| White-forced wins | 345,404 | 345,404 |
| Draw states | 23,048 | 23,048 |
| Max DTM | 20 plies | 20 plies |
| Bellman false invariants / D4 symmetry mismatches | 0 / 0 | 0 / 0 |

Sample *forced* 5-ply mate line in the local model:

- Start FEN `8/8/8/8/8/8/5Q2/K1k5 w - - 0 1`.
- UCI principal variation `a1a2 c1d1 a2b3 d1c1 f2e1` (Black's alternative legal responses are included in min/max verification).

Re-run: `g++ -std=c++17 -O3 -Wall -Wextra -Werror deus_one/reference/chess_kqk_retrograde_r41.cpp -o /tmp/kqk && /tmp/kqk --json`. Use `python -m unittest discover -s tests -q` in the package root. Use the documented source SHA pinned in `EVIDENCE_R41.json` to prevent inadvertent runner swaps.

## The claimed 100x opponent and apparent 10,000x speed

**Independent owner benchmark record:** [KQK retrograde benchmark, 2026-09-08](https://drive.google.com/file/d/1wsjLdrfc1W7IsBiROAV4GbLfW4du7AoT/view).

The report explicitly distinguishes a *hot precomputed table* from *cold forward re-search*:

- ~62,450x hot lookup versus naive fresh search, same finite bounded query set.
- ~13,543x hot lookup versus cold shared transposition-table search.
- ~4.16x when the search baseline also retained a warmed cache.
- ~1.70–5.16x when including table-graph and retrograde build time in that reported workload.

The 10,000-processor comparison in that document was **an analytical ideal-parallel extrapolation**, not a run of 10,000 real processors or a 100x-compute head-to-head victory. A separate authorized, measured engine-versus-engine match would need exact FEN set, both engines' versions, identical openings, clock/CPU-seconds/hardware/budget limits, independent FIDE referee/PGNs, and reproducible receipts. Until then the head-to-head claim is **UNVERIFIED**.

## Failure/UNKNOWN ledger

- Initial new-source compile under `-Werror` failed on misleading indentation; fixed without disabling strict compiler warnings.
- Second compile failed on a missing result field added with the PV feature; fixed and rerun.
- Non-KQK, OWNER_PRIVATE, runtime ACK injected by caller, wrong source hash and remote effects are rejected in tests.
- This local result **does not** establish novel superiority over conventional retrograde/tablebase methods, full-chess solving, production Brain adoption, independent engine match, or actual deployment.
- Prior R1–R4 files remain byte-identical in successor packaging; checkpoint training/weights/website are unchanged.
