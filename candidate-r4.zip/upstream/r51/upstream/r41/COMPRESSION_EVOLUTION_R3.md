# Compression, return-path and root-recursive evolution

Source registry: `59_COGNITIVE_EFFICIENCY_BENCHMARK`, `79_WORK_ELIMINATION_BENCH`, `178_V8_BL_HISTORY_DEEP_REDISCOVERY` rows 5–7, `204_V8_AUTONOMOUS_EVOLUTION_KERNEL`.

Preserve distinctions across compression: observation / hypothesis / scar / FAIL / UNKNOWN / authority / version / source ref / verifier. A reversible dictionary or exact event hash saves duplicates only; it does not prove cognition improved. Adaptive representation reduced bytes on a scope and helped a matched ARC set; object-graph compression reduced bytes but **hurt** correctness on its own matched set. One gain cannot compensate for a protected loss. Physical work avoidance from delta/cancellation is separate from compression ratio or neural intelligence.

Candidate DEUS-ONE feedback: new observation → typed source → operator/hypothesis selection → actual independent test → preserve counterexamples/failed approaches → maybe demote/compress old version with strict reversible citation → propose successor → shadow A/B → promotion only when independent verifier approves → monitor and rollback. For 'prophecy' or long-horizon regression, preserve *future uncertainty* rather than compressing a desired target into a falsely certain claim.

`compress_r3.py` preserves and reconstructs all PUBLIC records, including duplicate UNKNOWN and FAIL scars; conflicting rows of the same identity are rejected, private rows are rejected, and no native persistence is modified.
