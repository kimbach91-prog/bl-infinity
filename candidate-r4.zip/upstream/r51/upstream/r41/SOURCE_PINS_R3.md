# Source pins R3 — descriptive metadata only

**OWNER CUSTODY:** DEUS owner Google Drive canonical LiveBus, Drive ID `1pVtDbKFGECbogSR0-nrVDEecF8xQNelCux6GFUEmVrQ`; specific source branch readings on 2026-10-16. This is not a full native-source census or proof of admission. Source names, public statuses, and bounded source descriptions were used, not private code/credentials/weights.

| Purpose | Approved source locator | Evidence boundary |
|---|---|---|
| Root-recursive future/Grand Ending & absorb | LiveBus `178_V8_BL_HISTORY_DEEP_REDISCOVERY` rows 5–12,27–29 | Canon lineage + scoped/dormant, not live prophecy |
| Historical BL-SFRET title | Drive `1I1hkC0LxdMVR8ZlDw3FZ0NI-0ZxcZ66WOgb8ko2dcEw` | **Metadata only**; raw body not hydrated |
| Backchain/forecast operators | LiveBus `78_OPERATOR_FOUNDRY_V2` rows 77–79 | Names, contracts, test obligations; no fresh execution |
| Semantic V1/V2 hypothesis exchange | LiveBus `64_COGNITIVE_SYNERGY_FABRIC` rows 2–8 | Explicit runtime synergy OPEN |
| Reflex/organism network | LiveBus `143_V7_OMNICORE_BINDINGS` rows 210–211 | Provider build/advisory historical, authenticated runtime and benefit unmeasured |
| Networks and thin worker | LiveBus `191_V8_BRAIN_FEDERATION_ARCH` rows 2–7 | Architecture, not actual simultaneous worker admission |
| Resource authority and grants | LiveBus `21_COMPUTE_AUTHORITY_RECIPROCITY`, `111_GOVERNANCE_CONTRACT_V1` | Read rules are not bearer tokens |
| CAS/cold replay | LiveBus `110_DURABLE_JOB_CAS_V1` rows 2–5 | Exact effect semantics still need native task receipt |
| Typed synergy networks | LiveBus `168_V8_OPERATOR_SYNERGY_GRAPH` rows 2–7 | Candidate networks, not universal speedups |
| Compression, negation, avoided work | LiveBus `59_COGNITIVE_EFFICIENCY_BENCHMARK`, `79_WORK_ELIMINATION_BENCH` | Scoped A/B; some compression damages quality |
| Native neural/world model state | LiveBus `101_DEUS_NATIVE_BRAIN_V0` row 23, `204_V8_AUTONOMOUS_EVOLUTION_KERNEL` rows 2–8 | Own weights pilot and world prediction open |
| Owner website job continuity | LiveBus `11_ACTIVE_JOBS` row 2011, `WORKSPACE_CODEX_20261012` row 284 | Existing job, no new target ACK |

**PRIVATE SOURCE / UI MEMBRANE:** Canon `UI_SURFACE_CURRENT` forbids pulling private raw core into borrowed Chat to summarize. `R3` contains no original SFRET source, private BL weights, brain ABI/commands, secrets, provider endpoints or authenticated grants. Native current successor/source pins and implementation can only be bound inside an admitted owner-native executor.
