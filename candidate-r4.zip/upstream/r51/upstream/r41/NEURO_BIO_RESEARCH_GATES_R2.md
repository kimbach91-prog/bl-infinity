# DEUS-ONE R2 — connectomics, cognitive reflex and scientific brain/cell simulation gates

Source: `LiveBus:143_V7_OMNICORE_BINDINGS!A209:H212`, `LiveBus:101_DEUS_NATIVE_BRAIN_V0!A9:G11`, `LiveBus:44_1T_SUPERCELL_FABRIC!A1:H5`, historical owner Drive metadata for `DEUS-Connectomics-Audit-and-Adoption-v1.md`, `DEUS-F1-S2-Memory-Brain-Research-and-Benchmark-v2.md`, and `Ω-SUPERCELL — ORGANISM OS`. **These are source leads**, not proof of biological fidelity or a completed physical brain emulator.

## Existing DEUS architectural organs (distinct)

1. `CAP-BIO-REFLEX-001`: connectomics-inspired **sparse salience/reflex pre-router** for eligible S0/S1 events, source/provider build scoped; runtime authenticated canary, quality and performance remain unmeasured.
2. `CAP-NEURO-ORGANISM-DAEMON-001`: system **coordination** of World Tree cognition, reflex, organism/homeostasis and MicroNet work placement; host acceptance/useful job still has gates.
3. `Ω-Supercell/Bio-Cloud`: logical **state/resource** domains and homeostatic analogies, not actual biological cells or trillions of CPUs.
4. `DNB-03/DNB-21`: a separate DEUS neural microcore/weight pilot with multilingual transfer/semantic parity open. It is not a biophysically detailed brain simulation.

## Scientific levels: never collapse these together

- **N0 — design analogy:** connectome/organism-style graph of capabilities; no neuron or cell simulation.
- **N1 — synthetic discrete-event model:** finite threshold nodes, signed synapses, refractory delays, an energy budget and reproducible traces. R2 tests **only this level**.
- **N2 — calibrated neuromorphic model:** LIF/AdEx/Hodgkin-Huxley or synaptic-plasticity family with traceable biological parameters and independent held-out recordings. **NOT evidenced/admitted** in R2.
- **N3 — tissue/cellular simulation:** multi-compartment membranes, chemistry/metabolism, diffusion, gene/pathway or pharmacology, coupled space/time units with independent experimental validation. **NOT evidenced**.
- **N4 — cognitive transfer:** compare measured behavior on independent memory, prediction and planning tasks, with causal ablations against simpler symbolic state and existing DNB baseline. Do not infer consciousness or human brain equivalence.

## Functional experiment scaffold (N1)

`deus_one/neuro.py` simulates a bounded PUBLIC toy network with synchronous one-step propagation, inhibitory/excitatory signed edges, threshold, leak, refractory state, and energy consumption/recovery. Frames record spike counts, state, energy, and a synthetic overactivity alert. Inputs are finite integers, up to 16 nodes/128 edges/96 frames; no private signals, hardware control, gradient training or biological inference.

**Ablations and negative controls** to run against the same synthetic stimuli: remove inhibition vs add inhibition, remove refractory, change energy budget, changed source/state and replay trace tampering, spike storm, malformed weights, false OWNER_PRIVATE admission. The existing R2 tests exercise these within the public toy harness; no actual neuronal recording benchmark has been run.

**Next science work after approval:** select actual published data with rights and cell/synapse recordings, preregister task and comparative models, fit parameters only on training set, test held-out recordings, report spike timing/error/stability/metabolic proxy, run independent verifier and falsifiers, track exact artifacts and rollback. Before such acceptance, all "brain simulation" claims remain `UNVERIFIED_SCOPE` for scientific fidelity.
