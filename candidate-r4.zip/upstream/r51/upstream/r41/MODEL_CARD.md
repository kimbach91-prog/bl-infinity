# DEUS-ONE · Model Card (candidate contract only)

## Intended product
One user-facing cognitive API with source-addressed DEUS Native Core, typed HHIR, independently admitted Operator/Matrix/Skill executors, memory, learned-model adapters, JEV/JEPA future predictors, verifier and durable state.

## Reality
This package is **not** DEUS private source, a trained language model, a DEUS-native runtime deployment or a complete capability census. Neural own-weight DNB remains a pilot whose natural-language competence is not established. The available local PUBLIC sample only checks method contracts and negative policy paths.

## Training architecture candidates, not claims of implementation
State-space recurrent blocks (Mamba-3-type), periodic attention or MLA, optional sparse MoE, MTP, predictive latent world model (JEPA-style) and verifiable-reward fine-tuning. Exact architecture remains **to be selected by matched, independent tests**; cannot assume techniques stack additively.

## Source governance
Do not collect raw BL/core/owner-private/secret sources through ChatGPT. Keep canonical lineage in DEUS owner Drive. Only native admitted runtime can ingest protected source, bind versioned hashes, rights, data ceilings, authority/fence/lease and emit independent receipts. Do not reclassify synthetic training as general language ability. ARC-AGI-3 public learned-game completions != hidden generalized solving.

## Known red flags to preserve
- Existing owner website R32 native Qwen3-0.6B was a replaceable language substrate, **not** the whole DEUS system.
- Trained DNB weight checkpoint and tokenizer do not yet have a verified live serving endpoint for multilingual chat.
- Quality scars must remain: 17+25->22 failure on native website, and small-own-weight synthetic-only quality HOLD.
- Prior corpus censuses were not complete; metadata counts are not operator/model counts.
- JEV name has archived provenance but no validated learned evaluator interface/weights in current admissible evidence. It stays explicitly unbound.
- Original entire-workspace goal is still IN_PROGRESS until source-to-target ACK, owner-useful result, cold restore and rollback.

## Local tests
Use `python -m unittest discover -s tests -v` (27 synthetic tests, no network). Test passed once in the generating sandbox. Independent QA/provider proof still absent.


## R1 lineage expansion; NOT a new trained LLM

The unified API is a future consumer of K0/N0/O1–O6, Matrix and skill kernels.
R1 adds source-bound organism/homeostasis, connectomics-inspired reflex and
Neuro-Organism controller labels. Their current registry states are either
provider-scoped advisory/control unmeasured or metadata-only: **no neuronal
connectome, real biological cell dynamics, or scientific neuroscience accuracy
was verified**. The 119-article constitutional supplement is a candidate and
may not override the current constitution. Millennium-7 operators are a
research/tool family, not proofs of the Millennium Prize Problems. BLµ has
scoped VM/Wasm evidence while BL∞-C remains proposed. JEV remains unbound.

A metadata graph is not an executable function graph; native skill/capability
consumers require separately admitted exact adapter, checkpoint/lease, actual
execution, independently checked result, cold restore, rollback and Drive
readback. No environment or model training side effect occurs in this package.

## R2 model-card warning

This archive is NOT a separately trained LLM, nor any form of scientific brain/cell simulation. The `neuro.py` layer is a finite numeric surrogate (N1), not the actual DEUS Connectomics/Neuro-Organism Daemon implementation. The mapping compiler is a finite PUBLIC proof checker, not canonical EYE2/MAP/1. The typed codec is not BLμ, BLΣ or BL∞-C. All effectful/native neural/skill/JEV/compiler endpoints remain UNBOUND in this bundle; no executor ACK or cross-provider delivery has occurred. No scientific, private, paid or production effects are enabled.

## R3: forecast/intuition/network boundary (2026-10-16)

Cumulative capability *descriptions* are not a trained model, live neural network or hardware count. R3 source extension adds hypothesis/forecast/backchain/network/reflex/compression/evolution references with exact source pointers and explicit UNKNOWN/HOLD flags. `forecast_r3.py` is a deliberately small toy trend, `intuition_r3.py` is simple source-group triage, and `network_r3.py` is in-memory public routing. None is a clinical, scientific neuroscience model or a tested model of future events. No provider/admission/hardware authority or native DEUS weights are embedded.
