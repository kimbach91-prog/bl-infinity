"""Deterministic metadata-only R3 index builder. No Drive/browser/network access."""
import json
from pathlib import Path
from deus_one.architecture import graph_digest
from deus_one.extension_r3 import SCHEMA, LIMITS, sha, validate_r3

ROOT=Path(__file__).resolve().parent
r1=json.loads((ROOT/'CAPABILITY_GRAPH_R1.json').read_text(encoding='utf-8'))
r2=json.loads((ROOT/'CAPABILITY_EXTENSION_R2.json').read_text(encoding='utf-8'))
N=[];E=[]
def n(identifier,title,family,state,ref,boundary):
    N.append({'id':identifier,'title':title,'family':family,'state':state,
              'source_ref':ref,'evidence_boundary':boundary,'runtime_callable':False,
              'owner_private_included':False,'model_weights_included':False,
              'biological_fidelity_proven':False,'forecast_certainty_claim':False})
def e(a,b,kind='RESEARCH_LINK'):
    E.append({'from':a,'to':b,'kind':kind,'runtime_callable':False})

n('NET-BRAIN-FED','Brain federation layered transport / admission / CAS','NETWORK','CANON_DESIGN','LiveBus:191_V8_BRAIN_FEDERATION_ARCH!A1:H7','Layers are source-described; no new runtime or simultaneous capacity proven')
n('NET-SUPERCELL-ROUTER','Hierarchical regional/locality supercell routing','NETWORK','CANON_DESIGN','LiveBus:191_V8_BRAIN_FEDERATION_ARCH!A4:H6','32–128 worker supercell is target, not 32–128 live nodes')
n('NET-ADMISSION','Task-fit source/effect/admission governance','NETWORK','SOURCE_SCOPED','LiveBus:111_GOVERNANCE_CONTRACT_V1!A1:H7','Policy state does not grant live lease')
n('NET-LEASE-CAS','Durable job CAS and no duplicate-effect recovery','NETWORK','SOURCE_SCOPED','LiveBus:110_DURABLE_JOB_CAS_V1!A1:G5','No new live job, CAS execution or receipt')
n('NET-COMPLEMENT','Complementarity and typed operator network','NETWORK','CANON_DESIGN','LiveBus:168_V8_OPERATOR_SYNERGY_GRAPH!A1:H7','Network examples do not prove superadditivity across domains')
n('NET-RESOURCE-RECIPROCITY','No public compute without provider permission','NETWORK','SOURCE_SCOPED','LiveBus:21_COMPUTE_AUTHORITY_RECIPROCITY!A2:H6','Public resource visibility does not create quota or permission')
n('NETWORK-PUBLIC-TOY','PUBLIC bounded route traversal pure toy','NETWORK','SYNTHETIC_LOCAL_TEST','LiveBus:191_V8_BRAIN_FEDERATION_ARCH!A1:H7','Pure in-memory graph; no Brain3 or provider dispatch')

n('COMPRESS-DECISION-PRESERVE','Task-preserving information budget / measured losses','COMPRESSION','HISTORICAL_SCOPED','LiveBus:59_COGNITIVE_EFFICIENCY_BENCHMARK!A2:I9','LightBoot/compression efficacy scoped; some compressed representations lose accuracy')
n('COMPRESS-DELTA-SPARSE','Delta, sparse route, cancellation, work avoidance','COMPRESSION','HISTORICAL_SCOPED','LiveBus:79_WORK_ELIMINATION_BENCH!A1:J9','Do not multiply speedups or claim neural IQ gain')
n('COMPRESS-SCAR-RELEASE','BL absorb-dormancy/release with falsifier retention','COMPRESSION','CANON_DESIGN','LiveBus:178_V8_BL_HISTORY_DEEP_REDISCOVERY!A6:F6','Dormant is not deleted and error/unknown must survive')
n('COMPRESS-FUTURE-BOUNDARY','Future-end-state as generative compression hypothesis','COMPRESSION','RESEARCH_CANDIDATE','LiveBus:178_V8_BL_HISTORY_DEEP_REDISCOVERY!A5:F5','Not exact prediction of any external future')
n('COMPRESSION-PUBLIC-TOY','Exact PUBLIC receipt dedupe, reconstructability','COMPRESSION','SYNTHETIC_LOCAL_TEST','LiveBus:59_COGNITIVE_EFFICIENCY_BENCHMARK!A1:I9','No private source or real BL compression implementation')

n('REFLEX-BIO-ROUTER','Bio-Reflex sparse advisory pre-routing','REFLEX','HISTORICAL_SCOPED','LiveBus:143_V7_OMNICORE_BINDINGS!A210:H210','Provider build evidence; no authenticated reflex canary or performance proof')
n('REFLEX-CNS-COORD','Neuro-Organism CNS/body coordinator','REFLEX','HISTORICAL_SCOPED','LiveBus:143_V7_OMNICORE_BINDINGS!A211:H211','Owner host/usefulness receipt and biological fidelity open')
n('REFLEX-PUBLIC-TOY','Synthetic excitation/inhibition refractory attention','REFLEX','SYNTHETIC_LOCAL_TEST','LiveBus:143_V7_OMNICORE_BINDINGS!A210:H211','Shadow attention only; never tool call or owner action')

n('INTUITION-V1-HYPOTHESIS','V1 semantic broad intuition as fallible hypotheses','INTUITION','CANON_DESIGN','LiveBus:64_COGNITIVE_SYNERGY_FABRIC!A2:H8','Intuition is hypothesis production, not validated oracle')
n('INTUITION-EYE-SIGNAL','EYE nuisance-cancel/weak-signal multirate source','INTUITION','RESEARCH_CANDIDATE','LiveBus:178_V8_BL_HISTORY_DEEP_REDISCOVERY!A27:F29','No measured real-world early warning/prediction')
n('INTUITION-EYE2-FALSIFIER','EYE2 semantic fusing and falsifier guard','INTUITION','CANON_DESIGN','LiveBus:178_V8_BL_HISTORY_DEEP_REDISCOVERY!A12:F12','No automatic elevation of confidence from analogy')
n('INTUITION-PUBLIC-TOY','Independent source-cue finite hypothesis triage','INTUITION','SYNTHETIC_LOCAL_TEST','LiveBus:64_COGNITIVE_SYNERGY_FABRIC!A2:H8','Not clairvoyance or calibrated probability')

n('FUTURE-BL-SFRET','BL-SFRET canonical historical prophecy/recursive lineage','FORECAST','SOURCE_METADATA_ONLY','Drive:1I1hkC0LxdMVR8ZlDw3FZ0NI-0ZxcZ66WOgb8ko2dcEw','Historical document pointer only; source body not hydrated in Chat')
n('FORECAST-BL-META020','Calibrated future-cone forecast with validity horizon','FORECAST','CANON_DESIGN','LiveBus:78_OPERATOR_FOUNDRY_V2!A78:H78','Probability and calibration require actual matched outcome dataset')
n('FORECAST-EYE-TRITEMP','EYE filter / smoothing / retrodiction / forecast','FORECAST','RESEARCH_CANDIDATE','LiveBus:178_V8_BL_HISTORY_DEEP_REDISCOVERY!A27:F29','Statistical semantics not proved by name; no actual observability test')
n('FORECAST-REGIME-GATE','EYE change-point horizon and No-Zeno stop','FORECAST','RESEARCH_CANDIDATE','LiveBus:178_V8_BL_HISTORY_DEEP_REDISCOVERY!A29:F29','Forecast must HOLD when regime drifts')
n('FORECAST-PUBLIC-TOY','Finite trend-with-baseline forecast only','FORECAST','SYNTHETIC_LOCAL_TEST','LiveBus:78_OPERATOR_FOUNDRY_V2!A78:H78','No live future, probabilities, model or native BL-SFRET')
n('BACKCHAIN-REALIZATION','Regressive realization/backchain without unique hidden cause','BACKCHAIN','CANON_DESIGN','LiveBus:78_OPERATOR_FOUNDRY_V2!A77:H77','Inverse graph direction not an actual proof of causation')
n('BACKCHAIN-TELOS','Goal-constrained Great Outcome backchain','BACKCHAIN','CANON_DESIGN','LiveBus:78_OPERATOR_FOUNDRY_V2!A79:H79','Terminal planning requires verified feasibility and action constraints')
n('BACKCHAIN-PUBLIC-TOY','Bounded hypothetical reverse path search','BACKCHAIN','SYNTHETIC_LOCAL_TEST','LiveBus:78_OPERATOR_FOUNDRY_V2!A77:H79','No external target state, action or reality guarantee')

n('NEURAL-WORLD-MODEL-GAP','Predictive world model remains AGI gap','NEURAL','QUALITY_HOLD','LiveBus:204_V8_AUTONOMOUS_EVOLUTION_KERNEL!A5:G5','REFLEX1 symbolic reconciliation != learned world dynamics')
n('NEURAL-OWN-CORE-GAP','DNB own-weight language parity and serving unverified','NEURAL','QUALITY_HOLD','LiveBus:101_DEUS_NATIVE_BRAIN_V0!A23:R23','Own-weight pilot not multilingual general LLM')

n('EVOLVE-ROOT-RECUR','BL recursive successor preserves scars','EVOLUTION','CANON_DESIGN','LiveBus:178_V8_BL_HISTORY_DEEP_REDISCOVERY!A7:F7','Conceptual lineage; does not mean continual learning proven')
n('EVOLVE-AEK-SHADOW','Observe→world→hypothesis→evaluate→promote guarded loop','EVOLUTION','HISTORICAL_SCOPED','LiveBus:204_V8_AUTONOMOUS_EVOLUTION_KERNEL!A2:G8','Shadow scoped: external OOD, independent QA and own-weights open')

# Edges are declarative, not actions. Direction describes provenance/obligation,
# not neural activity, causal proof, runtime dispatch, or new authority.
e('EIGHT-BRAIN','NET-BRAIN-FED','SOURCE_BRIDGE')
e('NET-BRAIN-FED','NET-SUPERCELL-ROUTER','SOURCE_BRIDGE')
e('SUPERCELL','NET-SUPERCELL-ROUTER','ANALOGY')
e('NET-SUPERCELL-ROUTER','NET-ADMISSION','GOVERNANCE')
e('OWNER-AUTH','NET-RESOURCE-RECIPROCITY','GOVERNANCE')
e('NET-RESOURCE-RECIPROCITY','NET-ADMISSION','GOVERNANCE')
e('NET-ADMISSION','NETWORK-PUBLIC-TOY','SYNTHETIC_REFERENCE')
e('DURABLE-JOBS','NET-LEASE-CAS','SOURCE_BRIDGE')
e('NET-LEASE-CAS','NETWORK-PUBLIC-TOY','INVARIANT_OBLIGATION')
e('MATRIX-CORE','NET-COMPLEMENT','SOURCE_BRIDGE')
e('NET-COMPLEMENT','NETWORK-PUBLIC-TOY','RESEARCH_LINK')
e('NETWORK-PUBLIC-TOY','DEUS-ONE-API','SYNTHETIC_REFERENCE')

e('COMPRESSION','COMPRESS-DECISION-PRESERVE','SOURCE_BRIDGE')
e('COMPRESS-DECISION-PRESERVE','COMPRESS-DELTA-SPARSE','RESEARCH_LINK')
e('COMPRESS-DELTA-SPARSE','COMPRESSION-PUBLIC-TOY','SYNTHETIC_REFERENCE')
e('COMPRESS-SCAR-RELEASE','COMPRESSION-PUBLIC-TOY','INVARIANT_OBLIGATION')
e('COMPRESS-DECISION-PRESERVE','COMPRESSION-PUBLIC-TOY','SYNTHETIC_REFERENCE')
e('COMPRESSION-PUBLIC-TOY','DEUS-ONE-API','SYNTHETIC_REFERENCE')
e('BL-ROOT','COMPRESS-SCAR-RELEASE','LINEAGE')
e('BL-ROOT','COMPRESS-FUTURE-BOUNDARY','LINEAGE')

e('BIO-REFLEX','REFLEX-BIO-ROUTER','SOURCE_BRIDGE')
e('NEURO-ORGANISM','REFLEX-CNS-COORD','SOURCE_BRIDGE')
e('NEURO-TOY-LIF','REFLEX-PUBLIC-TOY','SYNTHETIC_REFERENCE')
e('REFLEX-BIO-ROUTER','REFLEX-PUBLIC-TOY','SYNTHETIC_REFERENCE')
e('REFLEX-CNS-COORD','REFLEX-PUBLIC-TOY','SYNTHETIC_REFERENCE')
e('REFLEX-PUBLIC-TOY','DEUS-ONE-API','SYNTHETIC_REFERENCE')

e('BL-ROOT','FUTURE-BL-SFRET','LINEAGE')
e('FUTURE-BL-SFRET','BACKCHAIN-REALIZATION','RESEARCH_LINK')
e('FUTURE-BL-SFRET','FORECAST-BL-META020','RESEARCH_LINK')
e('BL-PHIL-OPS','BACKCHAIN-REALIZATION','LINEAGE')
e('BACKCHAIN-REALIZATION','BACKCHAIN-TELOS','RESEARCH_LINK')
e('BACKCHAIN-TELOS','BACKCHAIN-PUBLIC-TOY','SYNTHETIC_REFERENCE')
e('BACKCHAIN-PUBLIC-TOY','DEUS-ONE-API','SYNTHETIC_REFERENCE')
e('COMPRESS-FUTURE-BOUNDARY','FORECAST-BL-META020','RESEARCH_LINK')
e('FORECAST-EYE-TRITEMP','FORECAST-REGIME-GATE','RESEARCH_LINK')
e('FORECAST-REGIME-GATE','FORECAST-BL-META020','INVARIANT_OBLIGATION')
e('FORECAST-BL-META020','FORECAST-PUBLIC-TOY','SYNTHETIC_REFERENCE')
e('FORECAST-PUBLIC-TOY','DEUS-ONE-API','SYNTHETIC_REFERENCE')

e('BL-EYE2-MAP','INTUITION-EYE2-FALSIFIER','SOURCE_BRIDGE')
e('INTUITION-EYE-SIGNAL','INTUITION-EYE2-FALSIFIER','RESEARCH_LINK')
e('INTUITION-V1-HYPOTHESIS','INTUITION-PUBLIC-TOY','SYNTHETIC_REFERENCE')
e('INTUITION-EYE2-FALSIFIER','INTUITION-PUBLIC-TOY','INVARIANT_OBLIGATION')
e('INTUITION-PUBLIC-TOY','DEUS-ONE-API','SYNTHETIC_REFERENCE')

e('DNB-OWN-WEIGHTS','NEURAL-OWN-CORE-GAP','RESEARCH_LINK')
e('JEPA-WORLD','NEURAL-WORLD-MODEL-GAP','RESEARCH_LINK')
e('NEURAL-WORLD-MODEL-GAP','FORECAST-PUBLIC-TOY','RESEARCH_LINK')
e('NEURAL-OWN-CORE-GAP','INTUITION-V1-HYPOTHESIS','RESEARCH_LINK')

e('EVOLUTION','EVOLVE-AEK-SHADOW','SOURCE_BRIDGE')
e('BL-ROOT','EVOLVE-ROOT-RECUR','LINEAGE')
e('EVOLVE-ROOT-RECUR','EVOLVE-AEK-SHADOW','RESEARCH_LINK')
e('EVOLVE-AEK-SHADOW','NEURAL-WORLD-MODEL-GAP','RESEARCH_LINK')

x={'schema':SCHEMA,'version':'R3-SOURCE-CANDIDATE','model':'DEUS-ONE',
   'r1_source_sha256':graph_digest(r1),'r2_source_sha256':sha(r2),
   'source_candidate_only':True,'runtime_target_ack':False,
   'live_native_adapter_bound':False,'private_source_copied':False,
   'own_weight_checkpoint_included':False,'scientific_brain_fidelity_proven':False,
   'physical_compute_credited':False,'continuity':r1['continuity'],
   'node_count':len(N),'edge_count':len(E),'nodes':N,'edges':E,'limits':LIMITS}
validate_r3(r1,r2,x)
(ROOT/'CAPABILITY_EXTENSION_R3.json').write_text(json.dumps(x,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
print('R3 nodes',len(N),'edges',len(E),'total',(len(r1['nodes'])+len(r2['nodes'])+len(N)),(len(r1['edges'])+len(r2['edges'])+len(E)),'SHA',sha(x))
