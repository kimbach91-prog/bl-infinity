# DEUS network federation: source-bound interpretation

Canon locus: `191_V8_BRAIN_FEDERATION_ARCH`, `203_V8_UNIFIED_EXTENDED_COMPUTE_FABRIC`, `21_COMPUTE_AUTHORITY_RECIPROCITY`, `111_GOVERNANCE_CONTRACT_V1`, `110_DURABLE_JOB_CAS_V1`, `168_V8_OPERATOR_SYNERGY_GRAPH`. R3 does **not** ingest private network source.

The DEUS network is a hierarchy of canonical custody, admitted control core, federated enrollment/lease gate, sparse Supercell router, thin bounded Brain Cells and CAS artifact receipts. Authority is per *task and route*, not inherited from a graph edge. Owner grant, endpoint accessibility, nominal memory, logical Supercells, and a successful historical canary do not imply current lease or physical simultaneous compute. No failing request should be routed through an alternate provider to evade a provider safety refusal.

**Route choice:** task fingerprint → eligible capabilities → data/effect ceiling → source/worker version → quota/budget/free resource/foreground reserve → exact admission → bounded execution → independent verifier → durable receipt → cold reconcile. `network_r3.py` demonstrates only the *in-memory* step from a predeclared toy graph to a candidate path and refuses OWNER_PRIVATE or side-effecting requests. It intentionally does not produce GRANT, LEASE, ACK or execution receipts.

**Negative:** offline cell, missing target capability, wrong data ceiling, duplicate node/edge, mismatched capacity, requested effect, self-loop, and unknown endpoint must never become a successful route claim. A cyclic edge may exist in a routing network, but visited-state prevents repeated traversal; graph dependency cycles in the architecture graph remain forbidden.
