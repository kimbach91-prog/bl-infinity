# DEUS-ONE R2 — Mapping / EYE2 / Φ–Ψ / cross-domain alignment

**Evidence level:** source-bound descriptive analysis + separately runnable finite PUBLIC surrogate. **Not** a read of protected core, *not* installation of `MAP/1`, not a general-purpose semantic mapping solver.

## Historical sources, in their own terminology

| Canon locator | Observed role and evidence | Boundary |
| --- | --- | --- |
| `LiveBus:178_V8_BL_HISTORY_DEEP_REDISCOVERY!A18:H18` | `MAP-001`: BL-MAP + EYE2 Φ/Ψ, commutation/inverse/noncollapse, translation loss | `PARTIAL_DORMANT`: concept and prior research, not current universal implementation |
| `LiveBus:181_V8_MAPPING_CONTEXT!A2:J2` | MAP Context task-fit workflow | `SESSION_SCOPED`; not account-wide interception |
| `LiveBus:181_V8_MAPPING_CONTEXT!A3:J3` | MAP/1 reversible structured codec; 288 exact roundtrips and 2,000 property cases | Restricted schemas; excludes arbitrary natural language semantics |
| `LiveBus:181_V8_MAPPING_CONTEXT!A4:J4` | Measured representation selector, raw fallback | No causal claim of inference quality or provider billing improvement |
| `LiveBus:181_V8_MAPPING_CONTEXT!A5:J5` | Native exact integer sum public Brain3 canary | 6 bounded exact tasks, no general solver license |
| `LiveBus:181_V8_MAPPING_CONTEXT!A6:J6` | Split/glue partition/result reconciliation with seam/conflict guard | No parallel hardware credit |
| `LiveBus:181_V8_MAPPING_CONTEXT!A7:J7` | Revision/authority-bound exact reuse and TTL | Cache does not authorize execution |
| `LiveBus:181_V8_MAPPING_CONTEXT!A8:J8` | Selected Python/JS/SQL lowering, guarded expected HOLD | Many other emitters not admitted |
| `LiveBus:181_V8_MAPPING_CONTEXT!A9:J10` | A/B quality HOLD and upstream synthetic reuse | No inference-quality lift claimed |
| `LiveBus:62_BL_INFINITY_LANGUAGE_FEDERATION!A14:H14` | BL-DATA-IR/1 typed exact carriers | Source role/codecs distinct from arbitrary BL language executors |

## Conceptual bridge and proof obligations

BL-MAP/EYE2 should preserve **source identity, validity domain, observable invariants, inverse/back-map where it exists, noncollapse of decision-different states, and compatibility with state transitions**. Formally, on a finite test domain, candidate forward map Φ and backward map Ψ must respect:

- **Roundtrip:** Ψ(Φ(x)) = x for all declared x, or an explicitly justified quotient with an admissible decision-equivalence relation.
- **Invariants:** I_source(x) = I_target(Φ(x)) for each protected typed invariant; no silent class/authority change.
- **Commutation:** Φ(T_source(x)) = T_target(Φ(x)) under exact transition laws.
- **Scars/UNKNOWN:** undecidable or unsupported translation stays HOLD; no fabricated confidence or default merge.
- **Cost gate:** include construction, transport, conversion, verification, caching invalidation and recovery; choose raw/native path when cheaper and equally correct.

### What R2 actually executes

`deus_one/mapping.py` validates a **finite declarative bijection** and its transition/invariant tables. It rejects noninjective merges, broken diagrams, missing states, tampered source pins and private data. This is **not** a reimplementation of BL-EYE2, `MAP/1`, or Brain3 installed mapping runtime. It is a conformance *reference* useful to bind a future admitted adapter and independent QA.

### Native adoption gate

Select an exact CURRENT mapping source, code bytes and version via owner-native collector; bind approved source classes and genuine MAP/1 handler; run frozen exact packets across JSON/JavaScript/Python/SQL with source-origin verifier, reversible cases, negative noncollapse/cross-domain faults, cold replays, invalidated cache and measured lifecycle cost; then target ACK and Drive readback.
