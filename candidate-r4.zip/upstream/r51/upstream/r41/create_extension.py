"""Deterministic PUBLIC metadata-only graph compiler. No private raw source reads."""
import json
from deus_one.architecture import graph_digest,validate_graph
from deus_one.extension import validate_extension,extension_summary
from pathlib import Path
ROOT=Path(__file__).resolve().parent
base=json.loads((ROOT/'CAPABILITY_GRAPH_R1.json').read_text())
validate_graph(base)
L='LiveBus:'
# tuple:id, title, family, state, source, evidence boundary
specs=[
('BL-EYE2-MAP','BL EYE2 two-way mapping and falsifier','MAPPING','RESEARCH_SCOPED',L+'178_V8_BL_HISTORY_DEEP_REDISCOVERY!A11:H18','EYE2 Φ/Ψ source lineage: abstract mapping, not current native executable ABI'),
('MAP-PHI-PSI','Forward/backward, no-collapse and commuting diagrams','MAPPING','SPEC_CANDIDATE',L+'178_V8_BL_HISTORY_DEEP_REDISCOVERY!A18:H18','Conceptual bounded semantic conversion; finite toy reference only'),
('MAP-CTX-CODEC','MAP/1 reversible data transport','MAPPING','HISTORICAL_SCOPED',L+'181_V8_MAPPING_CONTEXT!A3:J3','History: 288 roundtrip and 2000 property checks; not adopted here'),
('MAP-CTX-SELECTOR','Measured representation selector','MAPPING','HISTORICAL_SCOPED',L+'181_V8_MAPPING_CONTEXT!A4:J4','Quality/billing not globally measured, raw fallback retained'),
('MAP-CTX-SPLIT','Partition/seam conflict check','MAPPING','HISTORICAL_SCOPED',L+'181_V8_MAPPING_CONTEXT!A6:J6','Local verifier only, no parallel hardware claim'),
('MAP-CTX-CACHE','Revision and permission exact-reuse gate','MAPPING','HISTORICAL_SCOPED',L+'181_V8_MAPPING_CONTEXT!A7:J7','Cache metadata no credential or effect authorization'),
('MAP-CTX-BACKEND','Typed lowering and conversion receipts','MAPPING','HISTORICAL_SCOPED',L+'181_V8_MAPPING_CONTEXT!A8:J8','Python/JS/SQL are scoped, other backends not endorsed'),
('MAP-COMMUTE-GATE','Invariant, inverse, noncollapse and commutation','MAPPING','SPEC_CANDIDATE',L+'178_V8_BL_HISTORY_DEEP_REDISCOVERY!A18:H18','No source runtime mapping applied; preserve translation-loss and counterexamples'),
('MAP-FINITE-REFERENCE','Toy finite mapping proof checker','MAPPING','SYNTHETIC_LOCAL_TEST',L+'181_V8_MAPPING_CONTEXT!A2:J10','PUBLIC source-bound reference code R2; not MAP/1 implementation'),
('MAP-BL-XFT','BL cross-family transfer/gamete evidence','MAPPING','RESEARCH_SCOPED',L+'178_V8_BL_HISTORY_DEEP_REDISCOVERY!A21:H35','Synthetic scoped transfer evidence only; no universal transfer'),
('LANG-DIC1','Intent typed front door','LANGUAGE','HISTORICAL_SCOPED',L+'62_BL_INFINITY_LANGUAGE_FEDERATION!A2:H2','Adjacent bounded natural-command success; not actual compiled DIC runtime'),
('LANG-BLSIGMA','Reversible representation/codec family','LANGUAGE','HISTORICAL_SCOPED',L+'62_BL_INFINITY_LANGUAGE_FEDERATION!A4:H4','Codec source observed, no general cognition gain'),
('LANG-BLMUOS','BLmu effect/capability boundary','LANGUAGE','HISTORICAL_SCOPED',L+'62_BL_INFINITY_LANGUAGE_FEDERATION!A5:H5','Authority is inherited from admitted controller, never minted'),
('LANG-BLFABRIC','Graph/dataflow federation','LANGUAGE','HISTORICAL_SCOPED',L+'62_BL_INFINITY_LANGUAGE_FEDERATION!A6:H6','Only synthetic graph evidence on cited audit'),
('LANG-ATOMDEFECT','Heterogeneous multi-semantic selector','LANGUAGE','RESEARCH_SCOPED',L+'62_BL_INFINITY_LANGUAGE_FEDERATION!A7:H7','Synthetic boolean/analog/timing tests; not semantic language parity'),
('LANG-SEMIR','BL typed SSA/effect/provenance IR','LANGUAGE','SPEC_CANDIDATE',L+'62_BL_INFINITY_LANGUAGE_FEDERATION!A8:H8','Targets mature backends, no global compiler deployment'),
('LANG-BLX','BLX higher lineage','LANGUAGE','UNVERIFIED_SCOPE',L+'62_BL_INFINITY_LANGUAGE_FEDERATION!A10:H10','Higher lineage semantics direct source gap'),
('LANG-BACKEND-PORTS','LLVM/MLIR/Wasm/StableHLO/GPU target family','LANGUAGE','SPEC_CANDIDATE',L+'62_BL_INFINITY_LANGUAGE_FEDERATION!A11:H11','BLmu Wasm scoped; other target backend deployment unverified'),
('LANG-SELF-REWRITE','Bounded reprogram of task-local plan','LANGUAGE','SPEC_CANDIDATE',L+'62_BL_INFINITY_LANGUAGE_FEDERATION!A12:H12','No kernel self-rewrite/no owner privilege escalation'),
('LANG-DATAIR','Exact typed JSON/MAP1/SQL/Sexpr carrier','LANGUAGE','HISTORICAL_SCOPED',L+'62_BL_INFINITY_LANGUAGE_FEDERATION!A14:H14','Only records exact conversion, arbitrary programs excluded'),
('LANG-PACKET-REFERENCE','Toy typed packet two-envelope verifier','LANGUAGE','SYNTHETIC_LOCAL_TEST',L+'62_BL_INFINITY_LANGUAGE_FEDERATION!A14:H14','PUBLIC codec toy with role/effect/source lock; not BL compiler'),
('NEURO-SYNAPSE-REF','Connectomics-inspired salience signals','NEURO','HISTORICAL_SCOPED',L+'143_V7_OMNICORE_BINDINGS!A210:H210','Advisory source/build receipt, real authenticated reflex outcome unmeasured'),
('NEURO-DAEMON-REF','Neuro-organism control source route','NEURO','HISTORICAL_SCOPED',L+'143_V7_OMNICORE_BINDINGS!A211:H211','Host/control consumer and performance unverified'),
('NEURO-EVENT-MEM','Episodic-salience procedural memory relation','NEURO','SPEC_CANDIDATE',L+'101_DEUS_NATIVE_BRAIN_V0!A10:G11','Separate episodic/semantic/scar memory; no biological equivalence'),
('NEURO-REFRACTORY','Refractory and inhibition surrogate contract','NEURO','SPEC_CANDIDATE',L+'143_V7_OMNICORE_BINDINGS!A210:H211','Only candidate analogy, not exact original DEUS neuro code'),
('NEURO-HOMEOSTASIS','Toy local energy reserve and activity cap','NEURO','SPEC_CANDIDATE',L+'143_V7_OMNICORE_BINDINGS!A210:H211','Toy numeric energy != metabolism or model homeostasis'),
('NEURO-TOY-LIF','Bounded synthetic threshold / refractory network','NEURO','SYNTHETIC_LOCAL_TEST',L+'143_V7_OMNICORE_BINDINGS!A210:H211','Public discrete deterministic local test, no live daemon/real brain'),
('CELL-HOMEOSTASIS-SYNTH','Toy cell-state energy budgeting','CELL','SYNTHETIC_LOCAL_TEST',L+'44_1T_SUPERCELL_FABRIC!A1:H5','Synthetic resource lane only; no actual biological cells'),
('NEURO-SCIENCE-GATE','Scientific falsifiability & observation gate','NEURO','SPEC_CANDIDATE',L+'143_V7_OMNICORE_BINDINGS!A210:H211','No anatomy/electrophysiology ground truth; cannot claim brain simulation'),
]
nodes=[dict(id=id,title=title,family=family,state=state,source_ref=source,
            evidence_boundary=boundary,admitted=False,private_bytes_included=False,
            model_weights_included=False,biological_fidelity_proven=False)
       for id,title,family,state,source,boundary in specs]
# Existing graph edges stay unchanged. New edge declarations are inert source lineage.
def edge(frm,to,kind):return {'from':frm,'to':to,'kind':kind,'runtime_callable':False}
relations=[
('BL-ROOT','BL-EYE2-MAP','LINEAGE'),('BL-EYE2-MAP','MAP-PHI-PSI','RESEARCH_LINK'),
('MAP-PHI-PSI','MAP-COMMUTE-GATE','INVARIANT_OBLIGATION'),
('MAP-COMMUTE-GATE','MAP-FINITE-REFERENCE','SYNTHETIC_REFERENCE'),
('MAP-PHI-PSI','MAP-CTX-CODEC','SOURCE_BRIDGE'),
('MAP-CTX-CODEC','MAP-CTX-SELECTOR','SOURCE_BRIDGE'),
('MAP-CTX-SELECTOR','MAP-CTX-SPLIT','SOURCE_BRIDGE'),
('MAP-CTX-SPLIT','MAP-CTX-CACHE','SOURCE_BRIDGE'),
('MAP-CTX-CACHE','MAP-CTX-BACKEND','SOURCE_BRIDGE'),
('BL-ROOT','MAP-BL-XFT','LINEAGE'),
('MAP-BL-XFT','MAP-PHI-PSI','RESEARCH_LINK'),
('N0-HHIR','LANG-DIC1','SOURCE_BRIDGE'),
('N0-HHIR','LANG-SEMIR','SOURCE_BRIDGE'),
('BLMU','LANG-BLMUOS','SOURCE_BRIDGE'),
('BLMU','LANG-BLSIGMA','SOURCE_BRIDGE'),
('LANG-DIC1','LANG-DATAIR','SOURCE_BRIDGE'),
('LANG-BLSIGMA','LANG-DATAIR','SOURCE_BRIDGE'),
('LANG-DATAIR','LANG-PACKET-REFERENCE','SYNTHETIC_REFERENCE'),
('LANG-DATAIR','LANG-SEMIR','SOURCE_BRIDGE'),
('LANG-BLMUOS','LANG-SEMIR','GOVERNANCE'),
('LANG-ATOMDEFECT','LANG-BLFABRIC','SOURCE_BRIDGE'),
('LANG-BLFABRIC','LANG-SEMIR','SOURCE_BRIDGE'),
('LANG-SEMIR','LANG-BACKEND-PORTS','SOURCE_BRIDGE'),
('LANG-SEMIR','LANG-SELF-REWRITE','RESEARCH_LINK'),
('LANG-SELF-REWRITE','DEUS-ONE-API','INVARIANT_OBLIGATION'),
('LANG-BLX','LANG-SEMIR','RESEARCH_LINK'),
('LANG-BACKEND-PORTS','DEUS-ONE-API','SOURCE_BRIDGE'),
('MAP-CTX-BACKEND','LANG-DATAIR','SOURCE_BRIDGE'),
('CONNECTOMICS','NEURO-SYNAPSE-REF','ANALOGY'),
('NEURO-SYNAPSE-REF','NEURO-REFRACTORY','RESEARCH_LINK'),
('NEURO-REFRACTORY','NEURO-TOY-LIF','SYNTHETIC_REFERENCE'),
('NEURO-TOY-LIF','NEURO-HOMEOSTASIS','SYNTHETIC_REFERENCE'),
('NEURO-HOMEOSTASIS','NEURO-EVENT-MEM','RESEARCH_LINK'),
('NEURO-EVENT-MEM','NEURO-DAEMON-REF','RESEARCH_LINK'),
('NEURO-DAEMON-REF','NEURO-ORGANISM','SOURCE_BRIDGE'),
('BIO-CLOUD','CELL-HOMEOSTASIS-SYNTH','ANALOGY'),
('CELL-HOMEOSTASIS-SYNTH','BIO-CELL-SIM','RESEARCH_LINK'),
('NEURO-TOY-LIF','NEURO-SCIENCE-GATE','INVARIANT_OBLIGATION'),
('NEURO-SCIENCE-GATE','BIO-BRAIN-SIM','RESEARCH_LINK'),
('MAP-FINITE-REFERENCE','DEUS-ONE-API','SYNTHETIC_REFERENCE'),
('LANG-PACKET-REFERENCE','DEUS-ONE-API','SYNTHETIC_REFERENCE'),
('NEURO-TOY-LIF','DEUS-ONE-API','SYNTHETIC_REFERENCE'),
]
ext={'schema':'deus-one-source-extension-r2/1','version':'R2-SOURCE-CANDIDATE',
     'base_model':'DEUS-ONE','base_graph_sha256':graph_digest(base),
     'source_candidate_only':True,'runtime_ack':False,
     'native_adapter_admission':False,'training_checkpoint_included':False,
     'scientific_neural_fidelity':False,'effect_count':0,'nodes':nodes,
     'edges':[edge(*e) for e in relations],
     'node_count':len(nodes),'edge_count':len(relations),
     'continuity':base['continuity'],
     'limits':{'new_neural_weights':'NONE','new_private_source':'NONE',
               'neuro_role':'SYNTHETIC_REFERENCE_ONLY',
               'language_role':'PUBLIC_STRUCTURAL_REFERENCE_ONLY',
               'mapping_role':'FINITE_PUBLIC_PROOF_ONLY',
               'official_arc_score':'NOT_CLAIMED'}}
validate_extension(base,ext)
(ROOT/'CAPABILITY_EXTENSION_R2.json').write_text(json.dumps(ext,ensure_ascii=False,
  sort_keys=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps(extension_summary(base,ext),ensure_ascii=False,indent=2))
