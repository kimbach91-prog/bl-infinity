# DEUS-ONE / R4 continuation

The existing R1, R2 and R3 packages are copied intact as baseline input and code; R4 is an additive historical hyperconnection/search census and PUBLIC synthetic contract increment.

Run after unzipping in this directory:

    python -m unittest discover -s tests -q
    python -m deus_one.pipeline_r4
    python verify_r4.py

All tests are synthetic or on immutable public examples. Nothing modifies the DEUS website or Brain services. The private owner-driven source index and real capability adapter are *not* contained in this ZIP. See DELTA_R3_TO_R4.md, SEARCH_SUPERMAPPING_CENSUS_R4.json and MODEL_CARD_R4.md.
