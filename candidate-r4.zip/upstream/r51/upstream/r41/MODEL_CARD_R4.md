# DEUS-ONE R4 — model/system extension card

**Claim:** public bounded source-candidate graph, contracts and locally executable **synthetic reference tests**. Not an AI foundation-model checkpoint, physical hyperdimensional compute system, complete BL∞ original-corpus recovery, any native XSearch invocation, or production integration.

**Inherited scope:** R1 BL/native source graph, R2 mapping/language/neuro toy, R3 federation/reflex/forecast/compression toy. They remain distinct and testable. R4 adds multiary hypergraph, six-axis reversible mapping, multidimensional resource fit, metadata search, provenance dedupe and explicit corpus gaps. No previous FAIL/UNKNOWN evidence is erased.

**Do not infer:** 1T logical Supercells = 1T machines, 6D representation = six physical dimensions, 643 review leads = 643 missing native kernels, returned Drive aliases = independent evidence, a Graph path = a network/permission grant, a deployed advisory CNS = scientifically validated brain simulation, a good source audit = an LLM trained checkpoint.

**Privacy:** tests use PUBLIC synthetic fixtures; no Bách OWNER_PRIVATE source, personnel, Cường/PHD source, credentials or copied proprietary core in package. No runtime or cost effect.

**Promotion:** blocked until exact source/rights/current successor, actual provider-native admission, independent verifier receipt, measured owner-useful task and rollback/readback. No developer can self-mint controller authority by modifying the candidate graph.
