# BL-SFRET, Grand Ending, EYE and regression — four distinct semantics

Grounded source pointers only: `Drive:1I1hkC0LxdMVR8ZlDw3FZ0NI-0ZxcZ66WOgb8ko2dcEw` (historical BL-SFRET title/metadata); `178_V8_BL_HISTORY_DEEP_REDISCOVERY` rows 5, 11–12, 27–29; `78_OPERATOR_FOUNDRY_V2` rows 77–79. Full private SFRET body was **not** inspected in this Chat; the operational associations below are those qualified in the descriptive registry, not a reconstruction of private source.

1. **Intuition / hypothesis generation:** propose possible explanations quickly from weak or complementary signals. Hypotheses are set-valued and falsifiable; independent source groups matter; no certainty is gained by a name such as "siêu trực giác".
2. **Forecast / future cone:** estimate bounded possible futures under *known observation cutoff, model, horizon, calibration and drift monitor*. When a regime changes, HOLD or return unverified scenarios. Do not assert access to future observations.
3. **Retrodiction / regression:** invert *hypothetical* event chains backward from an observed state or candidate mechanism; underdetermination means multiple histories may explain the same observation. A reverse graph path is not proof of unique history.
4. **Great Outcome / goal backchain:** search backward from a declared target to currently actionable preconditions and forward-check resource/permission/feasibility. End-state is an objective, not an oracle.

The local `forecast_r3.py` holds if a bounded trend fails a last-step check or loses to persistence, and rejects future-dated input. The graph backchain is a *toy* path, with no claim of real causality or action. Independent native forecast model calibration and held-out outcome verification remain OPEN.
