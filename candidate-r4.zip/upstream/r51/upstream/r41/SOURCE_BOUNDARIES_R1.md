# R1 source classification and unclosed integration gates

- **Current constitution versus candidate:** only Drive CURRENT/owner-approved
  law binds. The 119-article v3.0 document is a candidate, not an installed
  overwrite. No derived source may widen actor grants.
- **BL mathematical/operator versus open theorem:** seven-Millennium interlock
  has named research/operator contracts. Do not assert proofs for unsolved
  Millennium Prize problems.
- **Programming languages:** BLµ has scoped parser/VM/Wasm benchmark;
  BL∞-C is a proposed cognitive DSL. Do not claim LLVM/StableHLO production.
- **Biomimetic versus bioscientific:** logical Supercells, Organism OS,
  Bio-Reflex and Neuro-Organism Daemon borrow ideas from living systems.
  These facts are not laboratory-valid cell physiology or connectome-scale
  simulation. Registry reports Bio-Reflex as deployed advisory/unmeasured,
  Neuro-Organism control deployed but owner internal daemon host pending.
- **Neural source versus trained model:** DNB owns a pilot checkpoint;
  strong multilingual instruction and independent serving are still open.
  JEV is a historical name with no admitted learned API. JEPA is separate.
- **Skills:** current descriptive registry 36 anchors does not close source
  census, automatically bind all skill executors or replace native authority.
- **Source custody:** owner-private code, BL raw details, private prompts and
  credentials are never bundled. Drive is canon; GitHub is code when pinned;
  only target receipts prove actual runtime changes.
- **Promotion and rollback:** no row in this package can self-promote to
  CURRENT or VERIFIED_DONE. Same-job admission/ACK, independent negative,
  replay, cold restore, rollback and readback gates remain mandatory.
- **August–October completeness:** this R1 is a bounded, expandable
  integration map, not an exhaustive archive/census. Historical failures
  are not overwritten by later versions.
