# DEUS-ONE R4 / bounded historical super-search and hyperconnection

This is an extension of the **same** DEUS-ONE R1–R3 PUBLIC source candidate, **not** a second kernel, training run, or native deployment.

## New registered branches

- **BL∞ HyperWeave 6D / evolutionary causal 3D / MMX12 / ATOM–DEFECT**: provenance-bound research candidates and heterogeneous typed representation. Physical dimensions, model hidden dimensions, state-space axes and distributed device count are different units. Do not multiply them.
- **Multiary capability connections**: one task may require several nodes and six exact semantic facets simultaneously. Synthetic bounded hypergraph witness rejects disconnected paths, mismatched axis, private/effect metadata and synthetic-to-live rights escalation. It is not a proof of superlinear intelligence.
- **Multidimensional capacity**: CPU, RAM, VRAM, disk, NIC and I/O are each independent constraints. A candidate node is eligible only when that same node satisfies all six axes plus latency/budget/health. No summing incompatible disjoint machines. Real distributed decomposition separately requires data-movement, sharding, lease and independent final verifier.
- **Hyper-mapping Φ/Ψ**: bounded six-axis reversible transformation and commuting witness with noncollapse; these are finite synthetic mathematical checks, not original private EYE2 or whole-language compiler.
- **Super-search and source-memory**: metadata-only exact/alias lookups, F00 gaps, source lineage grouping and a fail-closed completeness report. Mirrors in Drive/LiveBus do not count as independent sources. This demonstration does NOT invoke the DEUS SearchCell/XSearch native engine.

## Historical audit — what was missing or unknown

The 8 October owner Power census found 1,261 Drive file identities, 318 metadata tab refs, 37 taxonomy families and **643 unclassified or principal-review leads**. Its own report explicitly says private bodies, August source completeness, native atom denominator, and task-fit dispatch were not closed. New metadata queries cover specific BL∞/HyperWeave6D, MMX12, World Tree, XSearch/Gamete, EYE2, Noetic, Audio/Voice, defense, native code paths and R3 deltas. A bounded source-date-filtered August metadata query returned 12 titles across two pages; that is **NOT all August documents** nor an original-source audit. Metadata date after import may differ from creation of the underlying concept.

Potentially underrepresented R3 families remain Noetic Wildforest, Ω-Voice and multimodal, defensive atlas, provider-economics, DiGe visual, alias **kiếm trí tuệ** and cross-project prohibitions. R4 adds metadata/source candidate links but does not absorb private contents or claim practical acceptance. The unclassified review population and later deltas remain **OPEN/UNKNOWN**.

## Implemented PUBLIC test modules

`deus_one/hypergraph_r4.py`, `resources_r4.py`, `supermapping_r4.py`, `supersearch_r4.py`, `extension_r4.py`, `pipeline_r4.py`. Original R1–R3 modules and tests remain. Each new handler is inert and bounded; no IO, network, browser, provider model, billing, private corpus, controller, or Brain dispatch.

`CAPABILITY_EXTENSION_R4.json` pins predecessor R1/R2/R3 hashes and emits only descriptive nodes/edges. `SEARCH_SUPERMAPPING_CENSUS_R4.json` records scope, method, discovered safe metadata leads and open gaps. A live native collector may use these as an approved *pointer input*, not authorization.

## What constitutes real integration

Native owner-controlled collector must (1) read CURRENT/approved sources inside native custody and close exact scoped census denominator; (2) resolve stable family/current successor, accurate version/hash and independent tests; (3) bind a task-fit admitted multi-node or search adapter with principal, data class, grant, expiry, lease/fence, quotas; (4) execute a useful job, obtain target ACK and independent oracle, compare direct versus combined true full-cost benchmarks; (5) confirm negative, same-job interrupted resume, no duplicate effect, rollback, and Drive readback. Without these gates this is **SOURCE_CANDIDATE ONLY**.
