"""R4 bounded public source-name graph builder. NO owner-private raw source reads."""
from pathlib import Path
import json
from deus_one.architecture import graph_digest
from deus_one.extension_r3 import sha
from deus_one.extension_r4 import SCHEMA,LIMITS,validate_r4
P=Path(__file__).resolve().parent
r1=json.loads((P/'CAPABILITY_GRAPH_R1.json').read_text())
r2=json.loads((P/'CAPABILITY_EXTENSION_R2.json').read_text())
r3=json.loads((P/'CAPABILITY_EXTENSION_R3.json').read_text())
N=[];E=[]
def n(ident,title,family,state,ref,bound):
    N.append({'id':ident,'title':title,'family':family,'state':state,
        'source_ref':ref,'evidence_boundary':bound,
        'runtime_callable':False,'private_bytes_included':False,
        'physical_credit':False,'whole_corpus_verified':False})
def e(a,b,k='RESEARCH_LINK'):
    E.append({'from':a,'to':b,'kind':k,'runtime_callable':False})

n('HYPERWEAVE-6D','BL∞ HyperWeave 6D multi-membrane representational compression','HYPERDIMENSION','SOURCE_METADATA_ONLY','Drive:1dSm1CGg-PCG9FwKTNWzdHw1nRy35s91bQfApgSCh5PE','The six dimensions are lineage terminology; no physical six-dimensional computer verified')
n('HYPER-BL-CAUSAL3D','BL evolutionary 3D causal fabric and multiple views','HYPERDIMENSION','SOURCE_METADATA_ONLY','Drive:1dSd8xksDe3-pr_rLYypoIRwLEWPoqAQ9','Title-scoped historical lead; no adopted multiaxis runtime proven')
n('HYPER-MMX12','MMX12 × BL∞ multilevel composition and reuse','HYPERDIMENSION','SOURCE_METADATA_ONLY','Drive:16p3T3cYMvdtx5kxAZAet1M9yqpDkaMWErgu9Ra3GWDA','No multiplication of independent benchmark speedups or new compute capacity')
n('HYPER-ATOMDEFECT','ATOM–DEFECT heterogeneous semantics and mixed lanes','HYPERDIMENSION','HISTORICAL_SCOPED','LiveBus:62_BL_INFINITY_LANGUAGE_FEDERATION!A7:H8','Synthetic mixed semantic trials, not full native compiler installation')
n('HYPER-BLSEMIR','Typed HHIR semantic/mathematical multi-axis computation','HYPERDIMENSION','CANON_DESIGN','LiveBus:62_BL_INFINITY_LANGUAGE_FEDERATION!A7:H14','Differentiates dimensions of representation from distributed physical hosts')
n('HYPER-PHI-PSI','BL EYE2 Φ/Ψ and noncollapse cross-domain mapping','MAPPING','HISTORICAL_SCOPED','LiveBus:178_V8_BL_HISTORY_DEEP_REDISCOVERY!A12:F18','Mapping inverse, commutation and translation-loss obligations must be measured')
n('HYPER-DIGEREFERENCE','DiGe C38 multi-system representation and body reference','MAPPING','SOURCE_METADATA_ONLY','LiveBus:70_DIGE_C38_MULTI_SYSTEM_REFERENCE!A1:H8','Distinct creative/physical-visual domain; not native DEUS general reasoning proof')
n('HYPER-MAPPING-CONTEXT','Versioned MAP/1 selector, split/glue and exact islands','MAPPING','HISTORICAL_SCOPED','LiveBus:181_V8_MAPPING_CONTEXT!A1:J9','Source-context transport remains bounded; prior 1/6 paired AI A/B held')
n('HYPERGRAPH-SYNERGY','Operator hyper-composition from typed supporting subgraphs','HYPERDIMENSION','CANON_DESIGN','LiveBus:168_V8_OPERATOR_SYNERGY_GRAPH!A1:H9','Ordinary DAG proofs do not automatically prove true hyperedge synergy')
n('HYPERGRAPH-NETBENCH','Nonterminal enablers and matched operator network benchmarks','HYPERDIMENSION','HISTORICAL_SCOPED','LiveBus:169_V8_OPERATOR_NETWORK_BENCH!A1:H8','Each network has own baseline, cost and negative; no global benefit claimed')
n('HYPERGRAPH-PUBLIC-TOY','PUBLIC finite multiary six-axis hyperrelation contract test','HYPERDIMENSION','SYNTHETIC_LOCAL_TEST','LiveBus:168_V8_OPERATOR_SYNERGY_GRAPH!A1:H9','Synthetic witness only; no native hypergraph executable or physical dimensional credit')

n('MULTINODE-BRAIN-FED','Brain Federation control/transport/admission/worker layers','MULTINODE','CANON_DESIGN','LiveBus:191_V8_BRAIN_FEDERATION_ARCH!A1:H9','Separate logical topology, execution permission and actual availability')
n('MULTINODE-SHARDMAP','Brain shard hashing and migration with collision preservation','MULTINODE','HISTORICAL_SCOPED','LiveBus:200_V8_BRAIN_SHARD_MAP!A1:H6','SYNTHETIC shard distribution does not establish real physical nodes')
n('MULTINODE-SUPERCELL','Supercell worker groups, target/max versus actual membership','MULTINODE','CANON_DESIGN','LiveBus:197_V8_BRAIN_SUPERCELL_REGISTRY!A1:H6','Target 32–128 members is not proof of 128 live accepted workers')
n('MULTINODE-LEASE','Task-specific lease/fence/current resource attribution','MULTINODE','CANON_DESIGN','LiveBus:198_V8_BRAIN_LEASE_CURRENT!A1:H3','Fresh owner task-fit lease still required; no implicit inherited permission')
n('MULTINODE-SCALED-QUOTA','Multidimensional resource vector without invalid summation','MULTINODE','CANON_DESIGN','LiveBus:38_UNIFIED_RESOURCE_KERNEL!A1:H7','Logical vCPU/RAM envelopes cannot be added as one simultaneous physical machine')
n('MULTINODE-PROVIDER-RECIP','Reciprocity and permission/non-intrusive separation','MULTINODE','CANON_DESIGN','LiveBus:21_COMPUTE_AUTHORITY_RECIPROCITY!A1:H6','No free compute from unapproved transport or merely public reachability')
n('MULTIRESOURCE-PUBLIC-TOY','PUBLIC CPU/RAM/VRAM/DISK/NIC/IO task placement toy','MULTINODE','SYNTHETIC_LOCAL_TEST','LiveBus:38_UNIFIED_RESOURCE_KERNEL!A1:H7','One-host fit only, no provider data, quota or live lease')

n('SEARCH-FEDERATION','Search Federation and independent surface source routing','SEARCH','CANON_DESIGN','LiveBus:138_V7_SEARCH_KERNEL!A1:H10','Search discovery alone is not source proof or permission')
n('SEARCH-WORLDTREE','World Tree systems search orchestration branch','SEARCH','SOURCE_METADATA_ONLY','Drive:16gdXoxHZ-sweygPfmoemHZn3oGfmj6-8Ta_T0iq8iNA','Source title may describe search engine; no current native API bound')
n('SEARCH-XGAMETE','XSearch/Gamete stable cross-domain discovery rules','SEARCH','SOURCE_METADATA_ONLY','Drive:1u-1vB-p9fSI_juquxTV7Crp6VLzdD1zp','Historical metadata rules, not executed here')
n('SEARCH-UMS','Unified Memory Search and exact/version recall','SEARCH','CANON_DESIGN','LiveBus:138_V7_SEARCH_KERNEL!A2:H10','Need real retrieval evaluations on approved corpus')
n('SEARCH-RECOVERY','Search Recovery from stale roots and missing-current versions','SEARCH','CANON_DESIGN','LiveBus:138_V7_SEARCH_KERNEL!A2:H10','Do not infer CURRENT from latest numeric version')
n('SEARCH-EYE2-FALSE','EYE2 falsifier and semantic firewall in search','SEARCH','CANON_DESIGN','LiveBus:138_V7_SEARCH_KERNEL!A2:H10','Correlated aliases can create false independent evidence')
n('SEARCH-METADATA-PUBLIC-TOY','PUBLIC metadata-only index and source lineage triangulation','SEARCH','SYNTHETIC_LOCAL_TEST','LiveBus:POWER_SOURCES_R1_20261008!A1:E5','In-memory test does not call DEUS native XSearch or scan entire Drive')

n('COMP-HYPERWEAVE-LOSS','HyperWeave compression must preserve decidable distinctions','COMPRESSION','SOURCE_METADATA_ONLY','Drive:1dSm1CGg-PCG9FwKTNWzdHw1nRy35s91bQfApgSCh5PE','Do not infer compression accuracy without source-bound decision oracle')
n('COMP-REUSE-NET','Exact cache/cancel/locality/delta multi-operator network','COMPRESSION','HISTORICAL_SCOPED','LiveBus:168_V8_OPERATOR_SYNERGY_GRAPH!A2:H9','Network speedups and compression ratios are not multiplicative')
n('COMP-OBJECT-NEGATIVE','Object graph compression hurts same-model ARC A/B','COMPRESSION','HISTORICAL_SCOPED','LiveBus:59_COGNITIVE_EFFICIENCY_BENCHMARK!A5:I8','Keep result 2/8 raw versus 1/8 compressed; reject as default')
n('COMP-LOCAL-WORK','Work avoided and communication-bound load placement','COMPRESSION','HISTORICAL_SCOPED','LiveBus:79_WORK_ELIMINATION_BENCH!A1:J9','Count avoided operations only when valid outputs and activation overhead match')

n('AUDIT-POWER-20261008','Aug25→Oct08 source power census metadata and gap states','AUDIT','HISTORICAL_SCOPED','LiveBus:POWER_AUDIT_R1_20261008!A1:D15','1261 Drive files and 318 tab refs metadata only, not native corpus count')
n('AUDIT-CLASS-37','Thirty-seven broad source family classifications incl F00','AUDIT','HISTORICAL_SCOPED','LiveBus:POWER_FAMILIES_R1_20261008!A1:E38','Overlap counts cannot add to total capabilities or admitted adapters')
n('AUDIT-NATIVE-DENOM','Native source count, revisions and private corpus not closed','SOURCE_GAP','SOURCE_GAP','LiveBus:POWER_GATES_R1_20261008!A1:H8','Requires admitted native source collector to close full denominator')
n('AUDIT-F00-643','643 historical unclassified/principal-review source leads','SOURCE_GAP','SOURCE_GAP','LiveBus:POWER_AUDIT_R1_20261008!A9:D15','Names/metadata cannot prove absence; keep F00 and distinct principal review')
n('AUDIT-AUG-ORIG','August 25 lineage primary content and creation/import gaps','SOURCE_GAP','SOURCE_GAP','LiveBus:POWER_AUDIT_R1_20261008!A12:D15','August title leads found, but original source body census has not been verified')
n('AUDIT-POST-OCT8','Source changes after audit snapshot 8 October','SOURCE_GAP','SOURCE_GAP','LiveBus:WORKSPACE_CODEX_20261012!A284:H285','R3 candidates and later data cannot be retroactively counted in Oct08 census')
n('AUDIT-CURRENT-RESOLVER','CURRENT stable family successor not maximum suffix','AUDIT','CANON_DESIGN','LiveBus:157_V8_ACTIVE_SUCCESSOR_INDEX!A1:H5','Do not select versions only from release-style names')
n('AUDIT-OWNER-SCOPE','Separate Bách/DEUS and Cường/PHD data/rights','AUDIT','CANON_DESIGN','LiveBus:151_DEVICE_AUTHORITY_PARTITION!A1:H6','Unrelated subject and personal sources must not be absorbed')

n('SECONDARY-NOETIC','Noetic Wildforest intelligence seedbank lead','SECONDARY','SOURCE_METADATA_ONLY','Drive:1qr8ANSQls1i50kUTFjyhDbLZqdeyCjLe','Research source only; does not prove fully adopted separate superintelligence')
n('SECONDARY-OMEGA-VOICE','Ω-Voice acoustic identity and multimodal research','SECONDARY','SOURCE_METADATA_ONLY','Drive:1Cm1XcupxmSWTXHAiLEp6BOv4WNe_hiDxaOuKArI__t0','Source lead; speech/multimodal native deployment not verified')
n('SECONDARY-DEFENSIVE','Defensive intelligence knowledge atlas','SECONDARY','SOURCE_METADATA_ONLY','Drive:1Xf_Q07vePNyPw2EYbZ1Ks5ly4_MxbfojU-SWtQbeTms','No uncontrolled cyber action or private source ingestion')
n('SECONDARY-BL-ALIAS','Unresolved owner label kiếm trí tuệ','SECONDARY','SOURCE_GAP','LiveBus:POWER_FAMILIES_R1_20261008!A35:E38','Exact referent may differ from Noetic Wildforest; keep literal unresolved')
n('SECONDARY-PROVIDER-ECON','Compute machine-economy and cost/rights accounting','SECONDARY','CANON_DESIGN','LiveBus:POWER_FAMILIES_R1_20261008!A30:E36','Physical credits and billing are task/provider measured, never inferred')
n('SECONDARY-DIGE-VISUAL','DiGe image/multimodal skill family under separate scope','SECONDARY','SOURCE_METADATA_ONLY','LiveBus:POWER_FAMILIES_R1_20261008!A15:E22','Do not treat image-skill claims as an integrated native language model')

# New edge directions are source lineage / verification obligations only.
for a,b,k in [
 ('BL-ROOT','HYPERWEAVE-6D','LINEAGE'),('BL-ROOT','HYPER-BL-CAUSAL3D','LINEAGE'),
 ('BL-ROOT','HYPER-MMX12','LINEAGE'),('LANG-ATOMDEFECT','HYPER-ATOMDEFECT','SOURCE_BRIDGE'),
 ('N0-HHIR','HYPER-BLSEMIR','SOURCE_BRIDGE'),('BL-EYE2-MAP','HYPER-PHI-PSI','SOURCE_BRIDGE'),
 ('HYPER-BLSEMIR','HYPERGRAPH-SYNERGY','HYPEREDGE_CONCEPT'),
 ('HYPER-MMX12','HYPERGRAPH-SYNERGY','HYPEREDGE_CONCEPT'),
 ('HYPER-ATOMDEFECT','HYPERGRAPH-SYNERGY','HYPEREDGE_CONCEPT'),
 ('HYPERWEAVE-6D','HYPERGRAPH-SYNERGY','RESEARCH_LINK'),
 ('HYPER-BL-CAUSAL3D','HYPERGRAPH-SYNERGY','RESEARCH_LINK'),
 ('HYPER-PHI-PSI','HYPERGRAPH-SYNERGY','INVARIANT_OBLIGATION'),
 ('MATRIX-CORE','HYPERGRAPH-NETBENCH','SOURCE_BRIDGE'),
 ('HYPERGRAPH-NETBENCH','HYPERGRAPH-PUBLIC-TOY','SYNTHETIC_REFERENCE'),
 ('HYPERGRAPH-SYNERGY','HYPERGRAPH-PUBLIC-TOY','SYNTHETIC_REFERENCE'),
 ('HYPERGRAPH-PUBLIC-TOY','DEUS-ONE-API','SYNTHETIC_REFERENCE'),
 ('HYPER-DIGEREFERENCE','SECONDARY-DIGE-VISUAL','RESEARCH_LINK'),
 ('MAP-CTX-CODEC','HYPER-MAPPING-CONTEXT','SOURCE_BRIDGE'),
 ('HYPER-MAPPING-CONTEXT','HYPERGRAPH-SYNERGY','INVARIANT_OBLIGATION'),
 ('NET-BRAIN-FED','MULTINODE-BRAIN-FED','SOURCE_BRIDGE'),
 ('MULTINODE-BRAIN-FED','MULTINODE-SHARDMAP','RESEARCH_LINK'),
 ('MULTINODE-SHARDMAP','MULTINODE-SUPERCELL','RESEARCH_LINK'),
 ('NET-LEASE-CAS','MULTINODE-LEASE','SOURCE_BRIDGE'),
 ('MULTINODE-LEASE','MULTINODE-SUPERCELL','INVARIANT_OBLIGATION'),
 ('MULTINODE-SCALED-QUOTA','MULTIRESOURCE-PUBLIC-TOY','SYNTHETIC_REFERENCE'),
 ('MULTINODE-PROVIDER-RECIP','MULTIRESOURCE-PUBLIC-TOY','INVARIANT_OBLIGATION'),
 ('MULTINODE-SUPERCELL','MULTIRESOURCE-PUBLIC-TOY','RESEARCH_LINK'),
 ('MULTIRESOURCE-PUBLIC-TOY','DEUS-ONE-API','SYNTHETIC_REFERENCE'),
 ('NET-RESOURCE-RECIPROCITY','MULTINODE-PROVIDER-RECIP','SOURCE_BRIDGE'),
 ('SEARCH-CELL','SEARCH-FEDERATION','SOURCE_BRIDGE'),
 ('SEARCH-FEDERATION','SEARCH-WORLDTREE','RESEARCH_LINK'),
 ('SEARCH-FEDERATION','SEARCH-UMS','RESEARCH_LINK'),
 ('SEARCH-FEDERATION','SEARCH-RECOVERY','RESEARCH_LINK'),
 ('SEARCH-FEDERATION','SEARCH-EYE2-FALSE','RESEARCH_LINK'),
 ('BL-ROOT','SEARCH-XGAMETE','LINEAGE'),
 ('SEARCH-XGAMETE','SEARCH-METADATA-PUBLIC-TOY','SYNTHETIC_REFERENCE'),
 ('SEARCH-WORLDTREE','SEARCH-METADATA-PUBLIC-TOY','SYNTHETIC_REFERENCE'),
 ('SEARCH-UMS','SEARCH-METADATA-PUBLIC-TOY','SYNTHETIC_REFERENCE'),
 ('SEARCH-RECOVERY','SEARCH-METADATA-PUBLIC-TOY','CURRENT_GATE'),
 ('SEARCH-EYE2-FALSE','SEARCH-METADATA-PUBLIC-TOY','ANTI_FALSE_ACCEPT'),
 ('SEARCH-METADATA-PUBLIC-TOY','DEUS-ONE-API','SYNTHETIC_REFERENCE'),
 ('HYPERWEAVE-6D','COMP-HYPERWEAVE-LOSS','RESEARCH_LINK'),
 ('COMPRESS-DECISION-PRESERVE','COMP-OBJECT-NEGATIVE','SOURCE_BRIDGE'),
 ('COMP-OBJECT-NEGATIVE','COMP-HYPERWEAVE-LOSS','ANTI_FALSE_ACCEPT'),
 ('COMP-REUSE-NET','COMP-LOCAL-WORK','RESEARCH_LINK'),
 ('COMP-LOCAL-WORK','HYPERGRAPH-NETBENCH','INVARIANT_OBLIGATION'),
 ('COMP-HYPERWEAVE-LOSS','HYPERGRAPH-PUBLIC-TOY','INVARIANT_OBLIGATION'),
 ('COMP-REUSE-NET','HYPERGRAPH-SYNERGY','SOURCE_BRIDGE'),
 ('AUDIT-POWER-20261008','AUDIT-CLASS-37','SOURCE_BRIDGE'),
 ('AUDIT-POWER-20261008','AUDIT-F00-643','SOURCE_BRIDGE'),
 ('AUDIT-POWER-20261008','AUDIT-AUG-ORIG','SOURCE_BRIDGE'),
 ('AUDIT-CLASS-37','AUDIT-NATIVE-DENOM','INVARIANT_OBLIGATION'),
 ('AUDIT-F00-643','AUDIT-NATIVE-DENOM','INVARIANT_OBLIGATION'),
 ('AUDIT-AUG-ORIG','AUDIT-NATIVE-DENOM','INVARIANT_OBLIGATION'),
 ('AUDIT-POST-OCT8','AUDIT-NATIVE-DENOM','INVARIANT_OBLIGATION'),
 ('AUDIT-CURRENT-RESOLVER','AUDIT-NATIVE-DENOM','CURRENT_GATE'),
 ('AUDIT-OWNER-SCOPE','AUDIT-NATIVE-DENOM','INVARIANT_OBLIGATION'),
 ('AUDIT-NATIVE-DENOM','SEARCH-METADATA-PUBLIC-TOY','ANTI_FALSE_ACCEPT'),
 ('AUDIT-CLASS-37','SECONDARY-NOETIC','SEARCH_INDEX'),
 ('AUDIT-CLASS-37','SECONDARY-OMEGA-VOICE','SEARCH_INDEX'),
 ('AUDIT-CLASS-37','SECONDARY-DEFENSIVE','SEARCH_INDEX'),
 ('AUDIT-CLASS-37','SECONDARY-BL-ALIAS','SEARCH_INDEX'),
 ('AUDIT-CLASS-37','SECONDARY-PROVIDER-ECON','SEARCH_INDEX'),
 ('AUDIT-CLASS-37','SECONDARY-DIGE-VISUAL','SEARCH_INDEX'),
 ('SECONDARY-NOETIC','SEARCH-METADATA-PUBLIC-TOY','SEARCH_INDEX'),
 ('SECONDARY-OMEGA-VOICE','SEARCH-METADATA-PUBLIC-TOY','SEARCH_INDEX'),
 ('SECONDARY-DEFENSIVE','SEARCH-METADATA-PUBLIC-TOY','SEARCH_INDEX'),
 ('SECONDARY-BL-ALIAS','SEARCH-METADATA-PUBLIC-TOY','SEARCH_INDEX'),
 ('SECONDARY-PROVIDER-ECON','SEARCH-METADATA-PUBLIC-TOY','SEARCH_INDEX'),
 ('SECONDARY-DIGE-VISUAL','SEARCH-METADATA-PUBLIC-TOY','SEARCH_INDEX'),
 ]:e(a,b,k)

z={'schema':SCHEMA,'model':'DEUS-ONE','version':'R4-SOURCE-CANDIDATE',
   'r1_source_sha256':graph_digest(r1),'r2_source_sha256':sha(r2),
   'r3_source_sha256':sha(r3),'nodes':N,'edges':E,
   'node_count':len(N),'edge_count':len(E),'continuity':r1['continuity'],
   'limits':LIMITS,'source_candidate_only':True,'runtime_target_ack':False,
   'native_adapters_bound':False,'private_core_copied':False,
   'whole_corpus_exhausted':False,'real_multi_node_dispatch':False,
   'actual_multidimensional_compute_gain':False,'new_model_weights':False}
validate_r4(r1,r2,r3,z)
(P/'CAPABILITY_EXTENSION_R4.json').write_text(json.dumps(z,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
print('R4 nodes',len(N),'R4 edges',len(E),'total',sum(len(x['nodes']) for x in (r1,r2,r3,z)),sum(len(x['edges']) for x in (r1,r2,r3,z)),'r4 sha256',sha(z))
