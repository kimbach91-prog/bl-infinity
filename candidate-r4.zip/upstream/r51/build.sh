#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p bin evidence
${CXX:-g++} -O3 -std=c++17 -pthread -Wall -Wextra -Werror src/deus_r51.cpp -o bin/deus_r51
${CXX:-g++} -O3 -std=c++17 -Wall -Wextra -Werror src/export_kqk.cpp -o bin/export_kqk
bin/export_kqk bin/kqk.dtm > evidence/kqk_export_rebuild.json
# Opponent is not bundled: place the independently hash-verified official SF19 in bin/stockfish19.
