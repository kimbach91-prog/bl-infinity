// New export wrapper around original immutable R4.1 PUBLIC reference. Original main preserved.
#define main r41_original_main
#include "../upstream/r41/deus_one/reference/chess_kqk_retrograde_r41.cpp"
#undef main
#include <fstream>
#include <chrono>
int main(int argc,char**argv){
 if(argc!=2)return 2;
 auto t=chrono::steady_clock::now();
 Arena a;const int n=int(a.st.size());vector<vector<int>> pred(n);vector<int> left(n),maxd(n,0),d(n,-1);
 priority_queue<pair<int,int>,vector<pair<int,int>>,greater<pair<int,int>>> pq;
 long edges=0;int mates=0;
 for(int i=0;i<n;i++){
  a.edges(i,[&](int j){edges++;left[i]++;if(j>=0)pred[j].push_back(i);});
  const auto&s=a.st[i];if(s.turn==1&&!left[i]&&queen_checks(s.wq,s.bk,s.wk)){d[i]=0;pq.emplace(0,i);mates++;}
 }
 while(!pq.empty()){
  auto [distance,v]=pq.top();pq.pop();
  for(int p:pred[v]){
   if(d[p]>=0)continue;
   if(a.st[p].turn==0){d[p]=distance+1;pq.emplace(d[p],p);}
   else{left[p]--;maxd[p]=max(maxd[p],distance);if(left[p]==0){d[p]=maxd[p]+1;pq.emplace(d[p],p);}}
  }
 }
 vector<int16_t> raw(RAW,-2);int wins=0,draws=0,maximum=0,errors=0;
 for(int i=0;i<n;i++){
  const auto&s=a.st[i];raw[code(s.wk,s.wq,s.bk,s.turn)]=int16_t(d[i]);
  if(d[i]>=0){wins++;maximum=max(maximum,d[i]);}else draws++;
  int mini=10000,maxi=-1,num=0;bool escape=false;
  a.edges(i,[&](int j){num++;if(j<0||d[j]<0)escape=true;else{mini=min(mini,d[j]);maxi=max(maxi,d[j]);}});
  if(d[i]==0){if(num||s.turn!=1||!queen_checks(s.wq,s.bk,s.wk))errors++;}
  else if(d[i]>0){if(s.turn==0&&d[i]!=mini+1)errors++;if(s.turn==1&&(escape||d[i]!=maxi+1))errors++;}
  else{if(s.turn==0&&mini!=10000)errors++;if(s.turn==1&&num&&!escape)errors++;}
 }
 if(n!=368452||edges!=4891672||mates!=364||wins!=345404||draws!=23048||maximum!=20||errors)return 3;
 ofstream out(argv[1],ios::binary);out.write(reinterpret_cast<const char*>(raw.data()),RAW*2);out.close();
 if(!out)return 4;
 cout<<"{\"states\":"<<n<<",\"edges\":"<<edges<<",\"wins\":"<<wins<<",\"draws\":"<<draws<<",\"mates\":"<<mates<<",\"max_dtm\":"<<maximum<<",\"bellman_errors\":"<<errors<<",\"build_ms\":"<<chrono::duration_cast<chrono::milliseconds>(chrono::steady_clock::now()-t).count()<<",\"format\":\"little-endian int16 raw 524288\",\"native_core\":false}\n";
 return 0;
}
