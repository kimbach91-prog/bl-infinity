// DEUS-ONE chess R5.1 PUBLIC RECONSTRUCTION, NOT recovered original R5 or private DEUS.
// Original bounded standard-chess UCI search. No Stockfish source, NNUE, or move calls.
// Source lineage: R4.1 KQK raw DTM optional handoff, externally hash-pinned by launcher.
// Build: g++ -O3 -std=c++17 -pthread -Wall -Wextra -Werror src/deus_r51.cpp -o bin/deus_r51
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <limits>
#include <mutex>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <unordered_set>
#include <vector>
using namespace std;
using Clock = chrono::steady_clock;
mutex output_mutex;
void emit(const string &line){lock_guard<mutex> g(output_mutex);cout<<line<<flush;}
constexpr int INF=32000, MATE=30000, MAXPLY=96;
constexpr int P=1,N=2,B=3,R=4,Q=5,K=6;
const int NV[8]={33,31,18,14,-14,-18,-31,-33};
const int KV[8]={1,-1,16,-16,15,17,-15,-17};
const int BV[4]={15,17,-15,-17};
const int RV[4]={1,-1,16,-16};
const int VALUE[7]={0,100,320,335,505,980,0};
uint64_t mix64(uint64_t x){x+=0x9e3779b97f4a7c15ULL;x=(x^(x>>30))*0xbf58476d1ce4e5b9ULL;x=(x^(x>>27))*0x94d049bb133111ebULL;return x^(x>>31);}
bool inside(int s){return s>=0&&s<128&&!(s&0x88);}
int sq64(int s){return (s>>4)*8+(s&7);}
string coord(int s){return string(1,char('a'+(s&7)))+char('1'+(s>>4));}
int parseSquare(const string &s){if(s.size()!=2||s[0]<'a'||s[0]>'h'||s[1]<'1'||s[1]>'8')return -1;return (s[1]-'1')*16+s[0]-'a';}
struct Move {int from=-1,to=-1,prom=0,flags=0;}; // ep=1, castle=2
bool operator==(const Move&a,const Move&b){return a.from==b.from&&a.to==b.to&&a.prom==b.prom;}
string uci(const Move&m){if(m.from<0)return "0000";string s=coord(m.from)+coord(m.to);if(m.prom)s+=string("  nbrq")[m.prom];return s;}
struct Board {
 array<int8_t,128> p{};int side=1,castle=0,ep=-1,half=0,full=1;array<int,2> king{{4,116}};
 bool attacked(int s,int by)const{
  for(int d:{15,17}){int q=s-by*d;if(inside(q)&&p[q]==by*P)return true;}
  for(int d:NV){int q=s+d;if(inside(q)&&p[q]==by*N)return true;}
  for(int d:KV){int q=s+d;if(inside(q)&&p[q]==by*K)return true;}
  for(int d:BV){for(int q=s+d;inside(q);q+=d){if(!p[q])continue;if(p[q]==by*B||p[q]==by*Q)return true;break;}}
  for(int d:RV){for(int q=s+d;inside(q);q+=d){if(!p[q])continue;if(p[q]==by*R||p[q]==by*Q)return true;break;}}
  return false;
 }
 bool check()const{return attacked(king[side==1?0:1],-side);}
 uint64_t repkey()const{
  uint64_t h=mix64(uint64_t(side+2))^mix64(1000+castle);
  // Include EP only when a legal en-passant capture exists (FIDE repetition semantics).
  if(ep>=0){bool relevant=false;for(int d:{15,17}){int from=ep-side*d;
    if(inside(from)&&p[from]==side*P){Board c=*this;c.p[from]=0;c.p[ep]=side*P;c.p[ep-side*16]=0;
      if(!c.attacked(c.king[side==1?0:1],-side))relevant=true;}}
    if(relevant)h^=mix64(2000+ep);
  }
  for(int s=0;s<128;s++){if(s&0x88){s+=7;continue;}if(p[s])h^=mix64(3000+uint64_t(s*13+p[s]+6));}
  return h;
 }
 static Board fen(const string &f){
  Board b;istringstream ss(f);string placement,turn,rights,eps,extra;
  if(!(ss>>placement>>turn>>rights>>eps>>b.half>>b.full)||(ss>>extra)||b.half<0||b.full<1||b.half>1000000)throw runtime_error("FEN_FIELDS");
  int r=7,c=0,wk=0,bk=0;
  for(char ch:placement){if(ch=='/'){if(c!=8||r<=0)throw runtime_error("FEN_RANK");r--;c=0;continue;}
    if(ch>='1'&&ch<='8'){c+=ch-'0';if(c>8)throw runtime_error("FEN_WIDTH");continue;}
    int type=0;switch(tolower(ch)){case 'p':type=P;break;case 'n':type=N;break;case 'b':type=B;break;case 'r':type=R;break;case 'q':type=Q;break;case 'k':type=K;break;default:throw runtime_error("FEN_PIECE");}
    if(c>=8||r<0||(type==P&&(r==0||r==7)))throw runtime_error("FEN_SQUARE");
    int col=isupper(ch)?1:-1,s=r*16+c++;b.p[s]=col*type;if(type==K){b.king[col==1?0:1]=s;(col==1?wk:bk)++;}
  }
  if(r!=0||c!=8||wk!=1||bk!=1||(turn!="w"&&turn!="b"))throw runtime_error("FEN_STATE");
  b.side=turn=="w"?1:-1;
  if(rights!="-"){for(char x:rights){int bit=x=='K'?1:x=='Q'?2:x=='k'?4:x=='q'?8:0;if(!bit||(b.castle&bit))throw runtime_error("FEN_RIGHTS");b.castle|=bit;}}
  if((b.castle&1)&&(b.p[4]!=K||b.p[7]!=R))throw runtime_error("FEN_RIGHTS");
  if((b.castle&2)&&(b.p[4]!=K||b.p[0]!=R))throw runtime_error("FEN_RIGHTS");
  if((b.castle&4)&&(b.p[116]!=-K||b.p[119]!=-R))throw runtime_error("FEN_RIGHTS");
  if((b.castle&8)&&(b.p[116]!=-K||b.p[112]!=-R))throw runtime_error("FEN_RIGHTS");
  if(eps!="-"){b.ep=parseSquare(eps);if(b.ep<0||(b.ep>>4)!=(b.side==1?5:2)||b.p[b.ep]||b.p[b.ep-b.side*16]!=-b.side*P)throw runtime_error("FEN_EP");}
  if(b.attacked(b.king[b.side==1?1:0],b.side))throw runtime_error("FEN_OPPOSITE_CHECK");
  return b;
 }
 string fenstr()const{
  string s;for(int r=7;r>=0;r--){int e=0;for(int f=0;f<8;f++){int v=p[r*16+f];if(!v){e++;continue;}if(e){s+=to_string(e);e=0;}char c=string(" pnbrqk")[abs(v)];s+=v>0?char(toupper(c)):c;}if(e)s+=to_string(e);if(r)s+='/';}
  s+=side==1?" w ":" b ";string cr;for(auto q:vector<pair<int,char>>{{1,'K'},{2,'Q'},{4,'k'},{8,'q'}})if(castle&q.first)cr+=q.second;
  return s+(cr.empty()?"-":cr)+" "+(ep<0?"-":coord(ep))+" "+to_string(half)+" "+to_string(full);
 }
 Board after(const Move&m)const{
  Board b=*this;int pc=p[m.from],cap=p[m.to];b.p[m.to]=m.prom?side*m.prom:pc;b.p[m.from]=0;
  if(m.flags&1){b.p[m.to-side*16]=0;cap=-side*P;}
  if(abs(pc)==K){b.king[side==1?0:1]=m.to;b.castle&=side==1?12:3;
    if(m.flags&2){int rf=m.to>m.from?m.from+3:m.from-4,rt=m.to>m.from?m.from+1:m.from-1;b.p[rt]=b.p[rf];b.p[rf]=0;}}
  for(auto q:vector<pair<int,int>>{{0,2},{7,1},{112,8},{119,4}})if(m.from==q.first||m.to==q.first)b.castle&=~q.second;
  b.ep=(abs(pc)==P&&abs(m.to-m.from)==32)?(m.from+m.to)/2:-1;
  b.half=(abs(pc)==P||cap)?0:half+1;b.full=full+(side==-1);b.side=-side;return b;
 }
 vector<Move> pseudo()const{
  vector<Move> out;out.reserve(64);
  auto add=[&](int a,int z,int fl=0){if(abs(p[z])==K)return;if(abs(p[a])==P&&((z>>4)==0||(z>>4)==7)){for(int pr:{Q,R,B,N})out.push_back({a,z,pr,fl});}else out.push_back({a,z,0,fl});};
  for(int s=0;s<128;s++){if(s&0x88){s+=7;continue;}int v=p[s];if(v*side<=0)continue;
    int t=abs(v);
    if(t==P){int z=s+side*16;if(inside(z)&&p[z]==0){add(s,z);int zz=z+side*16;if((s>>4)==(side==1?1:6)&&p[zz]==0)add(s,zz);}
      for(int d:{15,17}){z=s+side*d;if(!inside(z))continue;if(p[z]*side<0)add(s,z);else if(z==ep&&p[z]==0&&p[z-side*16]==-side*P)add(s,z,1);}continue;}
    if(t==N){for(int d:NV){int z=s+d;if(inside(z)&&p[z]*side<=0)add(s,z);}continue;}
    if(t==K){for(int d:KV){int z=s+d;if(inside(z)&&p[z]*side<=0)add(s,z);}
      int home=side==1?4:116;
      if(s==home&&!attacked(s,-side)){
        int kb=side==1?1:4,qb=side==1?2:8;
        if((castle&kb)&&p[s+1]==0&&p[s+2]==0&&p[s+3]==side*R&&!attacked(s+1,-side)&&!attacked(s+2,-side))add(s,s+2,2);
        if((castle&qb)&&p[s-1]==0&&p[s-2]==0&&p[s-3]==0&&p[s-4]==side*R&&!attacked(s-1,-side)&&!attacked(s-2,-side))add(s,s-2,2);
      }continue;}
    for(int d:KV){bool diag=abs(d)==15||abs(d)==17;if((t==B&&!diag)||(t==R&&diag))continue;
      for(int z=s+d;inside(z);z+=d){if(p[z]*side>0)break;add(s,z);if(p[z])break;}}
  }
  return out;
 }
 vector<Move> legal()const{vector<Move> out;for(auto m:pseudo()){Board b=after(m);if(!b.attacked(b.king[side==1?0:1],-side))out.push_back(m);}return out;}
 bool insufficient()const{
  int minors=0,bishops=0,bc=-1;
  for(int s=0;s<128;s++){if(s&0x88){s+=7;continue;}int t=abs(p[s]);if(t==P||t==R||t==Q)return false;if(t==N)minors++;
    if(t==B){minors++;bishops++;int color=((s>>4)+(s&7))%2;if(bc<0)bc=color;else if(bc!=color)bc=2;}}
  return minors<=1||(minors==bishops&&bc>=0&&bc<2);
 }
};
uint64_t perft(const Board&b,int d){if(d==0)return 1;uint64_t n=0;for(auto m:b.legal())n+=perft(b.after(m),d-1);return n;}
int evaluation(const Board&b){
 int mg[2]={0,0},eg[2]={0,0},phase=0,bish[2]={0,0},pawns[2][8]{};
 for(int s=0;s<128;s++){if(s&0x88){s+=7;continue;}if(abs(b.p[s])==P)pawns[b.p[s]>0?0:1][s&7]++;}
 for(int s=0;s<128;s++){if(s&0x88){s+=7;continue;}int pc=b.p[s];if(!pc)continue;int c=pc>0?0:1,side=c==0?1:-1,t=abs(pc),f=s&7,r=c==0?(s>>4):7-(s>>4);int center=7-(abs(2*f-7)+abs(2*r-7))/2;
  int m=VALUE[t],e=VALUE[t];
  switch(t){
  case P:{m+=r*5+center*3;e+=r*10+center*2;if(pawns[c][f]>1){m-=12;e-=20;}
    if((f==0||!pawns[c][f-1])&&(f==7||!pawns[c][f+1])){m-=14;e-=12;}
    bool passed=true;for(int q=s+side*16;inside(q);q+=side*16)for(int df=-1;df<=1;df++)if(inside(q+df)&&b.p[q+df]==-side*P)passed=false;
    if(passed){m+=r*r*2;e+=r*r*5;}break;}
  case N:m+=center*9-(r==0?16:0);e+=center*6;phase++;break;
  case B:m+=center*5+(r>0?10:0);e+=center*5;bish[c]++;phase++;break;
  case R:m+=(r==6?18:0)+(!pawns[c][f]?14:0);e+=r*3+(!pawns[c][f]?10:0);phase+=2;break;
  case Q:m+=center*2-(r>2&&b.full<8?12:0);e+=center*4;phase+=4;break;
  case K:{m-=center*8+r*10;e+=center*12;
    if(r==0&&(f==6||f==2))m+=34;
    for(int df=-1;df<=1;df++){int z=s+side*16+df;if(inside(z)&&b.p[z]==side*P)m+=10;}
    int danger=0;for(int d:KV){int z=s+d;if(inside(z)&&b.attacked(z,-side))danger++;}m-=danger*8;break;}
  default:break;
  }
  mg[c]+=m;eg[c]+=e;
 }
 if(bish[0]>=2){mg[0]+=30;eg[0]+=45;}if(bish[1]>=2){mg[1]+=30;eg[1]+=45;}
 phase=min(24,phase);int v=((mg[0]-mg[1])*phase+(eg[0]-eg[1])*(24-phase))/24;
 return b.side*v+8;
}
struct TB {
 vector<int16_t> data;
 explicit TB(const string&path){if(path.empty())return;ifstream f(path,ios::binary);if(!f)throw runtime_error("KQK_FILE");data.resize(524288);f.read(reinterpret_cast<char*>(data.data()),1048576);char c;if(!f||f.get(c))throw runtime_error("KQK_SIZE");}
 int probe(const Board&b,int &strong)const{
  if(data.empty()||b.castle||b.ep>=0)return -3;
  int queen=-1,pieces=0;
  for(int s=0;s<128;s++){if(s&0x88){s+=7;continue;}if(!b.p[s])continue;pieces++;if(abs(b.p[s])==Q){if(queen>=0)return -3;queen=s;}else if(abs(b.p[s])!=K)return -3;}
  if(pieces!=3||queen<0)return -3;
  strong=b.p[queen]>0?1:-1;
  int wk=sq64(b.king[strong==1?0:1]),bk=sq64(b.king[strong==1?1:0]),wq=sq64(queen),turn=b.side==strong?0:1;
  return data[(((wk*64+wq)*64+bk)*2+turn)];
 }
};
struct Entry{uint64_t key=0,guard=0;Move move;int score=0;int16_t depth=-1;uint8_t bound=0;};
struct Limits{int depth=64,millis=1000;uint64_t nodes=numeric_limits<uint64_t>::max();bool infinite=false;vector<string> searchmoves;};
struct Stats{uint64_t nodes=0,ttHits=0,cutoffs=0,qnodes=0,tbHits=0;int depth=0;};
struct Search {
 atomic<bool>&stop;const TB&tb;Limits lim;Clock::time_point start;vector<Entry>&tt;vector<uint64_t> history;uint64_t histSig=0;Stats stat;Move killers[MAXPLY][2]{};int histHeur[128][128]{};int seed;
 Search(atomic<bool>&s,const TB&t,Limits l,vector<Entry>&tab,vector<uint64_t> h,int se):stop(s),tb(t),lim(l),start(Clock::now()),tt(tab),history(move(h)),seed(se){for(auto k:history)histSig+=mix64(k);}
 int elapsed()const{return int(chrono::duration_cast<chrono::milliseconds>(Clock::now()-start).count());}
 bool timeup(){if(stop.load())return true;if(stat.nodes>=lim.nodes||(!lim.infinite&&elapsed()>=lim.millis)){stop=true;return true;}return false;}
 int reps(uint64_t key)const{return int(count(history.begin(),history.end(),key));}
 bool uniqueHistory()const{unordered_set<uint64_t> ss;for(auto k:history)if(!ss.insert(k).second)return false;return true;}
 void push(const Board&b){auto k=b.repkey();history.push_back(k);histSig+=mix64(k);}
 void pop(){histSig-=mix64(history.back());history.pop_back();}
 int order(const Board&b,const Move&m,const Move&hint,int ply)const{
  if(!inside(m.from)||!inside(m.to))return -INF;
  if(m==hint)return 2000000;
  int capture=abs(b.p[m.to]);if(m.flags&1)capture=P;
  int v=0;if(capture)v+=100000+16*VALUE[capture]-VALUE[abs(b.p[m.from])];if(m.prom)v+=80000+VALUE[m.prom];
  if(ply<MAXPLY){if(m==killers[ply][0])v+=60000;else if(m==killers[ply][1])v+=50000;}return v+histHeur[m.from][m.to];
 }
 int qsearch(const Board&b,int alpha,int beta,int ply,int qdepth){
  stat.nodes++;stat.qnodes++;if(timeup())return 0;auto moves=b.legal();bool check=b.check();
  if(moves.empty())return check?-MATE+ply:0;
  if(b.half>=100||reps(history.back())>=3||b.insufficient())return 0;
  int stand=evaluation(b);if(ply>=MAXPLY-2||qdepth>=16)return stand;
  if(!check){if(stand>=beta)return stand;alpha=max(alpha,stand);}
  stable_sort(moves.begin(),moves.end(),[&](auto a,auto c){return order(b,a,{},ply)>order(b,c,{},ply);});
  for(auto m:moves){if(!check&&!b.p[m.to]&&!(m.flags&1)&&!m.prom)continue;Board child=b.after(m);push(child);int v=-qsearch(child,-beta,-alpha,ply+1,qdepth+1);pop();if(stop)return 0;if(v>=beta){stat.cutoffs++;return v;}alpha=max(alpha,v);}
  return alpha;
 }
 int search(const Board&b,int d,int alpha,int beta,int ply){
  if(d<=0)return qsearch(b,alpha,beta,ply,0);
  stat.nodes++;if(timeup())return 0;
  auto moves=b.legal();bool check=b.check();if(moves.empty())return check?-MATE+ply:0;
  if(b.half>=100||reps(history.back())>=3||b.insufficient())return 0;
  if(ply>=MAXPLY-2)return evaluation(b);
  uint64_t rk=history.back(),key=rk^mix64(uint64_t(b.half)+100)^mix64(histSig),guard=histSig;
  Entry &ent=tt[key%tt.size()];Move hint;int oldalpha=alpha;
  if(ent.key==key&&ent.guard==guard){hint=ent.move;if(ent.depth>=d){int v=ent.score;if(v>29000)v-=ply;if(v< -29000)v+=ply;stat.ttHits++;
    if(ent.bound==0||(ent.bound==1&&v>=beta)||(ent.bound==2&&v<=alpha))return v;}}
  stable_sort(moves.begin(),moves.end(),[&](auto a,auto c){return order(b,a,hint,ply)>order(b,c,hint,ply);});
  int best=-INF;Move bm;
  for(auto m:moves){Board c=b.after(m);push(c);int v=-search(c,d-1,-beta,-alpha,ply+1);pop();if(stop)return 0;
    if(v>best){best=v;bm=m;}alpha=max(alpha,v);if(alpha>=beta){stat.cutoffs++;if(!b.p[m.to]&&!(m.flags&1)){killers[ply][1]=killers[ply][0];killers[ply][0]=m;histHeur[m.from][m.to]=min(20000,histHeur[m.from][m.to]+d*d);}break;}}
  int stored=best;if(stored>29000)stored+=ply;if(stored< -29000)stored-=ply;
  ent={key,guard,bm,stored,int16_t(d),uint8_t(best>=beta?1:best<=oldalpha?2:0)};return best;
 }
 Move run(const Board&root){
  auto moves=root.legal();if(!lim.searchmoves.empty())moves.erase(remove_if(moves.begin(),moves.end(),[&](const Move&m){return find(lim.searchmoves.begin(),lim.searchmoves.end(),uci(m))==lim.searchmoves.end();}),moves.end());
  if(moves.empty())return {};
  stable_sort(moves.begin(),moves.end(),[&](const Move&a,const Move&b){return mix64(uint64_t(a.from*128+a.to+a.prom*16384+seed))<mix64(uint64_t(b.from*128+b.to+b.prom*16384+seed));});
  Move chosen=moves.front();int strong=0,dtm=tb.probe(root,strong);
  if(dtm>=0&&root.half+dtm<100&&uniqueHistory()){
    int opt=root.side==strong?1000:-1000;bool found=false;
    for(auto m:moves){Board c=root.after(m);int cs=0,v=tb.probe(c,cs);if(v<0)continue;
      if((root.side==strong&&v<opt)||(root.side!=strong&&v>opt)){chosen=m;opt=v;found=true;}}
    if(found&&opt==dtm-1){stat.tbHits++;ostringstream msg;msg<<"info string route R41_KQK_EXACT_REFERENCE dtm "<<dtm<<" nodes 0 time "<<elapsed()<<" native_core false\n";emit(msg.str());return chosen;}
  }
  Move previous=chosen;int finalScore=evaluation(root);
  for(int depth=1;depth<=lim.depth;depth++){
    if(timeup())break;
    stable_sort(moves.begin(),moves.end(),[&](const Move&a,const Move&b){return order(root,a,previous,0)>order(root,b,previous,0);});
    Move iterBest=chosen;int alpha=-INF,best=-INF;
    for(auto m:moves){Board c=root.after(m);push(c);int value=-search(c,depth-1,-INF,-alpha,1);pop();if(stop)break;
      if(value>best){best=value;iterBest=m;}alpha=max(alpha,value);}
    if(stop)break;
    chosen=iterBest;previous=chosen;stat.depth=depth;finalScore=best;
    ostringstream msg;msg<<"info depth "<<depth<<" score cp "<<best<<" nodes "<<stat.nodes<<" time "<<elapsed()<<" nps "<<(stat.nodes*1000/(elapsed()+1))<<" pv "<<uci(chosen)<<"\n";emit(msg.str());
    if(abs(best)>MATE-MAXPLY)break;
  }
  ostringstream msg;msg<<"info string route R51_RECONSTRUCTED_PUBLIC_SEARCH native_core false tt_hits "<<stat.ttHits<<" cutoffs "<<stat.cutoffs<<" qnodes "<<stat.qnodes<<" evaluated_cp "<<finalScore<<" nodes "<<stat.nodes<<" time "<<elapsed()<<"\n";emit(msg.str());
  return chosen;
 }
};
int main(int argc,char**argv){
 ios::sync_with_stdio(false);cin.tie(nullptr);
 string tbpath;for(int i=1;i+1<argc;i++)if(string(argv[i])=="--kqk")tbpath=argv[++i];
 try{
  TB tb(tbpath);Board board=Board::fen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1");vector<uint64_t> history{board.repkey()};
  int hashMB=32,seed=1;vector<Entry> table(size_t(hashMB)*1024*1024/sizeof(Entry));atomic<bool> stop{false};thread worker;bool positionValid=true;
  auto join=[&](){stop=true;if(worker.joinable())worker.join();};
  string line;
  while(getline(cin,line)){
    if(line.size()>200000){cout<<"info string rejected LINE_TOO_LONG\n"<<flush;continue;}
    istringstream ss(line);string cmd;ss>>cmd;if(cmd.empty())continue;
    try{
      if(cmd=="uci")cout<<"id name DEUS-ONE R5.1 PUBLIC Reconstruction\nid author DEUS project experimental adapter\noption name Hash type spin default 32 min 1 max 256\noption name Threads type spin default 1 min 1 max 1\noption name Seed type spin default 1 min 0 max 1000000\nuciok\n"<<flush;
      else if(cmd=="isready")emit("readyok\n");
      else if(cmd=="stop"){join();}
      else if(cmd=="quit"){join();break;}
      else if(cmd=="ucinewgame"){join();fill(table.begin(),table.end(),Entry{});history={board.repkey()};}
      else if(cmd=="setoption"){
        join();string w,name,val;ss>>w;if(w!="name")throw runtime_error("OPTION_SCHEMA");while(ss>>w&&w!="value"){if(!name.empty())name+=' ';name+=w;}getline(ss,val);int v=stoi(val);
        if(name=="Hash"){if(v<1||v>256)throw runtime_error("HASH_BOUND");hashMB=v;table.assign(size_t(v)*1024*1024/sizeof(Entry),Entry{});}
        else if(name=="Threads"){if(v!=1)throw runtime_error("THREADS_NOT_IMPLEMENTED");}
        else if(name=="Seed"){if(v<0||v>1000000)throw runtime_error("SEED_BOUND");seed=v;}
        else throw runtime_error("OPTION_UNSUPPORTED");
      }
      else if(cmd=="position"){
        join();positionValid=false;string mode,word;ss>>mode;Board candidate;
        if(mode=="startpos")candidate=Board::fen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1");
        else if(mode=="fen"){string f;for(int i=0;i<6;i++){if(!(ss>>word))throw runtime_error("POSITION_FEN");if(i)f+=' ';f+=word;}candidate=Board::fen(f);}else throw runtime_error("POSITION_MODE");
        vector<uint64_t> h{candidate.repkey()};int steps=0;
        if(ss>>word){if(word!="moves")throw runtime_error("POSITION_TRAILING");while(ss>>word){if(++steps>2000)throw runtime_error("POSITION_TOO_LONG");auto legal=candidate.legal();auto it=find_if(legal.begin(),legal.end(),[&](auto m){return uci(m)==word;});if(it==legal.end())throw runtime_error("ILLEGAL_REPLAY");candidate=candidate.after(*it);h.push_back(candidate.repkey());}}
        board=candidate;history=move(h);positionValid=true;
      }
      else if(cmd=="go"){
        join();if(!positionValid){cout<<"info string rejected INVALID_POSITION\nbestmove 0000\n"<<flush;continue;}
        Limits lim;string w;int per=-1;long wt=-1,bt=-1,wi=0,bi=0,mtg=30;bool explicitTime=false;
        while(ss>>w){if(w=="perft"){ss>>per;if(per<0||per>5)throw runtime_error("PERFT_BOUND");}
          else if(w=="movetime"){ss>>lim.millis;explicitTime=true;if(lim.millis<1||lim.millis>60000)throw runtime_error("TIME_BOUND");}
          else if(w=="depth"){ss>>lim.depth;if(lim.depth<1||lim.depth>64)throw runtime_error("DEPTH_BOUND");lim.infinite=true;}
          else if(w=="nodes"){ss>>lim.nodes;if(lim.nodes<1)throw runtime_error("NODES_BOUND");lim.infinite=true;}
          else if(w=="infinite")lim.infinite=true;
          else if(w=="wtime")ss>>wt;else if(w=="btime")ss>>bt;else if(w=="winc")ss>>wi;else if(w=="binc")ss>>bi;else if(w=="movestogo")ss>>mtg;
          else if(w=="searchmoves"){while(ss>>w)lim.searchmoves.push_back(w);break;}
          else throw runtime_error("GO_UNSUPPORTED");
          if(ss.fail())throw runtime_error("GO_VALUE");
        }
        if(per>=0){uint64_t total=0;if(per==0)total=1;else for(auto m:board.legal()){auto n=perft(board.after(m),per-1);total+=n;cout<<uci(m)<<": "<<n<<"\n";}cout<<"Nodes searched: "<<total<<"\n"<<flush;continue;}
        long rem=board.side==1?wt:bt,inc=board.side==1?wi:bi;
        if(rem>=0&&!explicitTime){lim.millis=int(max(1L,min(rem/2,max(1L,rem/max(1L,mtg)+inc*3/4-10))));lim.infinite=false;}
        if(explicitTime)lim.infinite=false;
        stop=false;Board pos=board;auto hh=history;
        worker=thread([&,pos,hh,lim](){try{Search engine(stop,tb,lim,table,hh,seed);Move m=engine.run(pos);emit("bestmove "+uci(m)+"\n");}catch(const exception&){emit("info string search ERROR\nbestmove 0000\n");}});
      }
      else if(cmd=="d"){join();cout<<"Fen: "<<board.fenstr()<<"\nCheckers: "<<(board.check()?"checked":"")<<"\n"<<flush;}
      else cout<<"info string unsupported "<<cmd<<"\n"<<flush;
    }catch(const exception&e){cout<<"info string rejected "<<e.what()<<"\n"<<flush;}
  }
  join();return 0;
 }catch(const exception&e){cerr<<"BOOT_FAILED "<<e.what()<<"\n";return 2;}
}
