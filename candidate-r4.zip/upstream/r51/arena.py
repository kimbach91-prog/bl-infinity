"""Local PUBLIC R5.1 reconstruction arena; NOT official online or full private DEUS.
The opponent and the independent rules-oracle processes are pinned Stockfish 19.
The oracle never sends a move suggestion/evaluation to the DEUS process.
All competition games begin at standard startpos. No engine-evaluation adjudication.
"""
from __future__ import annotations
import argparse, concurrent.futures, collections, hashlib, json, os, queue, re
import subprocess, threading, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
START = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'
SF_SHA = '2d89ca06b7f564cdea08fc1433d35b78d18178f5ceee9cab50133ab8d69c0cd2'
MOVE = re.compile(r'^([a-h][1-8])([a-h][1-8])([qnrb])?$')

def sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def canonical(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()

def atomic_json(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix+'.tmp')
    tmp.write_bytes(canonical(obj))
    os.replace(tmp, path)

def proc_cpu(pid: int) -> float:
    raw = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
    return (int(raw[11])+int(raw[12]))/os.sysconf('SC_CLK_TCK')

class Engine:
    def __init__(self, cmd, core=None):
        self.cmd = [str(x) for x in cmd]
        self.proc = subprocess.Popen(self.cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, bufsize=1)
        if core is not None:
            os.sched_setaffinity(self.proc.pid, {core})
        self.q=queue.Queue(); self.stderr=[]
        def readout():
            for line in self.proc.stdout:
                self.q.put(line.rstrip('\r\n'))
            self.q.put(None)
        def readerr():
            for line in self.proc.stderr:
                self.stderr.append(line.rstrip())
        self.reader=threading.Thread(target=readout,daemon=True);self.reader.start()
        threading.Thread(target=readerr,daemon=True).start()
        self.send('uci'); self.handshake=self.until(lambda s:s=='uciok',10)
        self.identity=next((s[8:] for s in self.handshake if s.startswith('id name ')),None)
        if not self.identity:
            self.close(); raise RuntimeError('Missing UCI identity')
        self.send('setoption name Threads value 1');self.send('setoption name Hash value 32')
        if any('option name UCI_LimitStrength' in s for s in self.handshake):
            self.send('setoption name UCI_LimitStrength value false')
        if any('option name Skill Level' in s for s in self.handshake):
            self.send('setoption name Skill Level value 20')
        self.ready()
    def send(self, line):
        if '\n' in line or '\r' in line: raise ValueError('Not one UCI line')
        self.proc.stdin.write(line+'\n');self.proc.stdin.flush()
    def until(self, predicate, timeout=10):
        lines=[]; deadline=time.monotonic()+timeout
        while True:
            left=deadline-time.monotonic()
            if left<=0: raise TimeoutError('UCI timeout')
            item=self.q.get(timeout=left)
            if item is None: raise RuntimeError(f'Engine died {self.proc.poll()}: {self.stderr[-3:]}')
            lines.append(item)
            if predicate(item):return lines
    def ready(self):
        self.send('isready');return self.until(lambda s:s=='readyok')
    def position(self, moves=(), fen=None):
        line='position '+('fen '+fen if fen is not None else 'startpos')
        if moves:line+=' moves '+' '.join(moves)
        self.send(line)
    def perft(self, depth):
        self.send(f'go perft {depth}')
        lines=self.until(lambda s:s.startswith('Nodes searched:'),30)
        div={};total=None
        for s in lines:
            m=re.fullmatch(r'([a-h][1-8][a-h][1-8][qnrb]?):\s*(\d+)',s)
            if m:div[m[1]]=int(m[2])
            if s.startswith('Nodes searched:'):total=int(s.split(':',1)[1])
        if total is None:raise ValueError('No perft total')
        return div,total,lines
    def describe(self):
        self.send('d');self.send('isready');lines=self.until(lambda s:s=='readyok')
        fen=next((s[5:] for s in lines if s.startswith('Fen: ')),None)
        check=next((bool(s[len('Checkers:'):].strip()) for s in lines if s.startswith('Checkers:')),None)
        if fen is None or check is None:raise ValueError('No board diagnostics')
        return fen,check
    def play(self, millis):
        t=time.monotonic();cpu=proc_cpu(self.proc.pid)
        self.send(f'go movetime {millis}')
        lines=self.until(lambda s:s.startswith('bestmove '),max(3, millis/1000+2))
        elapsed=time.monotonic()-t;used=proc_cpu(self.proc.pid)-cpu
        move=lines[-1].split()[1]; nodes=0;depth=0;route=None
        for s in lines:
            n=re.search(r'\bnodes (\d+)',s)
            d=re.search(r'\bdepth (\d+)',s)
            if n:nodes=int(n[1])
            if d:depth=int(d[1])
            if s.startswith('info string route '):route=s
        return move,{'wall_seconds':elapsed,'cpu_seconds':used,'reported_nodes':nodes,
                     'completed_depth':depth,'route':route,'uci_output':lines}
    def close(self):
        if getattr(self,'proc',None) is None:return
        try:
            if self.proc.poll() is None:
                self.send('quit');self.proc.wait(timeout=3)
        except Exception:
            self.proc.kill();self.proc.wait(timeout=3)
        for f in (self.proc.stdin,self.proc.stdout,self.proc.stderr):
            try:f.close()
            except Exception:pass
    def __enter__(self):return self
    def __exit__(self,*args):self.close()

class Position:
    """Independent simple FEN updater/SAN writer; legality supplied by rules oracle.
    Does NOT search or choose moves. No library/engine substitution for DEUS.
    """
    def __init__(self, fen):
        board,self.turn,self.rights,self.ep,half,full=fen.split()
        self.half=int(half);self.full=int(full);self.p={}
        ranks=board.split('/')
        if len(ranks)!=8:raise ValueError('FEN rank')
        for i,rank in enumerate(ranks):
            f=0
            for c in rank:
                if c.isdigit():f+=int(c)
                else:self.p[chr(97+f)+str(8-i)]=c;f+=1
            if f!=8:raise ValueError('FEN width')
    def fen(self):
        out=[]
        for r in range(8,0,-1):
            row='';empty=0
            for f in 'abcdefgh':
                pc=self.p.get(f+str(r))
                if not pc:empty+=1
                else:
                    if empty:row+=str(empty);empty=0
                    row+=pc
            if empty:row+=str(empty)
            out.append(row)
        return '/'.join(out)+' '+self.turn+' '+(self.rights or '-')+' '+self.ep+' '+str(self.half)+' '+str(self.full)
    def apply(self, uci):
        m=MOVE.fullmatch(uci)
        if not m:raise ValueError('UCI move syntax')
        a,z,prom=m.groups();pc=self.p.pop(a);captured=self.p.pop(z,None)
        if pc.lower()=='p' and a[0]!=z[0] and captured is None:
            captured=self.p.pop(z[0]+a[1],None)
            if captured is None:raise ValueError('EP absent')
        if pc.lower()=='k' and abs(ord(a[0])-ord(z[0]))==2:
            rf=('h' if z[0]=='g' else 'a')+a[1];rt=('f' if z[0]=='g' else 'd')+a[1]
            self.p[rt]=self.p.pop(rf)
        self.p[z]=prom.upper() if prom and pc.isupper() else prom if prom else pc
        remove=''
        if pc=='K':remove+='KQ'
        if pc=='k':remove+='kq'
        for sq,right in [('a1','Q'),('h1','K'),('a8','q'),('h8','k')]:
            if a==sq or z==sq:remove+=right
        self.rights=''.join(x for x in self.rights if x!='-' and x not in remove)
        self.ep=a[0]+str((int(a[1])+int(z[1]))//2) if pc.lower()=='p' and abs(int(a[1])-int(z[1]))==2 else '-'
        self.half=0 if pc.lower()=='p' or captured else self.half+1
        self.full+=self.turn=='b';self.turn='b' if self.turn=='w' else 'w'
    def insufficient(self):
        pcs=[(sq,p) for sq,p in self.p.items() if p.lower()!='k']
        if not pcs:return True
        if len(pcs)==1 and pcs[0][1].lower() in 'nb':return True
        if all(p.lower()=='b' for _,p in pcs):
            return len({(ord(sq[0])-97+int(sq[1])-1)%2 for sq,_ in pcs})==1
        return False
    def repkey(self, legal):
        parts=self.fen().split()[:4]
        if self.ep!='-':
            possible=any(m[2:4]==self.ep and self.p.get(m[:2],'').lower()=='p' and m[0]!=m[2] for m in legal)
            if not possible:parts[3]='-'
        return ' '.join(parts)
    def san(self, move, legal, next_checked, next_empty):
        a,z,prom=MOVE.fullmatch(move).groups();pc=self.p[a]
        if pc.lower()=='k' and abs(ord(a[0])-ord(z[0]))==2:s='O-O' if z[0]=='g' else 'O-O-O'
        else:
            capture=z in self.p or (pc.lower()=='p' and a[0]!=z[0])
            if pc.lower()=='p':s=a[0] if capture else ''
            else:
                s=pc.upper();others=[m[:2] for m in legal if m[2:4]==z and m[:2]!=a and self.p.get(m[:2])==pc]
                if others:
                    s+=a[0] if all(q[0]!=a[0] for q in others) else a[1] if all(q[1]!=a[1] for q in others) else a
            s+=('x' if capture else '')+z
            if prom:s+='='+prom.upper()
        if next_checked:s+='#' if next_empty else '+'
        return s

def compare_fen(a,b):
    # EP is normalized separately by the legal-move oracle; all other fields exact.
    aa=a.split();bb=b.split()
    return aa[:3]+aa[4:]==bb[:3]+bb[4:]

def game(number:int,millis:int,core:int,outdir:Path,seed:int,cap=400):
    path=outdir/f'game_{number:03}.json';cp=outdir/f'game_{number:03}.checkpoint.json'
    if path.exists():
        result=json.loads(path.read_text())
        if result['deus_sha256']!=sha((ROOT/'bin/deus_r51').read_bytes()) or result['movetime_ms_each']!=millis or result['seed']!=seed:
            raise ValueError('Completed game source/config conflict')
        previous='0'*64
        for ev in result['events']:
            raw={k:v for k,v in ev.items() if k!='event_sha256'}
            if ev['previous_sha256']!=previous or sha(canonical(raw))!=ev['event_sha256']:
                raise ValueError('Completed game event chain corrupted')
            previous=ev['event_sha256']
        if previous!=result['chain']:raise ValueError('Completed chain root mismatch')
        return {'id':number,'cached':True,'result':result['result'],'reason':result['termination']}
    deus_cmd=[ROOT/'bin/deus_r51','--kqk',ROOT/'bin/kqk.dtm']
    sf_cmd=[ROOT/'bin/stockfish19'];deus_white=number%2==1
    moves=[];events=[];chain='0'*64;resumed=False
    if cp.exists():
        saved=json.loads(cp.read_text())
        expected=sha(canonical({'millis':millis,'seed':seed,'deus_white':deus_white}))
        if saved['config_sha256']!=expected:raise ValueError('Resume config conflict')
        moves=list(saved['moves']);events=list(saved['events']);chain=saved['chain'];resumed=True
        previous='0'*64
        for i,ev in enumerate(events):
            raw={k:v for k,v in ev.items() if k!='event_sha256'}
            if ev['previous_sha256']!=previous or sha(canonical(raw))!=ev['event_sha256'] or ev['uci']!=moves[i]:
                raise ValueError('Resume event integrity')
            previous=ev['event_sha256']
        if len(events)!=len(moves) or previous!=chain:raise ValueError('Resume event count/chain')
    if sha((ROOT/'bin/stockfish19').read_bytes())!=SF_SHA:raise ValueError('Opponent identity mismatch')
    started=time.time();result='*';reason='UNFINISHED';rep=collections.Counter();pos=Position(START)
    for idx,m in enumerate(moves):
        # Restored repetitions are computed from saved verified pre-move keys below.
        pos.apply(m)
    for ev in events:rep[ev['before_key']]+=1
    with Engine(deus_cmd,core) as deus, Engine(sf_cmd,core) as sf, Engine(sf_cmd,core) as oracle:
        if deus.identity!='DEUS-ONE R5.1 PUBLIC Reconstruction' or sf.identity!='Stockfish 19':raise ValueError('Engine identity mismatch')
        deus.send(f'setoption name Seed value {seed}');deus.ready()
        for e in (deus,sf):e.send('ucinewgame');e.ready()
        oracle.position(moves);legal,_,_=oracle.perft(1);fen,checked=oracle.describe()
        if not compare_fen(pos.fen(),fen):raise ValueError('Resume FEN mismatch')
        while len(moves)<cap:
            key=pos.repkey(legal);rep[key]+=1
            if not legal:
                reason='CHECKMATE' if checked else 'STALEMATE';result=('0-1' if pos.turn=='w' else '1-0') if checked else '1/2-1/2';break
            if pos.half>=100 or rep[key]>=3 or pos.insufficient():
                reason='FIFTY_MOVE_CLAIM' if pos.half>=100 else 'THREEFOLD_CLAIM' if rep[key]>=3 else 'INSUFFICIENT_MATERIAL';result='1/2-1/2';break
            is_deus=(pos.turn=='w')==deus_white;e=deus if is_deus else sf
            if is_deus:
                from deus_adapter import select_move
                move,telemetry=select_move(e,moves,millis,f'R51-G{number:03}',len(moves)+1)
            else:
                e.position(moves);move,telemetry=e.play(millis)
            if move not in legal:raise RuntimeError(f'Illegal move {number}/{len(moves)} {move} {e.identity}')
            old=Position(pos.fen());before_fen=fen;old_legal=legal
            pos.apply(move);moves.append(move)
            oracle.position(moves);legal,_,_=oracle.perft(1);fen,checked=oracle.describe()
            if not compare_fen(pos.fen(),fen):raise RuntimeError('Independent FEN updater disagreement')
            san=old.san(move,old_legal,checked,not legal)
            event={'ply':len(moves),'side':old.turn,'engine':'DEUS_R51' if is_deus else 'Stockfish19',
                   'before_fen':before_fen,'before_key':key,'legal_sha256':sha(canonical(sorted(old_legal))),
                   'uci':move,'san':san,'after_fen':fen,'check':checked,'legal_after':len(legal),
                   'telemetry':telemetry,'previous_sha256':chain}
            chain=sha(canonical(event));event['event_sha256']=chain;events.append(event)
            atomic_json(cp,{'moves':moves,'events':events,'chain':chain,'config_sha256':sha(canonical({'millis':millis,'seed':seed,'deus_white':deus_white}))})
        else:reason='PLY_CAP_ABORT_NOT_DRAW'
        # Detect terminal result at exactly cap, rather than misclassifying a final mate.
        if result=='*' and not legal:
            reason='CHECKMATE' if checked else 'STALEMATE';result=('0-1' if pos.turn=='w' else '1-0') if checked else '1/2-1/2'
        payload={'game_id':number,'pair':(number+1)//2,'deus_white':deus_white,'seed':seed,
          'scope':'LOCAL_PUBLIC_RECONSTRUCTED_ENGINE_NOT_FULL_PRIVATE_DEUS','official_online':False,
          'start_fen':START,'result':result,'termination':reason,'plies':len(moves),'events':events,
          'chain':chain,'final_fen':fen,'elapsed_wall_seconds':time.time()-started,'movetime_ms_each':millis,
          'threads_each':1,'hash_mb_each':32,'core':core,'resumed':resumed,
          'deus_identity':deus.identity,'stockfish_identity':sf.identity,'stockfish_sha256':SF_SHA,
          'deus_sha256':sha((ROOT/'bin/deus_r51').read_bytes()),'kqk_sha256':sha((ROOT/'bin/kqk.dtm').read_bytes()),
          'native_core_ack':False,'model_calls':0}
        atomic_json(path,payload)
        header={'Event':'DEUS R5.1 local reconstructed PUBLIC candidate vs official Stockfish 19',
                'Site':'isolated-local-not-online','Date':'2026.10.17','Round':str(number),
                'White':deus.identity if deus_white else sf.identity,'Black':sf.identity if deus_white else deus.identity,
                'Result':result,'TimeControl':'?','TimeBudget':str(millis)+' ms per move each',
                'Termination':reason,'Pair':str((number+1)//2)}
        pgn='\n'.join(f'[{k} "{v}"]' for k,v in header.items())+'\n\n'
        for i,ev in enumerate(events):
            if i%2==0:pgn+=str(i//2+1)+'. '
            pgn+=ev['san']+' '
        pgn+=result+'\n'
        path.with_suffix('.pgn').write_text(pgn)
        return {'id':number,'result':result,'reason':reason,'plies':len(moves),'deus_white':deus_white,'wall':payload['elapsed_wall_seconds']}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--games',type=int,default=100);ap.add_argument('--millis',type=int,default=100)
    ap.add_argument('--workers',type=int,default=2);ap.add_argument('--out',default='evidence/match100');ap.add_argument('--start',type=int,default=1)
    args=ap.parse_args();outdir=ROOT/args.out;outdir.mkdir(parents=True,exist_ok=True)
    cores=sorted(os.sched_getaffinity(0));jobs=[(n,args.millis,cores[(n-args.start)%min(args.workers,len(cores))],outdir,100+(n+1)//2) for n in range(args.start,args.start+args.games)]
    manifest={'games':args.games,'start':args.start,'millis':args.millis,'workers':args.workers,'scope':'LOCAL_NOT_OFFICIAL_NOT_FULL_DEUS','all_startpos':True,'configuration_frozen_before_match':True,'source_sha256':sha((ROOT/'src/deus_r51.cpp').read_bytes()),'binary_sha256':sha((ROOT/'bin/deus_r51').read_bytes()),'stockfish_sha256':SF_SHA,'started_utc_epoch':time.time()}
    mf=outdir/'preregister.json'
    if not mf.exists():atomic_json(mf,manifest)
    else:
        prior=json.loads(mf.read_text())
        for key in ('games','start','millis','source_sha256','binary_sha256','stockfish_sha256'):
            if prior[key]!=manifest[key]:raise ValueError('Existing tournament contract conflict: '+key)
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as ex:
        fs=[ex.submit(game,*j) for j in jobs]
        for f in concurrent.futures.as_completed(fs):
            print(json.dumps(f.result()),flush=True)
    records=[json.loads(p.read_text()) for p in sorted(outdir.glob('game_[0-9][0-9][0-9].json'))]
    w=d=l=ab=0
    for r in records:
        if r['result']=='*':ab+=1
        elif r['result']=='1/2-1/2':d+=1
        elif (r['result']=='1-0')==r['deus_white']:w+=1
        else:l+=1
    summary={'recorded_games':len(records),'completed_games':w+d+l,'DEUS_R51_wins':w,'draws':d,'Stockfish19_wins':l,'aborted':ab,'plies':sum(r['plies'] for r in records),'illegal_moves':0,'official_online_games':0,'full_private_DEUS_games':0,'scope':'LOCAL_PUBLIC_R51_RECONSTRUCTION_ONLY'}
    atomic_json(outdir/'summary.json',summary);print(json.dumps(summary),flush=True)

if __name__=='__main__':main()
