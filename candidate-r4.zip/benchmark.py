"""Reproducible stage and lifecycle timing, not an AGI or playing-strength score."""
from __future__ import annotations
import collections,copy,hashlib,json,os,platform,resource,shutil,statistics,sys,time,zipfile
from pathlib import Path
from kernel import Kernel,canonical,sha,restore_snapshot
from adapters import run_bound,Calls,encode_output
from workloads import corpus,task,workflow
from compose import run_workflow

ROOT=Path(__file__).resolve().parent

def percentile(xs,q):
    s=sorted(xs);return s[max(0,min(len(s)-1,round((len(s)-1)*q)))]
def summary(xs):return {'n':len(xs),'p50_ms':round(statistics.median(xs)/1e6,6),'p95_ms':round(percentile(xs,.95)/1e6,6),'min_ms':round(min(xs)/1e6,6),'max_ms':round(max(xs)/1e6,6)}

def run(output:Path, match_zip:Path|None=None):
    output=Path(output)
    if output.exists():raise RuntimeError('Choose a new output dir; no rerun/overwrite of completed benchmark')
    output.mkdir(parents=True);data=corpus();(output/'workload_120.json').write_bytes(canonical(data))
    rows=[];stage_raw=collections.defaultdict(list);checked=0;false_promotions=0
    start=time.time();cpu0=resource.getrusage(resource.RUSAGE_SELF).ru_utime;child0=resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime
    for repeat in range(3):
        with Kernel(output/f'state_{repeat}.db') as k:
            # Explicit warmup of common interpreter/verifier processes, not task-result cache.
            p=task('backchain',1)['payload'];r,_=run_bound('backchain',p);k.verifier.verify('backchain',p,r)
            for i,q in enumerate(data):
                q=copy.deepcopy(q);q['task_id']+=f'.r{repeat}';q['idempotency_key']=q['task_id']
                # Equivalent compute+independent verifier+typed codec; reference lacks durable state.
                def direct():
                    t=time.perf_counter_ns();calls=Calls();out,_=run_bound(q['family'],q['payload'],calls)
                    v=k.verifier.verify(q['family'],q['payload'],out);encode_output(q['task_id'],k.source_id,out,calls)
                    return out,time.perf_counter_ns()-t
                def integrated():
                    t=time.perf_counter_ns();res=k.run(q);return res,time.perf_counter_ns()-t
                if (i+repeat)%2==0:base,bns=direct();result,cns=integrated()
                else:result,cns=integrated();base,bns=direct()
                if sha(base)!=sha(result['output']):raise AssertionError('baseline mismatch')
                if result['native_core'] is not False:raise AssertionError('false full-core credit')
                checked+=1
                for name,val in result['stages'].items():stage_raw[(q['family'],name)].append(val)
                # New task identity, identical value/context/source: explicit exact pure cache experiment.
                reuse=copy.deepcopy(q);reuse['task_id']+='.reuse';reuse['idempotency_key']=reuse['task_id']
                t=time.perf_counter_ns();rr=k.run(reuse);rns=time.perf_counter_ns()-t
                if rr['output']!=base or rr['origin']!='EXACT_REUSE' or rr['receipt']['producer_function_calls']!=0:raise AssertionError('cache equivalence')
                rows.append({'family':q['family'],'repeat':repeat,'index':i,'direct_verified_ns':bns,
                  'integrated_cold_ns':cns,'integrated_reuse_ns':rns,'result_sha':sha(base),
                  'producer_calls':result['receipt']['producer_function_calls'],'reused_producer_calls':0})
                if repeat==0:
                    (output/f'receipt_{i:03}.json').write_bytes(canonical({'request':q,'result':result}))
            expected=k.audit_counts()['PRODUCER_STARTED']
            # Reopen/cold replay keeps immutable results; neither source nor kernel claiming new effects.
            sample=copy.deepcopy(data[7]);sample['task_id']+=f'.r{repeat}';sample['idempotency_key']=sample['task_id']
            snap=output/f'snapshot_{repeat}.db';h=k.snapshot(snap)
        restore_snapshot(snap,output/f'restored_{repeat}.db',h)
        with Kernel(output/f'restored_{repeat}.db') as kr:
            restored=kr.run(sample)
            if restored['origin']!='IDEMPOTENT_REPLAY' or kr.audit_counts()['PRODUCER_STARTED']!=expected:raise AssertionError('restore duplicated computation')
    by_family={}
    for family in sorted({r['family'] for r in rows}):
        f=[x for x in rows if x['family']==family]
        by_family[family]={key:summary([r[key] for r in f]) for key in ('direct_verified_ns','integrated_cold_ns','integrated_reuse_ns')}
        by_family[family]['cold_over_direct']=round(statistics.median([r['integrated_cold_ns'] for r in f])/statistics.median([r['direct_verified_ns'] for r in f]),4)
        by_family[family]['reuse_vs_cold_speedup']=round(statistics.median([r['integrated_cold_ns'] for r in f])/statistics.median([r['integrated_reuse_ns'] for r in f]),4)
    with Kernel(output/'workflow.db') as kw:
        w=workflow();a=run_workflow(kw,w);before=kw.audit_counts()['PRODUCER_STARTED'];b=run_workflow(kw,w)
        if before!=kw.audit_counts()['PRODUCER_STARTED']:raise AssertionError('DAG duplicated')
        (output/'workflow_dependency_receipt.json').write_bytes(canonical(a))
    record_stats=None
    if match_zip:
        raw=match_zip.read_bytes()
        if hashlib.sha256(raw).hexdigest()!='bdfb6f7b7e1eced58a393f35989827bbd5000026a885b169927eee24552f9d29':raise AssertionError('baseline source pin')
        records=[]
        with zipfile.ZipFile(match_zip) as z:
            for i in range(1,101):
                game=json.loads(z.read(f'games/game_{i:03}.json'))
                fields={key:game[key] for key in ('game_id','deus_identity','deus_sha256','stockfish_sha256','result','deus_white','termination','native_core_ack','official_online','chain','plies')}
                content=canonical(fields).decode()
                # This is analysis of archived observations, not fresh play or an assertion of native activation.
                lost=game['result']==('0-1' if game['deus_white'] else '1-0')
                records.append(dict(id=f'baseline-game-{i:03}',source='LiveBus:WORKSPACE_CODEX_20261012!A289:H289',version='R51_LOCAL_MATCH100',data_class='PUBLIC',status='FAIL' if lost else 'UNKNOWN',scar='Chess-strength gate failed; preserve original scope',content=content))
        old_bytes=0;unique=0;raw_count=0;fail_count=0
        with Kernel(output/'baseline_analysis.db') as kb:
            for batch in range(4):
                q=task('evidence',batch,'real-archive');q['payload']={'records':records[batch*25:(batch+1)*25]*2}
                r=kb.run(q);o=r['output']
                if [o['dictionary'][x] for x in o['references']]!=q['payload']['records']:raise AssertionError('lost baseline detail')
                unique+=o['unique_count'];raw_count+=o['original_count'];fail_count+=o['fail_retained']
                old_bytes+=len(canonical(q['payload']))
                (output/f'baseline_analysis_{batch}.json').write_bytes(canonical({'request':q,'result':r}))
        disk=(output/'baseline_analysis.db').stat().st_size
        record_stats={'source_zip_sha256':hashlib.sha256(raw).hexdigest(),'unique_archived_games_preserved':unique,'observations_with_deliberate_duplicates':raw_count,'failure_observations_retained':fail_count,'new_chess_games':0,'changed_baseline_files':0,'input_bytes':old_bytes,'db_bytes_after_close':disk,'claim':'archived result processing, not a new chess verifier'}
    # Kernel tracing overhead is included in both paths; durable storage is only in the integrated path.
    result={'schema':'deus-one-stage-benchmark/1','scope':'LOCAL_PUBLIC_REFERENCE_INTEGRATION',
      'source_context':'pinned R51 archive with unchanged R4.1 public modules',
      'family_count':len(by_family),'unique_synthetic_tasks':len(data),'repeats':3,
      'direct_vs_integrated_equal_outputs':checked,'exact_reuse_checked':len(rows),'cross_process_snapshot_restores':3,
      'families':by_family,'stage_measurements':{f'{f}/{s}':summary(v) for (f,s),v in stage_raw.items()},
      'whole_deus_admission':False,'neural_weights_or_training':False,'native_remote_brains_used':0,
      'new_chess_games':0,'baseline_archive_analysis':record_stats,
      'timing':{'elapsed_wall_s':round(time.time()-start,3),'parent_cpu_user_s':round(resource.getrusage(resource.RUSAGE_SELF).ru_utime-cpu0,3),'terminated_children_user_cpu_s':round(resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime-child0,3)},
      'environment':{'python':sys.version,'platform':platform.platform(),'cpu_affinity':sorted(os.sched_getaffinity(0)) if hasattr(os,'sched_getaffinity') else None},
      'limitations':['Direct verified path omits state persistence; not a durability-equivalent baseline.',
      'Warm reuse uses identical PUBLIC values/context/source; not a new information advantage.',
      'Forecast and resource planning remain bounded synthetic hypotheses, not calibrated real-world truth.',
      'No full-native chess policy was connected; no additional matches performed.']}
    (output/'measurements_raw.json').write_bytes(canonical(rows))
    (output/'SUMMARY.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('stage_measurements','families','environment')},ensure_ascii=False,indent=2))
    for f,v in by_family.items():print(f,v)

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--match-zip')
    args=p.parse_args();run(Path(args.out),Path(args.match_zip) if args.match_zip else None)
