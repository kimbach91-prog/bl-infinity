"""CLI for a local PUBLIC typed workflow. No native or provider calls."""
import argparse, json, sys
from pathlib import Path
from kernel import Kernel
from compose import run_workflow

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--store',required=True)
    p.add_argument('--workflow',required=True)
    a=p.parse_args()
    try:
        spec=json.loads(Path(a.workflow).read_text())
        with Kernel(a.store) as runtime:
            result=run_workflow(runtime,spec)
        print(json.dumps(result,ensure_ascii=False,sort_keys=True))
        return 0 if result['state']=='VERIFIED_LOCAL_DAG_CONTRACT' else 2
    except Exception as exc:
        print(json.dumps({'state':'REJECTED','reason':str(exc),'native_core':False}))
        return 2
if __name__=='__main__':sys.exit(main())
