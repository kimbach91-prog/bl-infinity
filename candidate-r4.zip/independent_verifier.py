"""Independent implementation of bounded semantic checks; imports no producer.

Separate process, but not an external third-party certifier. Forecasts remain
unverified future scenarios; resource descriptions remain synthetic plans.
"""
from __future__ import annotations
import collections, hashlib, json, os, statistics, sys, unicodedata, re

VERSION='deus-one-local-semantic-verifier/1'
def canon(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def need(condition,message):
    if not condition:raise ValueError(message)

def nonpromotion(x):
    forbidden={'runtime_ack','runtime_target_ack','target_ack','authority_granted','lease_obtained',
      'native_dispatch','native_sfret_invoked','native_bl_mapping_executed','search_is_native_deus',
      'native_bl_regression_invoked','native_bio_reflex_executed','native_compression_executed',
      'real_world_action','action_authorized','biological_fidelity_proven','probability_calibrated',
      'future_observed','external_effect','model_quality_gain','scientific_or_semantic_universality'}
    if isinstance(x,dict):
        for k,v in x.items():
            if k in forbidden:need(v is False,'false promotion: '+k)
            nonpromotion(v)
    elif isinstance(x,list):
        for v in x:nonpromotion(v)

def verify(f,p,r):
    nonpromotion(r)
    if f=='evidence':
        raw=p['records']; d=r['dictionary']; refs=r['references']
        need(len(refs)==len(raw),'reference length')
        restored=[]
        for key in refs:
            need(key in d,'missing evidence atom')
            need(hashlib.sha256(canon(d[key])).hexdigest()==key,'bad evidence atom hash')
            restored.append(d[key])
        need(restored==raw,'lossy evidence compression')
        need(len(d)==len(set(map(lambda v:hashlib.sha256(canon(v)).hexdigest(),raw))),'wrong unique count')
        need(r['unique_count']==len(d) and r['original_count']==len(raw),'wrong evidence counts')
        need(r['fail_retained']==sum(x['status']=='FAIL' for x in raw),'lost FAIL')
        need(r['unknown_retained']==sum(x['status']=='UNKNOWN' for x in raw),'lost UNKNOWN')
        need(r['lossless_roundtrip'] is True and r['state']=='PUBLIC_EXACT_RECORD_REUSE_ONLY','evidence status')
    elif f=='metadata':
        norm=lambda s:' '.join(re.findall(r'[\w]+',unicodedata.normalize('NFKC',s).casefold()))
        q=norm(p['query']); tokens=set(q.split()); expected=[]
        for c in p['cards']:
            if c['principal']!='BACH' or (p['families'] and c['family'] not in p['families']):continue
            names=[norm(c['label'])]+[norm(s) for s in c['aliases']]
            if any(tokens<=set(n.split()) for n in names) or q in names:
                expected.append({k:c[k] for k in ('id','family','source_kind','source_date','state','lineage_root')})
        expected.sort(key=lambda c:(c['family'],c['id']))
        need(r['search']['items']==expected,'search content mismatch')
        need(r['search']['matched']==len(expected),'search match count')
        need(r['search']['excluded_nonowner_or_unknown']==sum(c['principal']!='BACH' for c in p['cards']),'scope count')
        roots=sorted(set(c['lineage_root'] for c in expected))
        need(r['lineage']['lineage_roots']==roots and r['lineage']['independent_lineages_claimable']==len(roots),'duplicate lineage independence')
        need(r['lineage']['mirror_is_independent'] is False and r['lineage']['validated_factual_claim'] is False,'metadata is not truth proof')
    elif f=='backchain':
        # Forward BFS independently verifies the upstream reverse BFS certificate.
        adjacency=collections.defaultdict(set)
        for a,b in p['transitions']:adjacency[a].add(b)
        todo=collections.deque([(p['start'],0)]);seen={p['start']};dist=None
        while todo:
            a,n=todo.popleft()
            if a==p['goal']:dist=n;break
            if n==p['max_depth']:continue
            for b in adjacency[a]:
                if b not in seen:seen.add(b);todo.append((b,n+1))
        if dist is None:need(r['path'] is None and r['steps'] is None and r['state']=='HOLD_GOAL_UNREACHABLE_IN_DECLARED_GRAPH','unreachable target falsely solved')
        else:
            path=r['path'];need(type(path) is list and path[0]==p['start'] and path[-1]==p['goal'],'path endpoints')
            need(r['steps']==len(path)-1==dist,'not shortest bounded witness')
            need(all(b in adjacency[a] for a,b in zip(path,path[1:])),'invalid forward path')
            need(r['state']=='PUBLIC_HYPOTHETICAL_GOAL_PATH_ONLY','path claim')
        need(r['independently_verified_reality'] is False,'graph reachability mistaken for world reality')
    elif f=='forecast_reflex':
        vals=p['values'];changes=[b-a for a,b in zip(vals,vals[1:])]
        slope=statistics.median(changes[:-1]);need(slope==int(slope),'unsupported slope')
        err=abs(changes[-1]-slope);base=abs(changes[-1]);o=r['forecast']
        need(o['as_of']==p['as_of'] and o['forecast_tick']==p['as_of']+p['horizon'],'time leakage')
        need(o['fit_holdout_error']==err and o['persistence_holdout_error']==base,'error incorrectly calculated')
        if err>p['tolerance']:state='HOLD_REGIME_CHANGE_OR_DRIFT';prediction=None
        elif err>base:state='HOLD_NO_BENEFIT_OVER_PERSISTENCE';prediction=None
        else:
            state='PUBLIC_FORECAST_SCENARIO_UNVERIFIED';prediction=vals[-1]+int(slope)*p['horizon']
            if abs(prediction)>10000000:state='HOLD_PREDICTION_OUT_OF_BOUND';prediction=None
        need(o['state']==state and o['forecast_value']==prediction,'unsupported future scenario')
        expected=[];cooldown=-100;energy=3
        for i,change in enumerate(changes):
            energy=min(3,energy+1);salience=min(8,abs(change));blocked=i-cooldown<=p['refractory']
            alert=not blocked and energy>=1 and salience>=p['threshold']
            if alert:energy-=1;cooldown=i
            expected.append(dict(tick=i,salience=salience,inhibited=False,refractory=blocked,attention_suggested=alert,remaining_energy=energy))
        need(r['reflex']['frames']==expected,'reflex recurrence error')
        need(r['reflex']['trace_sha256']==hashlib.sha256(canon(expected)).hexdigest(),'reflex digest')
        need(r['reflex']['attention_count']==sum(x['attention_suggested'] for x in expected),'reflex count')
    elif f=='placement':
        candidates=[n for n in p['nodes'] if n['healthy'] and n['latency_ms']<=p['max_latency_ms'] and n['cost_microunits']<=p['max_cost_microunits'] and all(x>=y for x,y in zip(n['capacity'],p['required']))]
        candidates.sort(key=lambda n:(n['cost_microunits'],n['latency_ms'],n['name']))
        if not candidates:need(r['state']=='HOLD_NO_SINGLE_NODE_CAPACITY' and r['suggestion'] is None,'invalid cross-node aggregation')
        else:
            n=candidates[0];m=('CPU_SLOT','RAM_MIB','VRAM_MIB','DISK_MIB','NIC_MBPS','IO_MBPS')
            w=dict(node=n['name'],capacity=dict(zip(m,n['capacity'])),required=dict(zip(m,p['required'])),latency_ms=n['latency_ms'],cost_microunits=n['cost_microunits'])
            need(r['suggestion']==w and r['eligible_nodes']==[x['name'] for x in candidates],'wrong feasible optimum')
            need(r['witness_sha256']==hashlib.sha256(json.dumps(w,sort_keys=True).encode()).hexdigest(),'placement digest')
        need(r['measured_physical_capacity'] is False and r['cross_node_aggregation'] is False,'virtual capacity not actual')
    elif f=='mapping':
        a=p['forward'];need(len(set(a.values()))==len(a),'collapse')
        need(set(p['source_invariants'])==set(p['source_transition'])==set(a),'mapping source universe')
        need(set(p['target_invariants'])==set(p['target_transition'])==set(a.values()),'mapping target universe')
        for x,y in a.items():
            need(p['source_invariants'][x]==p['target_invariants'][y],'lost invariant')
            need(a[p['source_transition'][x]]==p['target_transition'][y],'noncommuting map')
        need(r['state']=='FINITE_SYNTHETIC_MAPPING_PASS' and r['states_checked']==len(a),'mapping result')
        need(all(r[k] is True for k in ('reverse_defined','invariants_preserved','commuting_diagram')),'missing mapping claim')
        body={**p,'phi':p['forward'],'source_pin':'LiveBus:181_V8_MAPPING_CONTEXT!A2:J10'};del body['forward']
        need(r['witness_sha256']==hashlib.sha256(canon(body)).hexdigest(),'mapping digest')
    else:raise ValueError('unbound family')
    return {'verified_local_semantics':True,'forecast_truth_verified':False,'native_core_verified':False}

def main():
    source_hash=hashlib.sha256(open(__file__,'rb').read()).hexdigest()
    for line in sys.stdin:
        try:
            need(len(line)<2_000_000,'verification input bound')
            x=json.loads(line);r=verify(x['family'],x['payload'],x['result'])
            out={'id':x['id'],'ok':True,'details':r,'result_sha256':hashlib.sha256(canon(x['result'])).hexdigest()}
        except Exception as exc:out={'id':locals().get('x',{}).get('id'),'ok':False,'error':type(exc).__name__+': '+str(exc)[:180]}
        out.update(verifier=VERSION,pid=os.getpid(),verifier_source_sha256=source_hash,external_third_party=False)
        print(json.dumps(out,sort_keys=True,ensure_ascii=False),flush=True)

if __name__=='__main__':main()
